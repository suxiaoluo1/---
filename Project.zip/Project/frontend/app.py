import streamlit as st

from ui.api import api_post, normalize_resp
from ui.pages.admin import render_admin_create_user, render_admin_knowledge_center, render_admin_overview, \
    render_admin_users
from ui.pages.student import (
    render_student_chat,
    render_student_dashboard,
    render_student_knowledge_graph,
    render_student_practice,
    render_student_quizzes,
    render_student_wrongs,
)
from ui.pages.teacher import render_teacher_kp, render_teacher_student_detail, render_teacher_students, \
    render_teacher_task
from ui.state import init_state
from ui.styles import inject_global_css, inject_login_css


st.set_page_config(page_title="多模态智能学伴", page_icon="🦉", layout="wide")
init_state()
inject_global_css()

if not st.session_state.get("token"):
    inject_login_css()

    st.markdown("<br><br><br><br>", unsafe_allow_html=True)

    col_empty, col_login = st.columns([5.5, 4.5])

    with col_login:
        st.markdown("## 🦉 多模态融合智能学伴")
        st.markdown(
            "<p style='font-size: 1.1rem; line-height: 1.6; color: #555; margin-bottom: 1.5rem;'>属于你的个性化学习大本营。支持知识图谱、多模态智能问答、题目特训与实验报告AI辅导。</p>",
            unsafe_allow_html=True)

        tab_login, tab_reg = st.tabs(["🚀 立即登录", "🌱 注册账号"])
        with tab_login:
            role = st.selectbox("你的身份是", ["student", "teacher", "admin"], format_func=lambda x:
            {"student": "🧑‍🎓 学生", "teacher": "👩‍🏫 教师", "admin": "⚙️ 管理员"}[x])
            username = st.text_input("用户名")
            password = st.text_input("密码", type="password")
            if st.button("开启学习之旅 ✨", use_container_width=True):
                ok_flag, data, msg = normalize_resp(
                    api_post("/api/auth/login", {"username": username, "password": password, "role": role}))
                if ok_flag:
                    st.session_state.token = data["access_token"]
                    st.session_state.role = data["role"]
                    st.session_state.username = data["username"]
                    st.rerun()
                else:
                    st.error(msg)
        with tab_reg:
            full_name = st.text_input("你的真实姓名")
            reg_user = st.text_input("设定一个用户名")
            reg_pwd = st.text_input("设置一个安全的密码", type="password")
            grade = st.text_input("所在年级/专业")
            if st.button("加入我们 🎉", use_container_width=True):
                ok_flag, _, msg = normalize_resp(api_post("/api/auth/register",
                                                          {"username": reg_user, "password": reg_pwd, "role": "student",
                                                           "full_name": full_name, "grade": grade,
                                                           "subject": "软件项目管理"}))
                if ok_flag:
                    st.success("太棒了！注册成功，快去登录吧。")
                else:
                    st.error(msg)

    st.stop()

role = st.session_state.get("role")
token = st.session_state.get("token")

# 学生端菜单全面活泼化
nav_menus = {
    "student": ["🏠 我的大本营", "💬 智能问答", "🎯 专项练习", "🧠 知识星系图", "📔 我的错题本", "📊 荣誉墙"],
    "teacher": ["👥 学生列表", "🔍 学习详情", "📝 发布任务", "💡 课程知识库"],
    "admin": ["📈 系统概览", "👥 用户管理", "➕ 新增用户", "📚 知识中心"],
}
current_menu = nav_menus.get(role, [])
if "current_page" not in st.session_state or st.session_state.current_page not in current_menu:
    st.session_state.current_page = current_menu[0] if current_menu else None


def switch_page(page_name):
    st.session_state.current_page = page_name


with st.sidebar:
    st.markdown("### 🗺️ 探索导航")
    for page in current_menu:
        st.button(page, type="primary" if st.session_state.current_page == page else "secondary",
                  use_container_width=True, on_click=switch_page, args=(page,), key=f"nav_{page}")
    st.divider()
    st.info(f"👤 {st.session_state.username}\n\n🏫 {role}")
    if st.button("🚪 退出登录", use_container_width=True):
        for key in ["token", "role", "username", "current_page"]:
            st.session_state[key] = None
        st.session_state.history = []
        st.session_state.chat_pending_request = None
        st.rerun()

page = st.session_state.current_page
if role == "student":
    {
        "🏠 我的大本营": render_student_dashboard,
        "🎯 专项练习": render_student_practice,
        "💬 智能问答": render_student_chat,
        "📔 我的错题本": render_student_wrongs,
        "📊 荣誉墙": render_student_quizzes,
        "🧠 知识星系图": render_student_knowledge_graph,
    }[page](token)
elif role == "teacher":
    {
        "👥 学生列表": render_teacher_students,
        "🔍 学习详情": render_teacher_student_detail,
        "📝 发布任务": render_teacher_task,
        "💡 课程知识库": render_teacher_kp,
    }[page](token)
elif role == "admin":
    {
        "📈 系统概览": render_admin_overview,
        "👥 用户管理": render_admin_users,
        "➕ 新增用户": render_admin_create_user,
        "📚 知识中心": render_admin_knowledge_center,
    }[page](token)