import json
import time

import streamlit as st

from ..api import api_get, api_post, api_post_file, api_post_multipart, normalize_resp
from ..components import render_metric_card, render_top_header

SUBJECT = "软件项目管理"
MODE_OPTIONS = {
    "分步讲解": "step_by_step",
    "错题分析": "wrong_analysis",
    "知识点讲解": "knowledge_explain",
    "图表题分析": "chart_analysis",
    "实验报告辅导": "report_guidance",
    "AI批改作业": "ai_grading",
}
FILE_TYPES = ["txt", "md", "docx", "pdf", "pptx", "png", "jpg", "jpeg", "webp", "bmp"]


def _stream_text(text: str, delay: float = 0.01):
    if not text:
        return
    for ch in text:
        yield ch
        time.sleep(delay)


def _build_uploaded_payload(uploaded):
    if uploaded is None:
        return None
    return {
        "name": uploaded.name,
        "data": uploaded.getvalue(),
        "type": uploaded.type or "application/octet-stream",
    }


def _append_history(role: str, content: str, sources: dict | None = None):
    entry = {"role": role, "content": content}
    if sources:
        entry["sources"] = sources
    st.session_state.history.append(entry)


def _format_weak_points_text(weak_points) -> str:
    if not weak_points:
        return "暂无"
    parts: list[str] = []
    for item in weak_points:
        if isinstance(item, dict):
            point_name = str(item.get("knowledge_point") or item.get("name") or "未命名知识点").strip()
            wrong_count = item.get("wrong_count")
            if wrong_count is None:
                parts.append(point_name)
            else:
                parts.append(f"{point_name}（错 {wrong_count} 次）")
        else:
            value = str(item).strip()
            if value:
                parts.append(value)
    return "、".join(parts) if parts else "暂无"


def _build_graph_deep_dive_prompt(point_name: str) -> str:
    return (
        f"请结合课程知识库和教师资料，系统讲解“{point_name}”的核心概念、常见方法、适用场景，"
        "并结合我当前的薄弱表现说明我为什么容易出错，最后给出可执行的复习建议。"
    )


def _render_sources(data: dict):
    rag_used = bool(data.get("rag_used"))
    has_file_info = bool(data.get("uploaded_file_name") or data.get("extracted_text_preview"))
    if not rag_used and not has_file_info:
        st.caption("🟡 知识库中未检索到可靠相关资料，本次为 AI 根据通用能力自行回答。")
        return
    with st.expander("📚 查看 AI 的参考资料与依据"):
        if rag_used:
            st.write(f"**课程**：{data.get('detected_subject')} | **题型**：{data.get('detected_question_type')}")
            st.write("**涉及知识点**：" + "、".join(data.get("knowledge_points") or ["无"]))
            for item in data.get("rag_unique_sources") or []:
                st.markdown(f"- 📄 {item.get('title')} / {item.get('source')}")
        else:
            st.info("知识库中未检索到可靠相关资料，本次为 AI 根据通用能力自行回答。")
        if data.get("uploaded_file_name"):
            st.write(f"**已读取附件**：{data.get('uploaded_file_name')}")
        if data.get("extracted_text_preview"):
            st.caption("文件提取内容预览")
            st.code(data.get("extracted_text_preview"), language="text")


def _request_chat(token: str, prompt: str, mode_label: str, max_new_tokens: int, num_ctx: int, temperature: float,
                  top_p: float, top_k: int, uploaded_payload=None, history=None):
    mode = MODE_OPTIONS[mode_label]
    history = history or []
    if uploaded_payload is not None:
        files = {"file": (uploaded_payload["name"], uploaded_payload["data"], uploaded_payload["type"])}
        return normalize_resp(api_post_multipart(
            "/api/chat/with-file",
            {
                "prompt": prompt,
                "subject": SUBJECT,
                "mode": mode,
                "history_json": json.dumps(history, ensure_ascii=False),
                "max_new_tokens": str(max_new_tokens),
                "num_ctx": str(num_ctx),
                "temperature": str(temperature),
                "top_p": str(top_p),
                "top_k": str(top_k),
            },
            token,
            files=files,
        ))
    return normalize_resp(api_post(
        "/api/chat",
        {
            "prompt": prompt,
            "image_b64": None,
            "subject": SUBJECT,
            "mode": mode,
            "history": history,
            "max_new_tokens": max_new_tokens,
            "num_ctx": num_ctx,
            "temperature": temperature,
            "top_p": top_p,
            "top_k": top_k,
        },
        token,
    ))


def _switch_student_page(page_name: str):
    st.session_state.current_page = page_name


def _load_targeted_practice(token: str, payload: dict, mode: str = "normal"):
    endpoint = "/api/student/practice/generate-from-wrong" if mode == "wrong" else "/api/student/practice/generate"
    ok_flag, data, msg = normalize_resp(api_post(endpoint, payload, token))
    if ok_flag:
        st.session_state.practice_questions = data.get("questions", [])
        st.session_state.practice_filters = data.get("filters") or payload
        st.session_state.practice_result = None
        st.session_state.practice_index = 0
        st.session_state.practice_answers = {}
        st.session_state.practice_stage = "exam"
        st.session_state.practice_quick_config = None
        st.session_state.current_page = "🎯 专项练习"
        st.success(msg)
        st.rerun()
    else:
        st.error(msg)


def _render_summary_list(title: str, items: list[dict], fmt):
    st.subheader(title)
    if not items:
        st.caption("暂无足够数据，继续加油学习吧！🌟")
        return
    for item in items:
        st.markdown(f"- {fmt(item)}")


def _render_practice_summary_card(summary_card: dict | None):
    if not summary_card:
        return
    st.subheader("🧾 本次练习大通关总结！🎉")
    c1, c2, c3 = st.columns(3)
    with c1:
        chapters = summary_card.get("chapter_breakdown") or []
        st.metric("涉及章节", len(chapters))
    with c2:
        weak_points = summary_card.get("weak_points") or []
        st.metric("还需努力的知识点", len(weak_points))
    with c3:
        next_actions = summary_card.get("next_actions") or []
        st.metric("学伴锦囊", len(next_actions))

    st.divider()
    for item in summary_card.get("chapter_breakdown") or []:
        st.info(
            f"📍 章节：{item.get('chapter')} ｜ ✅ 正确率：{item.get('accuracy')}% ｜ ❌ 错题 {item.get('wrong_count')} 道")
    if summary_card.get("weak_points"):
        st.caption("🔍 发现你的薄弱点啦：")
        st.write(_format_weak_points_text(summary_card.get("weak_points") or []))
    for action in summary_card.get("next_actions") or []:
        st.success(f"💡 {action}")


def render_student_chat(token: str):
    # 将清空对话转移到了左侧边栏最下方
    with st.sidebar:
        st.markdown("---")
        if st.button("🧹 清空当前对话", use_container_width=True):
            st.session_state.history = []
            st.session_state.chat_pending_request = None
            st.rerun()

    render_top_header("🦉 你的专属智能学伴", "有什么我可以帮你的？无论是解答问题、分析图表还是辅导报告，随时发给我哦！✨")
    if "history" not in st.session_state:
        st.session_state.history = []

    tab_chat, tab_chart, tab_report, tab_grade = st.tabs(
        ["💬 综合问答", "📈 图表分析专区", "📝 报告辅导精灵", "✅ AI作业批改"])

    with tab_chat:
        st.session_state.setdefault("chat_pending_request", None)

        # === 1. 聊天记录展示区 ===
        chat_container = st.container()
        with chat_container:
            if not st.session_state.history:
                st.info(
                    "👋 你好呀！我是你的 AI 学习助手。你可以直接在下方问我任何专业问题，也可以点击输入框左侧的“📎 附件”上传题目截图或文档让我帮你分析哦！")

            for item in st.session_state.history:
                avatar = "🧑‍🎓" if item["role"] == "user" else "🦉"
                with st.chat_message(item["role"], avatar=avatar):
                    st.write(item["content"])
                    if item.get("sources"):
                        _render_sources(item["sources"])

            # 处理等待中的回复
            pending_request = st.session_state.get("chat_pending_request")
            if pending_request:
                with st.chat_message("assistant", avatar="🦉"):
                    thinking_placeholder = st.empty()
                    thinking_placeholder.info("🦉 学伴正在疯狂思考中，请稍等...")
                    time.sleep(0.15)
                    ok_flag, data, msg = _request_chat(
                        token=token,
                        prompt=pending_request["prompt"],
                        mode_label=pending_request["mode_label"],
                        max_new_tokens=pending_request["max_new_tokens"],
                        num_ctx=pending_request["num_ctx"],
                        temperature=pending_request["temperature"],
                        top_p=pending_request["top_p"],
                        top_k=pending_request["top_k"],
                        uploaded_payload=pending_request.get("uploaded_payload"),
                        history=pending_request.get("history_before") or [],
                    )
                    thinking_placeholder.empty()
                    if ok_flag:
                        answer_text = data.get("answer") or ""
                        streamed_text = st.write_stream(_stream_text(answer_text))
                        _render_sources(data)
                        _append_history("assistant", streamed_text or answer_text, data)
                    else:
                        error_text = f"请求失败了呀：{msg}"
                        st.error(error_text)
                        _append_history("assistant", error_text)
                st.session_state.chat_pending_request = None
                st.rerun()

        # 处理知识图谱传过来的草稿问题
        draft_prompt = st.session_state.get("chat_draft_prompt")
        if draft_prompt:
            st.success("✨ 已收到学习图谱的推荐问题！您可以直接发送。")
            st.code(draft_prompt, language="text")
            if st.button("🚀 一键发送该问题", use_container_width=True, key="chat_send_draft"):
                history_before = list(st.session_state.history)
                _append_history("user", draft_prompt)
                st.session_state.chat_pending_request = {
                    "prompt": draft_prompt,
                    "mode_label": "知识点讲解",
                    "max_new_tokens": 1024, "num_ctx": 8192, "temperature": 0.7, "top_p": 0.9, "top_k": 40,
                    "uploaded_payload": None,
                    "history_before": history_before,
                }
                st.session_state.chat_draft_prompt = None
                st.rerun()

        # === 2. 底部输入区 (原生 GPT 级体验，再无任何干扰元素) ===
        # 移除了上方的 radio 单选框和清空按钮，让 chat_input 成为真正的唯一底部悬浮栏
        prompt = st.chat_input(
            "向智能学伴提问，或者点击左侧别针图标上传附件...",
            accept_file=True,
            file_type=FILE_TYPES,
            disabled=bool(st.session_state.get("chat_pending_request")),
        )

        if prompt:
            # ✅ 修复 JSON 序列化报错：正确解析 Streamlit 1.43 的 ChatInputValue 对象
            if hasattr(prompt, "text") and hasattr(prompt, "files"):
                user_text = prompt.text
                files = prompt.files
            elif isinstance(prompt, dict):
                user_text = prompt.get("text", "")
                files = prompt.get("files", [])
            else:
                user_text = str(prompt)
                files = []

            uploaded_file = files[0] if files else None

            # 如果用户传了文件但没写文字，给个默认提示
            if not user_text and uploaded_file:
                user_text = f"请帮我分析这份文件：{uploaded_file.name}"

            history_before = list(st.session_state.history)
            _append_history("user", user_text)

            # 删除了 UI 控制后，底层直接固定默认模式，对用户透明
            st.session_state.chat_pending_request = {
                "prompt": user_text,
                "mode_label": "知识点讲解",  # 默认锁死为知识点讲解
                "max_new_tokens": 1024,
                "num_ctx": 8192,
                "temperature": 0.7,
                "top_p": 0.9,
                "top_k": 40,
                "uploaded_payload": _build_uploaded_payload(uploaded_file) if uploaded_file else None,
                "history_before": history_before,
            }
            st.session_state.chat_draft_prompt = None
            st.rerun()

    with tab_chart:
        left, right = st.columns([1.05, 1.75], gap="large")
        with left:
            with st.form("chart_analysis_form_integrated"):
                title = st.text_input("给这道图表题起个名字吧", value="图表题分析")
                chart_type = st.selectbox("这属于什么类型的图表呢？",
                                          ["网络图", "甘特图", "燃尽图", "挣值分析图", "风险矩阵图", "其他图表"],
                                          index=0)
                prompt = st.text_area("有没有什么特别想问的？", height=120, placeholder="例如：帮我找一下关键路径...")
                uploaded = st.file_uploader("📸 咔嚓！上传图表图片", type=["png", "jpg", "jpeg", "webp", "bmp"],
                                            key="chart_integrated_upload")
                submitted = st.form_submit_button("🚀 让 AI 帮我分析", use_container_width=True)
                if submitted:
                    if not uploaded:
                        st.warning("⚠️ 别忘了上传图片哦！")
                    else:
                        ok_flag, data, msg = normalize_resp(api_post_file(
                            "/api/student/chart-analyses/analyze",
                            {"title": title, "chart_type": chart_type, "prompt": prompt},
                            "file",
                            (uploaded.name, uploaded.getvalue(), uploaded.type or "application/octet-stream"),
                            token,
                        ))
                        if ok_flag:
                            st.session_state.chart_analysis_latest = data
                            st.success("🎉 分析完成啦！")
                            st.rerun()
                        else:
                            st.error(msg)
        with right:
            latest = st.session_state.get("chart_analysis_latest")
            if not latest:
                ok_flag, rows, _ = normalize_resp(api_get("/api/student/chart-analyses", token))
                if ok_flag and rows:
                    latest = rows[0]
            if latest:
                st.subheader("📌 关键信息捕获")
                st.write(f"**图表类型**：{latest.get('chart_type')}")
                st.write("**涉及知识点**：" + "、".join(latest.get("knowledge_points") or ["无"]))
                st.subheader("💡 学伴的分析结果")
                st.info(latest.get("ai_feedback") or "暂无分析结果")
            else:
                st.info("👈 上传图表后，学伴会在这里把分析结果原原本本地告诉你哦！")

    with tab_report:
        left, right = st.columns([1.05, 1.75], gap="large")
        with left:
            title = st.text_input("实验报告名称", value="我的实验报告", key="report_title")
            mode = st.radio("你想怎么提交？", ["直接粘贴正文", "上传文档附件"], horizontal=True, key="report_mode")
            if mode == "直接粘贴正文":
                content = st.text_area("报告正文内容", height=280, key="report_content")
                if st.button("🚀 开始辅导与润色", use_container_width=True, key="report_submit_text"):
                    ok_flag, data, msg = normalize_resp(
                        api_post("/api/student/report-guidance", {"title": title, "content": content}, token))
                    if ok_flag:
                        st.session_state.report_guidance_latest = data
                        st.success("批阅完毕！")
                        st.rerun()
                    else:
                        st.error(msg)
            else:
                uploaded = st.file_uploader("上传报告文件", type=["txt", "md", "docx", "pdf", "pptx"],
                                            key="report_file")
                if st.button("🚀 上传并开始辅导", use_container_width=True, key="report_submit_file"):
                    if not uploaded:
                        st.warning("⚠️ 别忘了选择文件呀！")
                    else:
                        ok_flag, data, msg = normalize_resp(api_post_file(
                            "/api/student/report-guidance/upload",
                            {"title": title},
                            "file",
                            (uploaded.name, uploaded.getvalue(), uploaded.type or "application/octet-stream"),
                            token,
                        ))
                        if ok_flag:
                            st.session_state.report_guidance_latest = data
                            st.success("批阅完毕！")
                            st.rerun()
                        else:
                            st.error(msg)
        with right:
            latest = st.session_state.get("report_guidance_latest")
            if not latest:
                ok_flag, rows, _ = normalize_resp(api_get("/api/student/report-guidance", token))
                if ok_flag and rows:
                    latest = rows[0]
            if latest:
                c1, c2 = st.columns([1, 1.4])
                with c1:
                    st.metric("🌟 AI 预估得分", f"{latest.get('ai_score') or 0} 分")
                    st.metric("🏅 综合评价等级", latest.get("overall_level") or "待评估")
                with c2:
                    st.caption("本次辅导已形成闭环结果，快根据建议修改吧！加油！")
                st.subheader("✨ 你的报告亮点")
                for item in latest.get("highlights") or ["暂无亮点总结"]:
                    st.success(item)
                st.subheader("🔧 这里还可以优化哦")
                for item in latest.get("improvements") or ["暂无改进建议"]:
                    st.warning(item)
            else:
                st.info("👈 提交报告后，这里会展示预估分数、报告亮点和非常详细的改进建议。")

    with tab_grade:
        left, right = st.columns([1.05, 1.75], gap="large")
        with left:
            title = st.text_input("题目简述", value="主观题批改", key="grade_title")
            question_text = st.text_area("原题目是怎样的？", height=120, key="grade_question")
            answer_mode = st.radio("你的答案", ["直接手敲", "上传照片/文档"], horizontal=True, key="grade_mode")
            student_answer = st.text_area("输入你的回答", height=180,
                                          key="grade_answer") if answer_mode == "直接手敲" else ""
            uploaded = st.file_uploader("上传答案附件", type=["txt", "md", "docx", "pdf", "pptx", "png", "jpg"],
                                        key="grade_file") if answer_mode == "上传照片/文档" else None
            reference_answer = st.text_area("参考标准答案（如果有的话）", height=100, key="grade_reference")
            if st.button("🚀 让学伴帮我批改", use_container_width=True, key="grade_submit"):
                files = None
                if uploaded is not None:
                    files = {"file": (uploaded.name, uploaded.getvalue(), uploaded.type or "application/octet-stream")}
                ok_flag, data, msg = normalize_resp(api_post_multipart(
                    "/api/student/assignment-grading",
                    {
                        "title": title,
                        "question_text": question_text,
                        "student_answer": student_answer,
                        "reference_answer": reference_answer,
                    },
                    token,
                    files=files,
                ))
                if ok_flag:
                    st.session_state.assignment_latest = data
                    st.success("批改完成！快看右边的建议吧。")
                    st.rerun()
                else:
                    st.error(msg)
        with right:
            latest = st.session_state.get("assignment_latest")
            if not latest:
                ok_flag, rows, _ = normalize_resp(api_get("/api/student/assignment-grading", token))
                if ok_flag and rows:
                    latest = rows[0]
            if latest:
                st.subheader("💡 学伴的批改建议")
                st.info(latest.get("ai_feedback") or "暂无分析建议")
                st.subheader("✍️ 给你一个满分答案示范")
                st.write(latest.get("optimized_answer") or "暂无优化答案建议")
            else:
                st.info("👈 输入题目和你的答案后，右侧会马上为你生成详细的批改建议和高分示范！")


def _graphviz_dot(nodes, edges):
    color_map = {"mastered": "#4ade80", "learning": "#fbbf24", "weak": "#f87171", "unknown": "#94a3b8"}
    lines = ["graph G {", 'layout=neato;', 'overlap=false;', 'splines=true;', 'bgcolor="transparent";']
    for n in nodes:
        name = n["name"].replace('"', "'")
        color = n.get("color") or color_map.get(n.get("status"), "#94a3b8")
        mastery = n.get("mastery_percent")
        label = name if mastery is None else f"{name}\n{mastery}%"
        width = max(0.9, float(n.get("symbol_size", 28)) / 36.0)
        lines.append(
            f'n{n["id"]} [label="{label}", shape=circle, width="{width:.2f}", height="{width:.2f}", fixedsize=true, style=filled, fillcolor="{color}", fontcolor="white", fontname="PingFang SC, sans-serif"];')
    for e in edges:
        rel = (e.get("relation") or "相关").replace('"', "'")
        lines.append(
            f'n{e["source"]} -- n{e["target"]} [label="{rel}", fontname="PingFang SC, sans-serif", fontsize=10, color="#cbd5e1"];')
    lines.append("}")
    return "\n".join(lines)


def render_student_knowledge_graph(token: str):
    render_top_header("🕸️ 知识星系图", "在这里探索课程的每个角落，发现自己的学习盲区！🚀")
    ok_flag, data, msg = normalize_resp(api_get(f"/api/student/knowledge-graph?subject={SUBJECT}", token))
    if not ok_flag:
        st.error(msg)
        return
    left, right = st.columns([1.05, 2.15], gap="large")
    with left:
        st.metric("🌟 已点亮知识节点", data.get("node_count", 0))
        st.subheader("💡 学伴小贴士")
        for item in data.get("recommendations", []):
            st.info(item)
        node_details = data.get("node_details") or []
        names = [item.get("name") for item in node_details if item.get("name")]
        default_name = st.session_state.get("graph_selected_node") if st.session_state.get(
            "graph_selected_node") in names else (names[0] if names else None)
        if names:
            selected = st.selectbox("👇 选择一个星球查看诊断报告", names,
                                    index=names.index(default_name) if default_name in names else 0)
            st.session_state.graph_selected_node = selected
            detail = next((x for x in node_details if x.get("name") == selected), None)
            if detail:
                st.subheader("🩺 星球诊断详情")
                st.write(f"**当前掌握度**：{detail.get('mastery_percent', 0)}%")
                st.write(f"**近期踩雷(错题)**：{detail.get('recent_wrong_count', 0)} 次")
                acc = detail.get('recent_accuracy')
                st.write(f"**专项正确率**：{acc if acc is not None else '暂无数据'}%")
                if detail.get("diagnosis_reason"):
                    st.warning(f"⚠️ {detail.get('diagnosis_reason')}")
                if detail.get("recommended_action"):
                    st.success(f"✅ {detail.get('recommended_action')}")
                cols = st.columns(2)
                with cols[0]:
                    if st.button("💬 去找学伴深挖", use_container_width=True):
                        st.session_state.chat_draft_prompt = _build_graph_deep_dive_prompt(selected)
                        st.session_state.chat_mode_label = "知识点讲解"
                        _switch_student_page("💬 智能问答")
                        st.rerun()
                with cols[1]:
                    chapter = detail.get("module")
                    if st.button("🎯 去做针对训练", use_container_width=True):
                        st.session_state.practice_quick_config = {
                            "mode": "normal",
                            "payload": {"chapter": chapter or "全部", "difficulty": "适中", "count": 5},
                        }
                        _switch_student_page("🎯 专项练习")
                        st.rerun()
        st.caption("🟢 绿色=掌握优秀；🟡 黄色=需要巩固；🔴 红色=近期重灾区。")
    with right:
        st.graphviz_chart(_graphviz_dot(data.get("nodes", []), data.get("edges", [])), use_container_width=True)




def _load_learning_progress(token: str) -> dict:
    ok_flag, data, msg = normalize_resp(api_get("/api/student/progress", token))
    if not ok_flag:
        return {"chapters": [], "summary_text": msg or "暂无学习进度数据"}
    return data or {"chapters": []}


def _progress_status_badge(status: str) -> str:
    mapping = {
        "尚未开始": "status-empty",
        "需要巩固": "status-review",
        "正在提升": "status-started",
        "掌握较好": "status-good",
    }
    cls = mapping.get(status, "status-empty")
    return f'<span class="status-pill {cls}">{status}</span>'


def _render_learning_progress_panel(progress_data: dict):
    chapters = progress_data.get("chapters") or []
    with st.container(border=True):
        st.markdown("### 📈 学习进度")
        st.caption(progress_data.get("summary_text") or "继续练习后，这里会为你展示每个章节的学习轨迹。")
    if not chapters:
        st.info("还没有足够的专项练习记录，完成一次训练后即可生成十个章节的学习进度。")
        return
    for item in chapters:
        header = f"<div class='chapter-progress-card'><div style='display:flex;justify-content:space-between;gap:12px;align-items:flex-start;'><div style='flex:1;'><div style='font-weight:800;color:#24324d;font-size:15px;line-height:1.6'>{item.get('chapter')}</div><div style='font-size:12px;color:#64748b;margin-top:6px;'>练习 {item.get('practice_count', 0)} 次 ｜ 正确率 {item.get('accuracy', 0)}%</div></div><div>{_progress_status_badge(item.get('status', '尚未开始'))}</div></div></div>"
        st.markdown(header, unsafe_allow_html=True)
        st.progress(max(0.0, min(1.0, float(item.get("progress_percent", 0)) / 100)))


def render_student_dashboard(token: str):
    render_top_header("🏠 我的学习大本营", "欢迎回来！今天继续一起打怪升级吧～这里将展示你的任务提醒、个性化学习路线和十个章节的学习进度。")
    ok_flag, data, msg = normalize_resp(api_get("/api/student/dashboard", token))
    if not ok_flag:
        st.error(msg)
        return
    recommendation = data.get("recommendation") or {}
    recent_summary = recommendation.get("recent_summary") or {}
    progress_data = _load_learning_progress(token)

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        render_metric_card("📓 错题积累", f"{data['wrong_count']} 道")
    with c2:
        render_metric_card("📝 练习/测验记录", f"{data['quiz_count']} 次")
    with c3:
        render_metric_card("🛣️ 专属学习路线", f"{len(data['paths'])} 条")
    with c4:
        render_metric_card("🎯 今日待完成", f"{len(data['tasks'])} 个")

    left, right = st.columns([1.55, 1.05], gap="large")
    with left:
        with st.container(border=True):
            st.markdown("### 🌟 今日学伴寄语")
            for item in recommendation.get("recommendations", []):
                st.markdown(f"- {item}")
        col_a, col_b = st.columns(2)
        with col_a:
            _render_summary_list(
                "🔥 近期踩坑最多（知识点）",
                recent_summary.get("top_wrong_knowledge_points") or [],
                lambda x: f"**{x.get('knowledge_point')}**：错 {x.get('wrong_count')} 次",
            )
        with col_b:
            _render_summary_list(
                "⚠️ 当前需要优先巩固的章节",
                recent_summary.get("low_accuracy_chapters") or [],
                lambda x: f"**{x.get('chapter')}**：正确率 {x.get('accuracy')}%",
            )

        st.subheader("🗺️ 你的专属修炼路线")
        paths = data.get("paths", [])
        if not paths:
            st.info("🌱 多做做专项练习或者记录几道错题，属于你的个性化学习路线就会自动生成。")
        for p in paths:
            reason = p.get("reason") or "系统根据你最近的练习和错题自动生成。"
            title = p.get("title") or "个性化学习路径"
            goal = p.get("goal") or "围绕近期薄弱点做针对性复习。"
            actions = p.get("action_targets") or {}
            with st.container(border=True):
                st.markdown(f"**📌 {title}**")
                st.caption(f"🎯 目标：{goal}")
                st.info(f"🦉 学伴分析：{reason}")
                for i, step in enumerate(p.get("steps") or [], 1):
                    st.write(f"**Step {i}**：{step}")
                c_practice, c_graph, c_chat = st.columns(3)
                with c_practice:
                    if st.button("🎯 去做练习", key=f"dash_practice_{p.get('id')}", use_container_width=True):
                        st.session_state.practice_quick_config = {"mode": "normal", "payload": actions.get("practice") or {"chapter": "全部", "difficulty": "适中", "count": 5}}
                        _switch_student_page("🎯 专项练习")
                        st.rerun()
                with c_graph:
                    if st.button("🕸️ 看知识图谱", key=f"dash_graph_{p.get('id')}", use_container_width=True):
                        st.session_state.graph_selected_node = (actions.get("graph") or {}).get("node_name")
                        _switch_student_page("🧠 知识星系图")
                        st.rerun()
                with c_chat:
                    if st.button("💬 问学伴", key=f"dash_chat_{p.get('id')}", use_container_width=True):
                        st.session_state.chat_draft_prompt = ((actions.get("chat") or {}).get("prompt") or reason)
                        st.session_state.chat_mode_label = "知识点讲解"
                        _switch_student_page("💬 智能问答")
                        st.rerun()
    with right:
        _render_learning_progress_panel(progress_data)
        if progress_data.get("priority_revisit"):
            revisit = progress_data.get("priority_revisit") or {}
            with st.container(border=True):
                st.markdown("**🎯 本周优先突破**")
                st.write(f"建议优先巩固 **{revisit.get('chapter')}**，当前正确率 **{revisit.get('accuracy')}%**。")
                if st.button("去做本章专项训练", key="go_revisit_chapter", use_container_width=True):
                    st.session_state.practice_quick_config = {"mode": "normal", "payload": {"chapter": revisit.get("chapter") or "全部", "difficulty": "适中", "count": 5}}
                    _switch_student_page("🎯 专项练习")
                    st.rerun()
        tasks = data.get("tasks") or []
        if tasks:
            with st.container(border=True):
                st.markdown("**📋 待办提醒**")
                for task in tasks[:6]:
                    st.markdown(f"- **{task.get('title')}** ｜ 状态：{task.get('status')}")


def render_student_wrongs(token: str):
    render_top_header("📔 我的错题本", "失败是成功之母！在这里消灭所有易错点吧！💪")
    left, right = st.columns([1.1, 1.7], gap="large")
    with left:
        with st.form("wrong_form"):
            question = st.text_area("把记不住的题目扔进来吧")
            answer = st.text_area("你的答案 / 正确答案")
            analysis = st.text_area("为什么会错呢？反思一下")
            submitted = st.form_submit_button("💾 存入错题本", use_container_width=True)
            if submitted:
                ok_flag, _, msg = normalize_resp(api_post("/api/student/wrong-questions",
                                                          {"subject": SUBJECT, "question_text": question,
                                                           "answer_text": answer, "analysis": analysis}, token))
                if ok_flag:
                    st.success("收录成功！")
                    st.rerun()
                else:
                    st.error(msg)
    with right:
        ok_flag, data, msg = normalize_resp(api_get("/api/student/wrong-questions", token))
        if ok_flag:
            if not data:
                st.info("太棒了！错题本空空如也，继续保持哦！🎉")
            for row in data:
                title = f"🐛 错题 #{row['id']}"
                if row.get("knowledge_points"):
                    title += f" ｜ {'、'.join(row.get('knowledge_points')[:2])}"
                with st.expander(title):
                    st.markdown("**题目**")
                    st.write(row["question_text"])
                    st.markdown("**正确答案**")
                    st.write(row.get("answer_text") or "未记录")
                    st.info(row.get("analysis") or "未记录分析")
                    if row.get("knowledge_points"):
                        st.caption("🏷️ 关联卡片：" + "、".join(row.get("knowledge_points") or []))
                    cols = st.columns(3)
                    with cols[0]:
                        if st.button("⚔️ 再次挑战", key=f"retry_q_{row['id']}", use_container_width=True):
                            st.session_state.practice_quick_config = {"mode": "wrong", "payload": {"mode": "question",
                                                                                                   "wrong_question_id":
                                                                                                       row["id"],
                                                                                                   "count": 5}}
                            _switch_student_page("🎯 专项练习")
                            st.rerun()
                    with cols[1]:
                        disabled = not bool(row.get("knowledge_points"))
                        if st.button("📖 突破该考点", key=f"retry_kp_{row['id']}", use_container_width=True,
                                     disabled=disabled):
                            st.session_state.practice_quick_config = {"mode": "wrong",
                                                                      "payload": {"mode": "knowledge_point",
                                                                                  "knowledge_point": (row.get(
                                                                                      "knowledge_points") or [None])[0],
                                                                                  "count": 5}}
                            _switch_student_page("🎯 专项练习")
                            st.rerun()
                    if row.get("ai_analysis"):
                        st.markdown("### 🦉 学伴溯源分析")
                        st.warning(row.get("ai_analysis"))
        else:
            st.error(msg)


def render_student_quizzes(token: str):
    render_top_header("📊 荣誉墙 (测验记录)", "见证你的每一次成长！看看最近战绩如何。🏆")
    ok_flag, data, msg = normalize_resp(api_get("/api/student/quiz-records", token))
    if ok_flag:
        if not data:
            st.info("还没有测验记录呢，快去【🎯 专项练习】练练手吧！")
        for row in data:
            st.markdown(
                f"<div class='soft-card'><b>🏆 {row['subject']}</b><br>成绩：{row['score']}/{row['total_score']}<br>{row.get('summary') or '干得漂亮！'}</div>",
                unsafe_allow_html=True)
    else:
        st.error(msg)




def _reset_practice_state():
    st.session_state.practice_questions = []
    st.session_state.practice_filters = None
    st.session_state.practice_result = None
    st.session_state.practice_index = 0
    st.session_state.practice_answers = {}
    st.session_state.practice_stage = "home"


def _render_practice_home(token: str, options_data: dict):
    chapters = ["全部章节"] + list(options_data.get("chapters") or [])
    difficulties = options_data.get("difficulties") or ["简单", "适中", "困难"]
    count_options = options_data.get("count_options") or [5, 10, 20]

    with st.container(border=True):
        st.markdown("### 🪄 选择你的训练方式")
        st.markdown("<span class='hero-chip'>🎯 个性化专项训练</span><span class='hero-chip'>🧠 错题定向修复</span><span class='hero-chip'>✨ 更沉浸的答题界面</span>", unsafe_allow_html=True)
        st.caption("系统会优先从你的错题本中抽取相关题目；若错题不足，则自动从题库补充，让练习更加贴合你的学习状态。")

    left, right = st.columns([1.05, 1], gap="large")
    with left:
        with st.container(border=True):
            st.markdown("### ⚙️ 练习参数设置")
            st.caption("先设定范围、难度和题量，再开启一次更有“进入答题界面”感觉的沉浸式练习。")
            chapter = st.selectbox("训练范围", chapters, index=0)
            difficulty = st.selectbox("难度选择", difficulties, index=difficulties.index("适中") if "适中" in difficulties else 0)
            count = st.radio("题量", count_options, horizontal=True, index=0)
            if st.button("🚀 开始专项练习", key="start_practice_normal", use_container_width=True):
                payload = {"chapter": "全部" if chapter == "全部章节" else chapter, "difficulty": difficulty, "count": count}
                _load_targeted_practice(token, payload, mode="normal")

    with right:
        col1, col2 = st.columns(2)
        with col1:
            with st.container(border=True):
                st.markdown("### 🧠 错题优先混合练")
                st.write("优先抽取错题，再从题库补齐，适合日常查漏补缺与阶段巩固。")
                if st.button("🌈 错题优先开练", key="start_practice_mix", use_container_width=True):
                    payload = {"chapter": "全部" if chapter == "全部章节" else chapter, "difficulty": difficulty, "count": count}
                    _load_targeted_practice(token, payload, mode="normal")
        with col2:
            with st.container(border=True):
                st.markdown("### 📚 只练错题")
                st.write("只从错题本中提取原题或同类题，适合考前冲刺和薄弱点强化。")
                if st.button("🎯 进入错题专练", key="start_practice_wrong", use_container_width=True):
                    _load_targeted_practice(token, {"mode": "chapter", "chapter": "全部" if chapter == "全部章节" else chapter, "count": count}, mode="wrong")
        with st.container(border=True):
            st.markdown("**✨ 你将得到哪些体验？**")
            st.markdown("- 进入独立答题视图，减少“还在配置页”的感觉。")
            st.markdown("- 支持逐题作答、即时查看当前进度、交卷后获得学伴分析。")
            st.markdown("- 配合错题本与学习进度，形成更完整的个性化学习闭环。")


def _render_practice_exam(token: str):
    questions = st.session_state.practice_questions or []
    if not questions:
        _reset_practice_state()
        st.info("当前没有可作答的题目，请先返回练习大厅重新开始。")
        return
    idx = st.session_state.practice_index
    idx = max(0, min(idx, len(questions) - 1))
    st.session_state.practice_index = idx
    q = questions[idx]
    filters = st.session_state.get("practice_filters") or {}
    progress_ratio = (idx + 1) / len(questions)

    st.markdown(f"""<div class="exam-banner"><div style='font-size:28px;font-weight:900;margin-bottom:8px;'>📝 专项答题界面</div><div style='opacity:0.92; line-height:1.8;'>当前模式：<b>{filters.get('chapter', '全部章节')}</b> ｜ 难度：<b>{filters.get('difficulty', '适中')}</b> ｜ 题量：<b>{len(questions)} 题</b><br>正在作答第 <b>{idx + 1}</b> / <b>{len(questions)}</b> 题，沉浸答题中，继续加油！</div></div>""", unsafe_allow_html=True)

    top_a, top_b = st.columns([0.78, 0.22])
    with top_a:
        st.progress(progress_ratio)
    with top_b:
        if st.button("↩️ 返回练习大厅", key="back_practice_home", use_container_width=True):
            _reset_practice_state()
            st.rerun()

    if st.session_state.practice_result:
        result = st.session_state.practice_result
        score = result.get("score", 0)
        total = result.get("total", len(result.get("results") or []))
        st.success(f"🎉 已完成交卷！你的得分：{score} / {total}")
        _render_practice_summary_card(result.get("summary_card"))
        for item in result.get("results") or []:
            badge = "✅ 正确" if item.get("is_correct") else "❌ 错误"
            with st.expander(f"{badge} ｜ {item.get('chapter')} ｜ {item.get('question_type')}"):
                st.write(item.get("question_text"))
                st.caption("你的答案")
                st.write(item.get("student_answer") or "（未作答）")
                st.caption("参考答案")
                st.write(item.get("correct_answer") or "暂无")
                st.info(item.get("analysis") or "暂无解析")
        col_r1, col_r2 = st.columns(2)
        with col_r1:
            if st.button("🔁 再来一组同配置练习", key="redo_same_practice", use_container_width=True):
                payload = {"chapter": filters.get("chapter") or "全部", "difficulty": filters.get("difficulty") or "适中", "count": filters.get("count") or len(questions)}
                _load_targeted_practice(token, payload, mode="normal")
        with col_r2:
            if st.button("🏠 返回练习大厅", key="result_back_home", use_container_width=True):
                _reset_practice_state()
                st.rerun()
        return

    with st.container(border=True):
        st.markdown(f"### 第 {idx + 1} 题 ｜ {q.get('difficulty', '适中')} ｜ {q.get('question_type')}")
        st.caption(f"题目来源：{q.get('source_label') or '题库'}")
        st.write(q.get("question_text"))
        existing = st.session_state.practice_answers.get(q["id"], "")
    qid = q["id"]
    current_answer = existing
    if q.get("question_type") in ["单选题", "多选题"]:
        options = q.get("options") or {}
        labels = [f"{k}. {v}" for k, v in options.items()]
        if q.get("question_type") == "多选题":
            existing_list = [x.strip() for x in existing.split(",") if x.strip()]
            selected = st.multiselect("请选择一个或多个答案", labels, default=[lab for lab in labels if lab.split(".")[0].strip() in existing_list])
            current_answer = ",".join([lab.split(".")[0].strip() for lab in selected])
        else:
            index = 0
            if existing:
                for i, label in enumerate(labels):
                    if label.startswith(existing + "."):
                        index = i
                        break
            choice = st.radio("请选择一个正确答案", labels, index=index)
            current_answer = (choice or "").split(".")[0].strip() if choice else ""
    elif q.get("question_type") == "判断题":
        options = ["正确", "错误"]
        index = options.index(existing) if existing in options else 0
        current_answer = st.radio("你的判断是？", options, index=index)
    elif q.get("question_type") == "计算题":
        current_answer = st.text_input("请输入你的计算结果", value=existing)
    else:
        current_answer = st.text_area("请详细写下你的解答", value=existing, height=220)

    st.caption("🏷️ 关联考点：" + "、".join(q.get("knowledge_points") or ["未标注"]))
    st.session_state.practice_answers[qid] = current_answer

    c_prev, c_next, c_submit = st.columns([1, 1, 1.2])
    with c_prev:
        if st.button("⬅️ 上一题", key="practice_prev", disabled=idx == 0, use_container_width=True):
            st.session_state.practice_index -= 1
            st.rerun()
    with c_next:
        if st.button("下一题 ➡️", key="practice_next", disabled=idx >= len(questions) - 1, use_container_width=True):
            st.session_state.practice_index += 1
            st.rerun()
    with c_submit:
        if st.button("交卷查看成绩 🚀", key="practice_submit", use_container_width=True):
            answers = [{"question_id": item["id"], "student_answer": st.session_state.practice_answers.get(item["id"], "")} for item in questions]
            ok3, data3, msg3 = normalize_resp(api_post("/api/student/practice/submit", {"answers": answers}, token))
            if ok3:
                st.session_state.practice_result = data3
                st.success("交卷成功，正在生成你的练习总结！")
                st.rerun()
            else:
                st.error(msg3)


def render_student_practice(token: str):
    render_top_header("🎯 专项演练场", "练习大厅已经升级：你可以先在大厅配置训练方案，点击开始后将进入更独立、更有答题氛围的专项作答界面。")
    ok_flag, options_data, msg = normalize_resp(api_get("/api/student/practice/options", token))
    if not ok_flag:
        st.error(msg)
        return

    st.session_state.setdefault("practice_questions", [])
    st.session_state.setdefault("practice_result", None)
    st.session_state.setdefault("practice_index", 0)
    st.session_state.setdefault("practice_answers", {})
    st.session_state.setdefault("practice_filters", None)
    st.session_state.setdefault("practice_stage", "home")

    quick_cfg = st.session_state.get("practice_quick_config")
    if quick_cfg:
        _load_targeted_practice(token, quick_cfg.get("payload") or {}, mode=quick_cfg.get("mode") or "normal")
        return

    if st.session_state.practice_questions and st.session_state.get("practice_stage") == "exam":
        _render_practice_exam(token)
    else:
        _render_practice_home(token, options_data)
