import streamlit as st
from ..api import api_delete, api_get, api_post, api_post_file, normalize_resp
from ..components import render_top_header

SUBJECT = "软件项目管理"


def render_teacher_students(token: str):
    render_top_header("教师端｜学生列表", "查看《软件项目管理》课程学生名单与班级学习概览。")
    ok_overview, overview, msg_overview = normalize_resp(api_get("/api/teacher/overview", token))
    if ok_overview and overview:
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("班级平均正确率", f"{overview.get('class_average_accuracy', 0)}%")
        c2.metric("实验报告提交人数", overview.get('recent_report_submitters', 0))
        c3.metric("AI批改次数", overview.get('recent_ai_grading_count', 0))
        c4.metric("近7天专项练习量", overview.get('recent_practice_count', 0))
        left, right = st.columns(2)
        with left:
            st.subheader("最近最薄弱章节")
            for item in overview.get("weak_chapters") or []:
                st.markdown(f"- {item.get('chapter')}｜正确率 {item.get('accuracy')}%｜错题 {item.get('wrong_count')} 次")
        with right:
            st.subheader("最近最常错知识点 Top 5")
            for item in overview.get("top_wrong_points") or []:
                st.markdown(f"- {item.get('knowledge_point')}｜错题 {item.get('wrong_count')} 次")
        st.divider()
    elif msg_overview:
        st.info(msg_overview)

    ok_flag, data, msg = normalize_resp(api_get("/api/teacher/students", token))
    if ok_flag:
        cols = st.columns(2)
        for idx, s in enumerate(data):
            with cols[idx % 2]:
                st.markdown(f"<div class='soft-card'><b>{s['full_name'] or s['username']}</b><br>用户名：{s['username']}<br>学生 ID：{s['id']}<br>年级/班级：{s.get('grade') or ''} / {s.get('class_name') or ''}</div>", unsafe_allow_html=True)
    else:
        st.error(msg)


def render_teacher_student_detail(token: str):
    render_top_header("教师端｜学生学习详情", "查看学生在软件项目管理课程中的聊天记录、错题与测验。")
    student_id = st.number_input("输入学生 ID", min_value=1, value=1, step=1)
    if st.button("查询学生详情"):
        ok_flag, data, msg = normalize_resp(api_get(f"/api/teacher/student/{student_id}/records", token))
        if ok_flag:
            a, b, c, d = st.columns(4)
            with a:
                st.subheader("学习记录")
                for r in data["learning_records"] or []:
                    st.markdown(f"- [{r['record_type']}] {r['content'][:120]}")
            with b:
                st.subheader("错题记录")
                for w in data["wrong_questions"] or []:
                    st.markdown(f"- {w['question_text'][:80]}")
            with c:
                st.subheader("测验记录")
                for q in data["quiz_records"] or []:
                    st.markdown(f"- {q['score']}/{q['total_score']}｜{q.get('summary') or ''}")
            with d:
                st.subheader("多模态学习记录")
                st.markdown("**实验报告辅导**")
                for rp in data.get("report_submissions") or []:
                    st.markdown(f"- {rp['title'][:30]}｜{rp.get('overall_level') or '待评估'}")
                st.markdown("**AI批改作业**")
                for ap in data.get("assignment_submissions") or []:
                    st.markdown(f"- {ap['title'][:24]}｜{ap.get('ai_score') or 0} 分｜{ap.get('overall_level') or '待评估'}")
                st.markdown("**图表题分析**")
                for cp in data.get("chart_analysis_records") or []:
                    st.markdown(f"- {cp['title'][:24]}｜{cp.get('chart_type') or '图表题'}｜{'、'.join(cp.get('knowledge_points') or []) or '无'}")
        else:
            st.error(msg)


def render_teacher_task(token: str):
    render_top_header("教师端｜发布任务", "围绕项目管理案例、图表题和实验报告向学生布置任务。")
    left, right = st.columns([1, 1.4], gap="large")
    with left:
        with st.form("teacher_task"):
            student_id = st.number_input("学生 ID", min_value=1, value=1, step=1)
            title = st.text_input("任务标题", value="网络图与关键路径专项练习")
            description = st.text_area("任务说明", value="完成 2 道关键路径计算题，并提交解题过程与结论。")
            submitted = st.form_submit_button("发布任务")
            if submitted:
                ok_flag, _, msg = normalize_resp(api_post("/api/teacher/tasks", {"student_id": int(student_id), "title": title, "description": description}, token))
                st.success(msg) if ok_flag else st.error(msg)
                if ok_flag:
                    st.rerun()
    with right:
        ok_flag, data, msg = normalize_resp(api_get("/api/teacher/tasks", token))
        if ok_flag:
            for t in data or []:
                st.markdown(f"<div class='soft-card'><b>{t['title']}</b><br>学生 ID：{t['student_id']}<br>状态：{t['status']}<br><br>{t.get('description') or ''}</div>", unsafe_allow_html=True)
        else:
            st.error(msg)


def render_teacher_kp(token: str):
    render_top_header("教师端｜课程知识库与题库", "上传《软件项目管理》资料、导入题库，并构建课程知识图谱。")
    tab1, tab2, tab3, tab4 = st.tabs(["📚 课程资料", "🗂️ 题库导入", "💡 知识点", "🧠 知识图谱"])
    with tab1:
        left, right = st.columns([1.1, 1.6], gap="large")
        with left:
            st.subheader("上传课程文档")
            title = st.text_input("资料标题", placeholder="例如：第4章 进度管理讲义")
            source_label = st.text_input("知识库名称", value="软件项目管理课程库")
            uploaded = st.file_uploader("选择文件", type=["pdf", "docx", "txt", "md", "pptx"])
            if st.button("上传并入库", use_container_width=True):
                if uploaded and title.strip():
                    ok_flag, data, msg = normalize_resp(api_post_file("/api/teacher/knowledge-documents/upload", {"title": title, "subject": SUBJECT, "source_label": source_label}, "file", (uploaded.name, uploaded.getvalue(), uploaded.type or "application/octet-stream"), token))
                    if ok_flag:
                        st.success(f"{msg}，共切分 {data.get('chunk_count', 0)} 个文本块。")
                        st.rerun()
                    else:
                        st.error(msg)
                else:
                    st.warning("请先填写资料标题并选择文件。")
        with right:
            st.subheader("已上传资料")
            ok_flag, data, msg = normalize_resp(api_get("/api/teacher/knowledge-documents", token))
            if ok_flag:
                for item in data or []:
                    col1, col2 = st.columns([4, 1])
                    with col1:
                        st.markdown(f"<div class='soft-card'><b>{item['title']}</b><br>课程：{item['subject']} ｜ 知识库：{item['source_label']}<br>文件：{item['file_name']} ｜ 类型：{item['file_type']} ｜ 切片数：{item['chunk_count']}</div>", unsafe_allow_html=True)
                    with col2:
                        if st.button("删除", key=f"teacher_del_doc_{item['id']}", use_container_width=True):
                            ok_flag2, _, msg2 = normalize_resp(api_delete(f"/api/teacher/knowledge-documents/{item['id']}", token))
                            st.success(msg2) if ok_flag2 else st.error(msg2)
                            if ok_flag2:
                                st.rerun()
            else:
                st.error(msg)
    with tab2:
        left, right = st.columns([1.05, 1.75], gap="large")
        with left:
            st.subheader("导入题库文件")
            st.caption("支持 csv / xlsx / json / txt。可导入单选题、多选题、判断题、计算题、简答题；建议列名：章节、题型、题目、正确答案、解析、知识点、A/B/C/D。")
            q_source_label = st.text_input("题库来源标识", value="教师导入题库")
            q_file = st.file_uploader("选择题库文件", type=["csv", "xlsx", "json", "txt"], key="teacher_qbank_upload")
            if st.button("开始导入题库", key="teacher_import_qbank", use_container_width=True):
                if q_file:
                    ok_flag, data, msg = normalize_resp(api_post_file("/api/teacher/practice-questions/import", {"subject": SUBJECT, "source_label": q_source_label}, "file", (q_file.name, q_file.getvalue(), q_file.type or "application/octet-stream"), token))
                    if ok_flag:
                        st.success(f"{msg}：新增 {data.get('created_count', 0)} 题，跳过 {data.get('skipped_count', 0)} 题。")
                        if data.get('upload_path'):
                            st.caption(f"原始文件已保存到：{data.get('upload_path')}")
                        if data.get('parsed_path'):
                            st.caption(f"解析结果已保存到：{data.get('parsed_path')}")
                        if data.get('errors'):
                            st.warning("部分行有问题：" + "；".join(data.get('errors')[:5]))
                    else:
                        st.error(msg)
                else:
                    st.warning("请先选择题库文件。")
        with right:
            st.subheader("最近题库内容")
            ok_flag, questions, msg = normalize_resp(api_get("/api/teacher/practice-questions", token))
            if ok_flag:
                st.caption(f"当前可见题目数：{len(questions or [])}（最多展示 200 条）")
                for item in (questions or [])[:20]:
                    st.markdown(f"<div class='soft-card'><b>{item['chapter']}｜{item.get('difficulty','适中')}｜{item['question_type']}</b><br>{item['question_text'][:120]}<br>答案：{item['correct_answer']} ｜ 知识点：{'、'.join(item.get('knowledge_points') or []) or '无'}<br>来源：{item.get('source_label') or '未标注'}</div>", unsafe_allow_html=True)
            else:
                st.error(msg)
    with tab3:
        left, right = st.columns([1, 1.5], gap="large")
        with left:
            with st.form("kp_form"):
                name = st.text_input("知识点名称", placeholder="例如：挣值分析")
                difficulty = st.selectbox("难度", ["easy", "medium", "hard"], index=1)
                description = st.text_area("知识点描述", placeholder="例如：理解 EV/PV/AC 与 CV、SV、CPI、SPI 的含义和计算")
                submitted = st.form_submit_button("新增知识点")
                if submitted:
                    ok_flag, _, msg = normalize_resp(api_post("/api/teacher/knowledge-points", {"name": name, "subject": SUBJECT, "description": description, "difficulty": difficulty}, token))
                    st.success(msg) if ok_flag else st.error(msg)
                    if ok_flag:
                        st.rerun()
        with right:
            ok_flag, data, msg = normalize_resp(api_get("/api/teacher/knowledge-points", token))
            if ok_flag:
                for k in data or []:
                    st.markdown(f"<div class='soft-card'><b>{k['name']}</b><br>课程：{k['subject']} ｜ 难度：{k['difficulty']}<br>{k.get('description') or ''}</div>", unsafe_allow_html=True)
            else:
                st.error(msg)
    with tab4:
        left, right = st.columns([1.1, 1.6], gap="large")
        with left:
            ok_flag, docs, msg = normalize_resp(api_get("/api/teacher/knowledge-documents", token))
            doc_options = {f"#{d['id']}｜{d['title']}": d['id'] for d in (docs or [])} if ok_flag else {}
            graph_name = st.text_input("图谱名称", value="软件项目管理课程知识图谱")
            selected = st.multiselect("选择构图资料", list(doc_options.keys()))
            if st.button("开始构建图谱", use_container_width=True):
                doc_ids = [doc_options[x] for x in selected] if selected else []
                ok_flag2, data, msg2 = normalize_resp(api_post("/api/teacher/knowledge-graphs/build", {"graph_name": graph_name, "subject": SUBJECT, "document_ids": doc_ids}, token))
                st.success(f"{msg2}：节点 {data.get('node_count', 0)}，关系 {data.get('edge_count', 0)}") if ok_flag2 else st.error(msg2)
                if ok_flag2:
                    st.rerun()
        with right:
            ok_flag, graphs, msg = normalize_resp(api_get("/api/teacher/knowledge-graphs", token))
            if ok_flag:
                for g in graphs or []:
                    col1, col2 = st.columns([4, 1])
                    with col1:
                        st.markdown(f"<div class='soft-card'><b>{g['name']}</b><br>节点：{g['node_count']} ｜ 关系：{g['edge_count']}<br>来源：{'、'.join(g.get('source_titles') or []) or '未记录'}</div>", unsafe_allow_html=True)
                    with col2:
                        if st.button("删除", key=f"teacher_del_graph_{g['id']}", use_container_width=True):
                            ok_flag2, _, msg2 = normalize_resp(api_delete(f"/api/teacher/knowledge-graphs/{g['id']}", token))
                            st.success(msg2) if ok_flag2 else st.error(msg2)
                            if ok_flag2:
                                st.rerun()
            else:
                st.error(msg)

