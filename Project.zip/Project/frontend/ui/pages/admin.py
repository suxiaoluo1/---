import json
import streamlit as st
from ..api import api_delete, api_get, api_post, api_post_file, api_put, normalize_resp
from ..components import render_metric_card, render_top_header

SUBJECT = "软件项目管理"


def render_admin_overview(token: str):
    render_top_header("管理员端｜系统概览", "查看软件项目管理学习助手的整体运行数据。")
    ok_flag, data, msg = normalize_resp(api_get("/api/admin/overview", token))
    if not ok_flag:
        st.error(msg)
        return

    user_stats = data.get("user_stats") or {}
    content_stats = data.get("content_stats") or {}
    activity_stats = data.get("weekly_activity") or {}

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("用户总数", user_stats.get("total_users", 0))
    c2.metric("学生 / 教师", f"{user_stats.get('student_count', 0)} / {user_stats.get('teacher_count', 0)}")
    c3.metric("题库总题数", content_stats.get("total_questions", 0))
    c4.metric("知识库文档数", content_stats.get("knowledge_document_count", 0))

    c5, c6, c7, c8 = st.columns(4)
    c5.metric("本周练习次数", activity_stats.get("practice_count", 0))
    c6.metric("本周错题数", activity_stats.get("wrong_question_count", 0))
    c7.metric("实验报告辅导", activity_stats.get("report_guidance_count", 0))
    c8.metric("AI批改/图表分析", f"{activity_stats.get('assignment_grading_count', 0)} / {activity_stats.get('chart_analysis_count', 0)}")

    left, right = st.columns(2)
    with left:
        st.subheader("高频错题章节")
        for item in activity_stats.get("high_frequency_wrong_chapters") or []:
            st.markdown(f"- {item.get('chapter')}｜错题 {item.get('wrong_count')} 次")
    with right:
        st.subheader("系统辅助信息")
        st.markdown(f"- 知识图谱数：{content_stats.get('knowledge_graph_count', 0)}")
        st.markdown(f"- 学习路径数：{content_stats.get('learning_path_count', 0)}")
        st.markdown(f"- 聊天历史条数：{activity_stats.get('chat_history_count', 0)}")


def render_admin_users(token: str):
    render_top_header("管理员端｜用户管理", "支持学生、教师、管理员的新增、修改、删除。")
    tab1, tab2 = st.tabs(["👥 用户列表", "✏️ 编辑/删除"])
    with tab1:
        role_filter = st.selectbox("按角色筛选", ["all", "student", "teacher", "admin"], format_func=lambda x: {"all": "全部", "student": "学生", "teacher": "教师", "admin": "管理员"}[x])
        path = "/api/admin/users" if role_filter == "all" else f"/api/admin/users?role={role_filter}"
        ok_flag, data, msg = normalize_resp(api_get(path, token))
        if ok_flag:
            cols = st.columns(2)
            for idx, u in enumerate(data):
                with cols[idx % 2]:
                    st.markdown(
                        f"<div class='soft-card'><b>{u['username']}</b> ｜ {u['role']}<br>姓名：{u.get('full_name') or ''}<br>年级/班级：{u.get('grade') or ''} / {u.get('class_name') or ''}<br>课程：{u.get('subject') or ''}<br>ID：{u['id']}</div>",
                        unsafe_allow_html=True,
                    )
        else:
            st.error(msg)
    with tab2:
        ok_flag, users, msg = normalize_resp(api_get("/api/admin/users", token))
        if not ok_flag:
            st.error(msg)
            return
        options = {f"#{u['id']}｜{u['username']}｜{u['role']}": u for u in users}
        selected_label = st.selectbox("选择要编辑的用户", list(options.keys())) if options else None
        if not selected_label:
            st.info("暂无用户。")
            return
        selected = options[selected_label]
        left, right = st.columns(2, gap="large")
        with left:
            st.subheader("修改用户信息")
            with st.form("admin_update_user"):
                full_name = st.text_input("姓名", value=selected.get("full_name") or "")
                grade = st.text_input("年级", value=selected.get("grade") or "")
                class_name = st.text_input("班级", value=selected.get("class_name") or "")
                subject = st.text_input("课程", value=selected.get("subject") or "")
                password = st.text_input("重置密码（可留空）", type="password")
                submitted = st.form_submit_button("保存修改", use_container_width=True)
                if submitted:
                    ok_flag, _, msg = normalize_resp(api_put(f"/api/admin/users/{selected['id']}", {
                        "full_name": full_name,
                        "grade": grade,
                        "class_name": class_name,
                        "subject": subject,
                        "password": password or None,
                    }, token))
                    st.success(msg) if ok_flag else st.error(msg)
                    if ok_flag:
                        st.rerun()
        with right:
            st.subheader("删除用户")
            st.warning("删除后不可恢复，请谨慎操作。")
            if st.button("删除该用户", use_container_width=True):
                ok_flag, _, msg = normalize_resp(api_delete(f"/api/admin/users/{selected['id']}", token))
                st.success(msg) if ok_flag else st.error(msg)
                if ok_flag:
                    st.rerun()


def render_admin_create_user(token: str):
    render_top_header("管理员端｜新增用户", "创建软件项目管理课程的学生、教师或管理员账号。")
    with st.form("admin_create_user"):
        username = st.text_input("用户名")
        password = st.text_input("密码", type="password")
        role = st.selectbox("角色", ["student", "teacher", "admin"])
        full_name = st.text_input("姓名")
        grade = st.text_input("年级（学生可填）")
        class_name = st.text_input("班级（学生可填）")
        subject = st.text_input("课程（教师可填）", value=SUBJECT)
        submitted = st.form_submit_button("创建用户")
        if submitted:
            ok_flag, _, msg = normalize_resp(api_post("/api/admin/users", {"username": username, "password": password, "role": role, "full_name": full_name, "grade": grade, "class_name": class_name, "subject": subject}, token))
            st.success(msg) if ok_flag else st.error(msg)


def render_admin_knowledge_center(token: str):
    render_top_header("管理员端｜知识库、图谱与题库", "管理员可统一上传资料、构建图谱，并对专项练习题库进行管理。")
    tab1, tab2, tab3 = st.tabs(["📚 知识库文件", "🧠 知识图谱", "🗂️ 题库管理"])
    with tab1:
        left, right = st.columns([1.1, 1.6], gap="large")
        with left:
            title = st.text_input("资料标题", key="admin_doc_title")
            source_label = st.text_input("知识库名称", value="软件项目管理课程库", key="admin_source_label")
            uploaded = st.file_uploader("选择文件", type=["pdf", "docx", "txt", "md", "pptx"], key="admin_doc_upload")
            if st.button("上传并入库", key="admin_upload_btn", use_container_width=True):
                if uploaded and title.strip():
                    ok_flag, data, msg = normalize_resp(api_post_file("/api/admin/knowledge-documents/upload", {"title": title, "subject": SUBJECT, "source_label": source_label}, "file", (uploaded.name, uploaded.getvalue(), uploaded.type or "application/octet-stream"), token))
                    st.success(f"{msg}，共切分 {data.get('chunk_count', 0)} 个文本块。") if ok_flag else st.error(msg)
                    if ok_flag:
                        st.rerun()
                else:
                    st.warning("请先填写资料标题并选择文件。")
        with right:
            ok_flag, docs, msg = normalize_resp(api_get("/api/admin/knowledge-documents", token))
            if ok_flag:
                for item in docs or []:
                    col1, col2 = st.columns([4, 1])
                    with col1:
                        st.markdown(f"<div class='soft-card'><b>{item['title']}</b><br>课程：{item['subject']} ｜ 知识库：{item['source_label']}<br>文件：{item['file_name']} ｜ 类型：{item['file_type']} ｜ 切片数：{item['chunk_count']}</div>", unsafe_allow_html=True)
                    with col2:
                        if st.button("删除", key=f"del_doc_{item['id']}", use_container_width=True):
                            ok_flag2, _, msg2 = normalize_resp(api_delete(f"/api/admin/knowledge-documents/{item['id']}", token))
                            st.success(msg2) if ok_flag2 else st.error(msg2)
                            if ok_flag2:
                                st.rerun()
            else:
                st.error(msg)
    with tab2:
        left, right = st.columns([1.1, 1.6], gap="large")
        with left:
            ok_flag, docs, msg = normalize_resp(api_get("/api/admin/knowledge-documents", token))
            doc_options = {f"#{d['id']}｜{d['title']}": d['id'] for d in (docs or [])} if ok_flag else {}
            graph_name = st.text_input("图谱名称", value="软件项目管理课程知识图谱", key="admin_graph_name")
            selected = st.multiselect("选择构图资料", list(doc_options.keys()), key="admin_graph_docs")
            if st.button("开始构建图谱", key="admin_build_graph", use_container_width=True):
                doc_ids = [doc_options[x] for x in selected] if selected else []
                ok_flag2, data, msg2 = normalize_resp(api_post("/api/admin/knowledge-graphs/build", {"graph_name": graph_name, "subject": SUBJECT, "document_ids": doc_ids}, token))
                st.success(f"{msg2}：节点 {data.get('node_count', 0)}，关系 {data.get('edge_count', 0)}") if ok_flag2 else st.error(msg2)
                if ok_flag2:
                    st.rerun()
        with right:
            ok_flag, graphs, msg = normalize_resp(api_get("/api/admin/knowledge-graphs", token))
            if ok_flag:
                for g in graphs or []:
                    col1, col2 = st.columns([4, 1])
                    with col1:
                        st.markdown(f"<div class='soft-card'><b>{g['name']}</b><br>节点：{g['node_count']} ｜ 关系：{g['edge_count']}<br>来源：{'、'.join(g.get('source_titles') or []) or '未记录'}</div>", unsafe_allow_html=True)
                    with col2:
                        if st.button("删除", key=f"del_graph_{g['id']}", use_container_width=True):
                            ok_flag2, _, msg2 = normalize_resp(api_delete(f"/api/admin/knowledge-graphs/{g['id']}", token))
                            st.success(msg2) if ok_flag2 else st.error(msg2)
                            if ok_flag2:
                                st.rerun()
            else:
                st.error(msg)
    with tab3:
        sub1, sub2, sub3 = st.tabs(["批量导入", "新增/编辑", "列表与删除"])
        with sub1:
            st.caption("支持 csv / xlsx / json / txt。可导入单选题、多选题、判断题、计算题、简答题；建议列名：章节、题型、题目、正确答案、解析、知识点、A/B/C/D。")
            import_source = st.text_input("导入来源标识", value="管理员导入题库", key="admin_q_import_source")
            q_file = st.file_uploader("选择题库文件", type=["csv", "xlsx", "json", "txt"], key="admin_q_upload")
            if st.button("导入题库", key="admin_import_qbank", use_container_width=True):
                if q_file:
                    ok_flag, data, msg = normalize_resp(api_post_file("/api/admin/practice-questions/import", {"subject": SUBJECT, "source_label": import_source}, "file", (q_file.name, q_file.getvalue(), q_file.type or "application/octet-stream"), token))
                    if ok_flag:
                        st.success(f"{msg}：新增 {data.get('created_count', 0)} 题，跳过 {data.get('skipped_count', 0)} 题。")
                        if data.get('upload_path'):
                            st.caption(f"原始文件已保存到：{data.get('upload_path')}")
                        if data.get('parsed_path'):
                            st.caption(f"解析结果已保存到：{data.get('parsed_path')}")
                        if data.get('errors'):
                            st.warning("部分行有问题：" + "；".join(data.get('errors')[:5]))
                        st.rerun()
                    else:
                        st.error(msg)
                else:
                    st.warning("请先选择题库文件。")
        with sub2:
            ok_flag, questions, msg = normalize_resp(api_get("/api/admin/practice-questions", token))
            if not ok_flag:
                st.error(msg)
            else:
                options = {f"#{q['id']}｜{q['chapter']}｜{q['question_text'][:20]}": q for q in questions or []}
                selected_label = st.selectbox("选择要编辑的题目（不选可直接新增）", ["新增题目"] + list(options.keys()), key="admin_q_select")
                selected = None if selected_label == "新增题目" else options[selected_label]
                default_options = selected.get('options') if selected else None
                default_text = json.dumps(default_options, ensure_ascii=False) if default_options else '{"A":"","B":"","C":"","D":""}'
                with st.form("admin_question_form"):
                    chapter = st.text_input("章节", value=selected.get('chapter') if selected else "")
                    difficulty = st.selectbox("难度", ["简单", "适中", "困难"], index=["简单", "适中", "困难"].index(selected.get('difficulty')) if selected and selected.get('difficulty') in ["简单", "适中", "困难"] else 1)
                    question_type = st.selectbox("题型", ["单选题", "多选题", "判断题", "计算题", "简答题"], index=["单选题", "多选题", "判断题", "计算题", "简答题"].index(selected.get('question_type')) if selected and selected.get('question_type') in ["单选题", "多选题", "判断题", "计算题", "简答题"] else 0)
                    question_text = st.text_area("题目", value=selected.get('question_text') if selected else "", height=120)
                    options_text = st.text_area("选项 JSON（简答题可留空）", value=default_text, height=120)
                    correct_answer = st.text_input("正确答案", value=selected.get('correct_answer') if selected else "")
                    analysis = st.text_area("解析", value=selected.get('analysis') if selected else "", height=120)
                    knowledge_points = st.text_input("知识点（用顿号、逗号或分号分隔）", value='、'.join(selected.get('knowledge_points') or []) if selected else "")
                    source_label = st.text_input("来源", value=selected.get('source_label') if selected else "管理员录入")
                    submitted = st.form_submit_button("保存题目", use_container_width=True)
                    if submitted:
                        try:
                            parsed_options = json.loads(options_text) if options_text.strip() else None
                        except Exception:
                            st.error("选项 JSON 格式不正确。")
                            parsed_options = None
                        if question_type == "简答题" and not options_text.strip():
                            parsed_options = None
                        if parsed_options is not None or question_type == "简答题":
                            payload = {
                                "subject": SUBJECT,
                                "chapter": chapter,
                                "difficulty": difficulty,
                                "question_type": question_type,
                                "question_text": question_text,
                                "options": parsed_options,
                                "correct_answer": correct_answer,
                                "analysis": analysis,
                                "knowledge_points": [x.strip() for x in knowledge_points.replace('；', ',').replace(';', ',').replace('、', ',').split(',') if x.strip()],
                                "source_label": source_label,
                            }
                            if selected:
                                ok_flag2, _, msg2 = normalize_resp(api_put(f"/api/admin/practice-questions/{selected['id']}", payload, token))
                            else:
                                ok_flag2, _, msg2 = normalize_resp(api_post("/api/admin/practice-questions", payload, token))
                            st.success(msg2) if ok_flag2 else st.error(msg2)
                            if ok_flag2:
                                st.rerun()
        with sub3:
            ok_meta, meta, meta_msg = normalize_resp(api_get("/api/admin/practice-questions/meta", token))
            source_options = ["全部来源"] + (meta.get("source_labels") if ok_meta and meta else [])
            chapter_options = ["全部章节"] + (meta.get("chapters") if ok_meta and meta else [])

            st.subheader("批量清理题库")
            c0, c1, c2 = st.columns([1.4, 1.4, 1])
            with c0:
                bulk_source = st.selectbox("按来源删除", source_options, key="admin_bulk_source")
            with c1:
                bulk_chapter = st.selectbox("按章节删除", chapter_options, key="admin_bulk_chapter")
            with c2:
                delete_all = st.checkbox("删除全部题目", key="admin_bulk_delete_all")
            cascade_records = st.checkbox("同步删除相关练习记录", value=True, key="admin_bulk_cascade")
            st.caption("批量删除会同时清理这些题目的练习记录，避免外键冲突。")
            c3, c4 = st.columns(2)
            with c3:
                if st.button("批量删除匹配题目", key="admin_bulk_delete_btn", use_container_width=True):
                    payload = {
                        "source_label": None if bulk_source == "全部来源" else bulk_source,
                        "chapter": None if bulk_chapter == "全部章节" else bulk_chapter,
                        "delete_all": delete_all,
                        "cascade_records": cascade_records,
                    }
                    ok_flag2, data2, msg2 = normalize_resp(api_post("/api/admin/practice-questions/bulk-delete", payload, token))
                    if ok_flag2:
                        st.success(f"{msg2}：删除题目 {data2.get('deleted_question_count', 0)} 道，同步删除练习记录 {data2.get('deleted_record_count', 0)} 条。")
                        st.rerun()
                    else:
                        st.error(msg2)
            with c4:
                if st.button("按当前条件题库去重", key="admin_bulk_dedupe_btn", use_container_width=True):
                    payload = {
                        "source_label": None if bulk_source == "全部来源" else bulk_source,
                        "chapter": None if bulk_chapter == "全部章节" else bulk_chapter,
                        "cascade_records": cascade_records,
                    }
                    ok_flag2, data2, msg2 = normalize_resp(api_post("/api/admin/practice-questions/deduplicate", payload, token))
                    if ok_flag2:
                        st.success(f"{msg2}：删除重复题目 {data2.get('deleted_question_count', 0)} 道，同步删除练习记录 {data2.get('deleted_record_count', 0)} 条。")
                        st.rerun()
                    else:
                        st.error(msg2)

            st.divider()
            keyword = st.text_input("按题目关键词搜索", key="admin_q_keyword")
            path = "/api/admin/practice-questions" if not keyword else f"/api/admin/practice-questions?keyword={keyword}"
            ok_flag, questions, msg = normalize_resp(api_get(path, token))
            if ok_flag:
                st.caption(f"共展示 {len(questions or [])} 道题（最多 500 条）")
                for item in questions or []:
                    c1, c2 = st.columns([4.2, 1])
                    with c1:
                        st.markdown(f"<div class='soft-card'><b>{item['chapter']}｜{item.get('difficulty','适中')}｜{item['question_type']}</b><br>{item['question_text']}<br>答案：{item['correct_answer']} ｜ 知识点：{'、'.join(item.get('knowledge_points') or []) or '无'}<br>来源：{item.get('source_label') or '未标注'}</div>", unsafe_allow_html=True)
                    with c2:
                        if st.button("删除", key=f"admin_del_question_{item['id']}", use_container_width=True):
                            ok_flag2, data2, msg2 = normalize_resp(api_delete(f"/api/admin/practice-questions/{item['id']}?cascade_records=true", token))
                            if ok_flag2:
                                st.success(f"{msg2}：已删除题目 {data2.get('deleted_question_count', 0)} 道，练习记录 {data2.get('deleted_record_count', 0)} 条。")
                                st.rerun()
                            else:
                                st.error(msg2)
            else:
                st.error(msg)

