
import streamlit as st


def render_top_header(role_text: str, subtitle: str):
    username = st.session_state.get('username', '用户')
    st.markdown(f"""
    <div class="app-header" style="background: linear-gradient(120deg, rgba(37,99,235,0.96), rgba(124,58,237,0.92) 58%, rgba(236,72,153,0.82) 100%); padding: 30px 32px; border-radius: 28px; color: white; margin-bottom: 24px; box-shadow: 0 18px 42px rgba(99, 102, 241, 0.18); position: relative; overflow: hidden;">
        <div style="position:absolute; right:-30px; top:-18px; width:220px; height:220px; border-radius:50%; background:rgba(255,255,255,0.10);"></div>
        <div style="position:absolute; right:130px; bottom:-60px; width:170px; height:170px; border-radius:50%; background:rgba(255,255,255,0.08);"></div>
        <div style="position: relative; z-index: 2;">
            <div style="display:flex; align-items:center; justify-content:space-between; gap: 16px; flex-wrap: wrap;">
                <div>
                    <div style="font-size: 15px; opacity: 0.9; margin-bottom: 8px; font-weight: 700;">多模态融合大语言模型的个性化学习助手</div>
                    <div style="font-size: 31px; font-weight: 900; letter-spacing: -0.5px; line-height: 1.25;">{role_text}</div>
                    <div style="font-size: 15px; opacity: 0.96; margin-top: 10px; max-width: 780px; line-height: 1.7;">{subtitle}</div>
                </div>
                <div style="display:flex; flex-wrap:wrap; gap:8px; align-items:center; justify-content:flex-end;">
                    <span class="hero-chip">🟢 当前在线：{username}</span>
                    <span class="hero-chip">📘 软件项目管理课程</span>
                    <span class="hero-chip">✨ 个性化学习体验</span>
                </div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)


def render_metric_card(label: str, value: str):
    st.markdown(f"""
    <div class="metric-card">
        <div style="color: #64748b; font-size: 14px; margin-bottom: 10px; font-weight: 700;">{label}</div>
        <div style="color: #1e293b; font-size: 30px; font-weight: 900; margin-bottom: 4px;">{value}</div>
        <div style="color:#8a94a8; font-size: 12px;">Keep learning, keep shining ✨</div>
    </div>
    """, unsafe_allow_html=True)
