import os
import requests

API_BASE = os.environ.get("API_BASE", "http://127.0.0.1:8000")


def _safe_json(r: requests.Response):
    try:
        return r.json()
    except ValueError:
        return {
            "success": False,
            "code": r.status_code,
            "message": r.text[:1000] or "后端返回了非 JSON 内容",
            "data": None,
        }


def api_post(path: str, data: dict | None = None, token: str | None = None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    r = requests.post(f"{API_BASE}{path}", json=data or {}, headers=headers, timeout=600)
    return _safe_json(r)


def api_get(path: str, token: str | None = None):
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    r = requests.get(f"{API_BASE}{path}", headers=headers, timeout=120)
    return _safe_json(r)


def normalize_resp(resp):
    if isinstance(resp, dict):
        if resp.get("success") is True or resp.get("code") == 0:
            return True, resp.get("data"), resp.get("message", "success")
        return False, resp.get("data"), resp.get("message", str(resp))
    return False, None, str(resp)


def api_post_file(path: str, data: dict, file_field: str, file_tuple, token: str | None = None):
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    files = {file_field: file_tuple}
    r = requests.post(f"{API_BASE}{path}", data=data, files=files, headers=headers, timeout=600)
    return _safe_json(r)


def api_put(path: str, data: dict, token: str | None = None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    r = requests.put(f"{API_BASE}{path}", json=data, headers=headers, timeout=600)
    return _safe_json(r)


def api_delete(path: str, token: str | None = None):
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    r = requests.delete(f"{API_BASE}{path}", headers=headers, timeout=600)
    return _safe_json(r)


def api_post_multipart(path: str, data: dict, token: str | None = None, files: dict | None = None):
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    r = requests.post(f"{API_BASE}{path}", data=data, files=files or {}, headers=headers, timeout=600)
    return _safe_json(r)
