import streamlit as st


def init_state():
    defaults = {
        "token": None,
        "role": None,
        "username": None,
        "history": [],
        "chat_pending_request": None,
        "graph_selected_node": None,
        "practice_quick_config": None,
        "chat_draft_prompt": None,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v
