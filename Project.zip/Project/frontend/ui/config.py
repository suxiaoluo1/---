# 智能问答隐藏的高级参数配置（对用户透明）
CHAT_ADVANCED_CONFIG = {
    "mode": "step_by_step",      # 默认回答模式：分步解题
    "max_new_tokens": 2048,       # 最大回复长度
    "temperature": 0.7,          # 发散度
    "top_p": 0.9,
    "top_k": 40,
    "num_ctx": 4096              # 上下文窗口大小
}