
from __future__ import annotations

import base64
import mimetypes
from functools import lru_cache
from pathlib import Path


ASSET_DIR = Path(__file__).resolve().parent / "assets"


def asset_path(name: str) -> Path:
    return ASSET_DIR / name


@lru_cache(maxsize=16)
def asset_data_uri(name: str) -> str:
    path = asset_path(name)
    mime = mimetypes.guess_type(str(path))[0] or 'image/png'
    data = base64.b64encode(path.read_bytes()).decode('utf-8')
    return f"data:{mime};base64,{data}"
