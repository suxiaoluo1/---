import io
import os
import base64
from PIL import Image

MAX_SIDE = int(os.environ.get("IMG_MAX_SIDE", "768"))
JPEG_QUALITY = int(os.environ.get("IMG_JPEG_QUALITY", "85"))
DEFAULT_NUM_CTX = int(os.environ.get("OLLAMA_NUM_CTX", "4096"))


def downscale_image(img: Image.Image, max_side: int = MAX_SIDE) -> Image.Image:
    w, h = img.size
    m = max(w, h)
    if m <= max_side:
        return img
    scale = max_side / float(m)
    nw, nh = int(w * scale), int(h * scale)
    return img.resize((nw, nh), Image.BICUBIC)


def image_to_b64_jpeg(img: Image.Image, quality: int = JPEG_QUALITY) -> str:
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=int(quality), optimize=True)
    return base64.b64encode(buf.getvalue()).decode("utf-8")
