
import streamlit as st

from .assets import asset_data_uri


def inject_global_css():
    learning_bg = asset_data_uri('learning_bg.png')
    st.markdown(f"""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');

    html, body, [class*="css"]  {{ font-family: 'Inter', 'PingFang SC', 'Microsoft YaHei', sans-serif; }}
    .stApp {{
        background:
            radial-gradient(circle at top right, rgba(255,255,255,0.92), rgba(255,255,255,0.72) 38%, rgba(245,247,255,0.93) 72%),
            url('{learning_bg}') center top / cover fixed no-repeat,
            linear-gradient(180deg, #eef4ff 0%, #f8f7ff 48%, #f9fbff 100%);
        color: #1f2a44;
    }}
    header[data-testid="stHeader"] {{ background: transparent !important; }}
    [data-testid="stDecoration"] {{ display: none !important; }}
    #MainMenu {{visibility: hidden;}} footer {{visibility: hidden;}}
    .block-container {{ padding-top: 1.4rem !important; padding-bottom: 120px !important; max-width: 1240px !important; margin: 0 auto; }}

    section[data-testid="stSidebar"] {{
        background: linear-gradient(180deg, rgba(255,255,255,0.96) 0%, rgba(245,248,255,0.97) 100%) !important;
        border-right: 1px solid rgba(191, 219, 254, 0.55) !important;
        backdrop-filter: blur(10px) !important;
    }}
    section[data-testid="stSidebar"] button[kind="secondary"] {{
        background: rgba(255,255,255,0.65) !important;
        color: #55637f !important;
        border: 1px solid rgba(209, 223, 245, 0.8) !important;
        box-shadow: 0 6px 18px rgba(132, 145, 178, 0.05) !important;
        justify-content: flex-start !important;
        font-weight: 700 !important;
        font-size: 15px !important;
        border-radius: 16px !important;
        padding: 12px 16px !important;
        margin-bottom: 8px !important;
        transition: all 0.22s ease !important;
    }}
    section[data-testid="stSidebar"] button[kind="secondary"]:hover {{
        background: rgba(239, 246, 255, 0.95) !important;
        color: #2563eb !important;
        transform: translateX(4px) translateY(-1px);
        border-color: rgba(147, 197, 253, 0.95) !important;
    }}
    section[data-testid="stSidebar"] button[kind="primary"] {{
        background: linear-gradient(135deg, rgba(240,249,255,0.98), rgba(238,242,255,0.98)) !important;
        color: #1d4ed8 !important;
        border: 1px solid rgba(147, 197, 253, 0.85) !important;
        border-left: 5px solid #3b82f6 !important;
        border-radius: 18px !important;
        box-shadow: 0 10px 26px rgba(59, 130, 246, 0.12) !important;
        justify-content: flex-start !important;
        font-weight: 900 !important;
        font-size: 15px !important;
        padding: 12px 16px !important;
    }}

    div[data-testid="stVerticalBlockBorderWrapper"] {{
        background: linear-gradient(180deg, rgba(255,255,255,0.96), rgba(255,255,255,0.92)) !important;
        border-radius: 24px !important;
        border: 1px solid rgba(224, 232, 255, 0.92) !important;
        box-shadow: 0 12px 34px rgba(99, 102, 241, 0.06) !important;
        transition: transform 0.25s ease, box-shadow 0.25s ease !important;
    }}
    div[data-testid="stVerticalBlockBorderWrapper"]:hover {{
        transform: translateY(-2px);
        box-shadow: 0 16px 40px rgba(99, 102, 241, 0.08) !important;
    }}

    .metric-card {{
        background: linear-gradient(180deg, rgba(255,255,255,0.98), rgba(247,250,255,0.95));
        padding: 22px 18px; border-radius: 22px;
        border: 1px solid rgba(225, 233, 255, 0.9);
        box-shadow: 0 8px 24px rgba(99,102,241,0.08);
        text-align: center;
        transition: transform 0.25s ease, box-shadow 0.25s ease;
        min-height: 120px;
    }}
    .metric-card:hover {{ transform: translateY(-4px); box-shadow: 0 18px 32px rgba(99,102,241,0.12); }}

    .soft-card {{
        background: linear-gradient(180deg, rgba(255,255,255,0.98), rgba(248,250,255,0.94));
        border-radius: 22px;
        border: 1px solid rgba(226, 232, 255, 0.95);
        padding: 18px 18px;
        margin-bottom: 16px;
        box-shadow: 0 10px 24px rgba(148, 163, 184, 0.08);
    }}

    .glass-panel {{
        background: linear-gradient(135deg, rgba(255,255,255,0.94), rgba(255,255,255,0.72));
        backdrop-filter: blur(12px);
        border-radius: 28px;
        border: 1px solid rgba(219, 234, 254, 0.88);
        padding: 20px 22px;
        box-shadow: 0 15px 30px rgba(99, 102, 241, 0.09);
    }}

    .panel-title {{ font-size: 18px; font-weight: 900; color: #1f2a44; margin-bottom: 8px; }}
    .panel-subtitle {{ color: #64748b; font-size: 13px; line-height: 1.65; }}

    .practice-shell {{
        background: linear-gradient(180deg, rgba(255,255,255,0.98), rgba(250,251,255,0.96));
        border-radius: 30px;
        border: 1px solid rgba(219, 234, 254, 0.96);
        padding: 24px;
        box-shadow: 0 18px 40px rgba(59, 130, 246, 0.10);
    }}
    .hero-chip {{
        display: inline-flex; align-items: center; gap: 8px; padding: 7px 14px;
        border-radius: 999px; background: rgba(255,255,255,0.72); border: 1px solid rgba(255,255,255,0.92);
        font-size: 13px; font-weight: 700; color: #415071; margin-right: 8px; margin-bottom: 8px;
    }}
    .status-pill {{ display:inline-block; padding: 4px 10px; border-radius:999px; font-weight:800; font-size:12px; }}
    .status-started {{ color:#2563eb; background:#dbeafe; }}
    .status-review {{ color:#b45309; background:#fef3c7; }}
    .status-empty {{ color:#64748b; background:#f1f5f9; }}
    .status-good {{ color:#047857; background:#d1fae5; }}

    .chapter-progress-card {{
        background: linear-gradient(180deg, rgba(255,255,255,0.96), rgba(248,250,255,0.92));
        border: 1px solid rgba(226, 232, 255, 0.95);
        border-radius: 20px;
        padding: 14px 16px;
        margin-bottom: 12px;
        box-shadow: 0 8px 18px rgba(148, 163, 184, 0.07);
    }}
    .summary-banner {{
        background: linear-gradient(135deg, #eef4ff 0%, #f7f0ff 100%);
        border: 1px solid rgba(196, 181, 253, 0.55);
        border-radius: 24px;
        padding: 18px 20px;
        box-shadow: 0 10px 24px rgba(167, 139, 250, 0.10);
    }}
    .exam-banner {{
        background: linear-gradient(120deg, rgba(37,99,235,0.95), rgba(124,58,237,0.92) 55%, rgba(236,72,153,0.84) 100%);
        color: white; padding: 24px 26px; border-radius: 28px; box-shadow: 0 20px 40px rgba(99,102,241,0.18);
        margin-bottom: 18px;
    }}

    .stButton > button {{
        border-radius: 16px !important;
        border: 1px solid rgba(191, 219, 254, 0.95) !important;
        font-weight: 800 !important;
        transition: all 0.2s ease !important;
    }}
    .stButton > button:hover {{
        transform: translateY(-2px);
        box-shadow: 0 10px 24px rgba(59,130,246,0.12) !important;
    }}

    [data-testid="stChatMessage"] {{ border-radius: 18px; padding: 14px 15px; box-shadow: 0 8px 16px rgba(99,102,241,0.05); }}
    [data-testid="stChatMessage"]:nth-child(even) {{ background: rgba(255,255,255,0.88); border: 1px solid rgba(226,232,240,0.9); }}
    [data-testid="stChatMessage"]:nth-child(odd) {{ background: rgba(240,249,255,0.92); border: 1px solid rgba(191,219,254,0.8); }}
    .stChatInputContainer {{ border-radius: 24px !important; border: 1px solid rgba(191,219,254,0.95) !important; box-shadow: 0 8px 20px rgba(59,130,246,0.08) !important; }}
    </style>
    """, unsafe_allow_html=True)


def inject_login_css():
    login_bg = asset_data_uri('login_bg.png')
    st.markdown(f"""
    <style>
    .block-container {{ max-width: 1450px !important; }}
    [data-testid="stAppViewContainer"] {{
        background:
            linear-gradient(90deg, rgba(236,242,255,0.90), rgba(245,240,255,0.72) 46%, rgba(255,255,255,0.95) 72%),
            url('{login_bg}') no-repeat left center / cover !important;
    }}
    [data-testid="collapsedControl"], section[data-testid="stSidebar"] {{ display: none !important; }}
    div[data-testid="column"]:nth-of-type(2) {{
        background: rgba(255, 255, 255, 0.88);
        padding: 48px 56px; border-radius: 30px;
        box-shadow: 0 25px 50px rgba(80, 89, 135, 0.12);
        backdrop-filter: blur(14px);
        border: 1px solid rgba(255,255,255,0.92);
    }}
    .stTextInput > div > div > input, .stSelectbox div[data-baseweb="select"] > div {{
        border-radius: 16px !important; border: 2px solid #e2e8f0 !important; font-size: 16px !important;
    }}
    .stTextInput > div > div > input:focus {{ border-color: #6366f1 !important; }}
    .stTabs [data-baseweb="tab"] {{ font-size: 20px !important; padding-bottom: 15px !important; font-weight: 800 !important; }}
    .stButton > button {{
        width: 100%; border-radius: 16px !important; border: none !important;
        background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 58%, #ec4899 100%) !important;
        color: white !important; font-weight: 800 !important; font-size: 18px !important;
        padding: 15px 0 !important; margin-top: 15px !important;
    }}
    </style>
    """, unsafe_allow_html=True)
