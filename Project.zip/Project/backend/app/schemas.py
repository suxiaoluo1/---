from pydantic import BaseModel, Field
from typing import List, Optional
from .course_data import COURSE_NAME

class Token(BaseModel):
    access_token: str
    token_type: str
    role: str
    username: str

class UserRegister(BaseModel):
    username: str
    password: str = Field(min_length=6)
    role: str
    full_name: Optional[str] = None
    grade: Optional[str] = None
    class_name: Optional[str] = None
    subject: Optional[str] = None

class UserLogin(BaseModel):
    username: str
    password: str
    role: str

class UserUpdate(BaseModel):
    password: Optional[str] = None
    full_name: Optional[str] = None
    grade: Optional[str] = None
    class_name: Optional[str] = None
    subject: Optional[str] = None

class UserOut(BaseModel):
    id: int
    username: str
    role: str
    full_name: Optional[str] = None
    grade: Optional[str] = None
    class_name: Optional[str] = None
    subject: Optional[str] = None
    class Config:
        from_attributes = True

class LearningPathCreate(BaseModel):
    title: str
    goal: str
    steps: List[str]

class KnowledgePointCreate(BaseModel):
    name: str
    subject: str = COURSE_NAME
    description: Optional[str] = None
    difficulty: str = "medium"

class QuizRecordCreate(BaseModel):
    subject: str = COURSE_NAME
    score: float
    total_score: float
    summary: Optional[str] = None

class WrongQuestionCreate(BaseModel):
    subject: str = COURSE_NAME
    question_text: str
    answer_text: Optional[str] = None
    analysis: Optional[str] = None

class WrongQuestionFromChatCreate(BaseModel):
    subject: str = COURSE_NAME
    question_text: str
    answer_text: Optional[str] = None
    analysis: Optional[str] = None

class TaskCreate(BaseModel):
    student_id: int
    title: str
    description: Optional[str] = None

class ChatHistoryItem(BaseModel):
    role: str
    content: str
    image_b64: Optional[str] = None

class ChatRequest(BaseModel):
    prompt: str
    image_b64: Optional[str] = None
    max_new_tokens: int = 1024
    temperature: float = 0.7
    top_p: float = 0.9
    top_k: int = 40
    num_ctx: int = 8192
    mode: str = "step_by_step"
    subject: Optional[str] = COURSE_NAME
    history: List[ChatHistoryItem] = []

class RAGSourceOut(BaseModel):
    title: str
    source: str
    subject: str
    file_name: Optional[str] = None
    chunk_index: Optional[int] = None

class KnowledgeDocumentOut(BaseModel):
    id: int
    title: str
    subject: str
    source_label: str
    file_name: str
    file_type: str
    chunk_count: int
    created_at: str

class ChatResponse(BaseModel):
    answer: str
    elapsed_seconds: float
    detected_subject: Optional[str] = None
    detected_question_type: Optional[str] = None
    rag_used: bool = False
    rag_sources: List[RAGSourceOut] = []
    knowledge_points: List[str] = []

class KnowledgeGraphBuildRequest(BaseModel):
    graph_name: str
    subject: str = COURSE_NAME
    document_ids: List[int] = []

class KnowledgeGraphNodeOut(BaseModel):
    id: int
    name: str
    category: str
    description: Optional[str] = None
    source_count: int = 0
    status: Optional[str] = None
    mastery_score: Optional[float] = None
    wrong_hits: int = 0
    recent_hits: int = 0
    symbol_size: Optional[int] = None

class KnowledgeGraphEdgeOut(BaseModel):
    id: int
    source: int
    target: int
    relation: str
    weight: float = 1.0
    evidence: Optional[str] = None


class PracticeGenerateRequest(BaseModel):
    chapter: Optional[str] = None
    difficulty: Optional[str] = None
    count: int = Field(default=5, ge=1, le=20)


class PracticeSubmitItem(BaseModel):
    question_id: int
    student_answer: Optional[str] = None


class PracticeSubmitRequest(BaseModel):
    answers: List[PracticeSubmitItem]


class PracticeQuestionCreate(BaseModel):
    subject: str = COURSE_NAME
    chapter: str
    difficulty: str = "适中"
    question_type: str = "单选题"
    question_text: str
    options: Optional[dict] = None
    correct_answer: str
    analysis: Optional[str] = None
    knowledge_points: List[str] = []
    source_label: Optional[str] = "管理员录入"


class PracticeQuestionUpdate(BaseModel):
    subject: Optional[str] = None
    chapter: Optional[str] = None
    difficulty: Optional[str] = None
    question_type: Optional[str] = None
    question_text: Optional[str] = None
    options: Optional[dict] = None
    correct_answer: Optional[str] = None
    analysis: Optional[str] = None
    knowledge_points: Optional[List[str]] = None
    source_label: Optional[str] = None


class ReportGuidanceRequest(BaseModel):
    title: str
    content: str = Field(min_length=20)


class ReportSubmissionOut(BaseModel):
    id: int
    title: str
    content: str
    ai_feedback: Optional[str] = None
    structure_score: Optional[float] = None
    terminology_score: Optional[float] = None
    completeness_score: Optional[float] = None
    overall_level: Optional[str] = None
    created_at: str


class ChartAnalysisOut(BaseModel):
    id: int
    title: str
    chart_type: str
    prompt: Optional[str] = None
    image_path: Optional[str] = None
    ai_feedback: Optional[str] = None
    knowledge_points: List[str] = []
    created_at: str


class PracticeQuestionBulkDeleteRequest(BaseModel):
    ids: Optional[List[int]] = None
    source_label: Optional[str] = None
    chapter: Optional[str] = None
    keyword: Optional[str] = None
    delete_all: bool = False
    cascade_records: bool = True


class PracticeQuestionDeduplicateRequest(BaseModel):
    source_label: Optional[str] = None
    chapter: Optional[str] = None
    cascade_records: bool = True
