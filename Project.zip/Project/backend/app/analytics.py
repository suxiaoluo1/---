from __future__ import annotations

import json
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from typing import Any

from sqlalchemy.orm import Session

from .course_data import POINT_TO_MODULE, infer_points
from .models import (
    AssignmentSubmission,
    ChartAnalysisRecord,
    KnowledgeDocument,
    KnowledgePoint,
    MasteryRecord,
    PracticeQuestion,
    PracticeRecord,
    ReportSubmission,
    User,
    WrongQuestion,
)


def _utc_cutoff(days: int = 7):
    return datetime.utcnow() - timedelta(days=days)


def _safe_json_loads(value: str | None) -> list[str]:
    if not value:
        return []
    try:
        data = json.loads(value)
        if isinstance(data, list):
            return [str(x) for x in data if str(x).strip()]
    except Exception:
        pass
    return []


def summarize_student_learning(db: Session, student_id: int, days: int = 7) -> dict[str, Any]:
    cutoff = _utc_cutoff(days)
    wrongs = (
        db.query(WrongQuestion)
        .filter(WrongQuestion.student_id == student_id, WrongQuestion.created_at >= cutoff)
        .order_by(WrongQuestion.id.desc())
        .all()
    )
    practices = (
        db.query(PracticeRecord)
        .filter(PracticeRecord.student_id == student_id, PracticeRecord.created_at >= cutoff)
        .order_by(PracticeRecord.id.desc())
        .all()
    )
    mastery_rows = (
        db.query(MasteryRecord, KnowledgePoint)
        .join(KnowledgePoint, KnowledgePoint.id == MasteryRecord.knowledge_point_id)
        .filter(MasteryRecord.student_id == student_id)
        .all()
    )

    point_wrong_counter: Counter[str] = Counter()
    point_related_chapters: dict[str, Counter[str]] = defaultdict(Counter)
    for row in wrongs:
        text = "\n".join([row.question_text or "", row.analysis or "", row.answer_text or ""])
        points = infer_points(text)
        for point in points:
            point_wrong_counter[point] += 1
            module = POINT_TO_MODULE.get(point)
            if module:
                point_related_chapters[point][module] += 1

    chapter_stats: dict[str, dict[str, int]] = defaultdict(lambda: {"total": 0, "correct": 0, "wrong": 0})
    point_practice_stats: dict[str, dict[str, int]] = defaultdict(lambda: {"total": 0, "correct": 0, "wrong": 0})
    for row in practices:
        chapter = row.chapter or POINT_TO_MODULE.get(((_safe_json_loads(row.knowledge_points_json) or [None])[0]), "未分类章节")
        chapter_stats[chapter]["total"] += 1
        chapter_stats[chapter]["correct"] += 1 if bool(row.is_correct) else 0
        chapter_stats[chapter]["wrong"] += 0 if bool(row.is_correct) else 1
        points = _safe_json_loads(row.knowledge_points_json) or infer_points("\n".join([row.analysis or "", row.chapter or ""]))
        for point in points:
            point_practice_stats[point]["total"] += 1
            point_practice_stats[point]["correct"] += 1 if bool(row.is_correct) else 0
            point_practice_stats[point]["wrong"] += 0 if bool(row.is_correct) else 1

    weak_points = []
    for point, count in point_wrong_counter.most_common(5):
        practice_total = point_practice_stats[point]["total"]
        practice_correct = point_practice_stats[point]["correct"]
        accuracy = round(practice_correct / practice_total * 100, 1) if practice_total else None
        related_chapter = point_related_chapters[point].most_common(1)[0][0] if point_related_chapters[point] else POINT_TO_MODULE.get(point, "课程综合")
        weak_points.append({
            "knowledge_point": point,
            "wrong_count": int(count),
            "recent_practice_accuracy": accuracy,
            "related_chapter": related_chapter,
            "reason": f"最近{days}天“{point}”相关题目累计出错 {int(count)} 次。",
        })

    weak_chapters = []
    for chapter, stat in chapter_stats.items():
        if stat["total"] <= 0:
            continue
        accuracy = round(stat["correct"] / stat["total"] * 100, 1)
        weak_chapters.append({
            "chapter": chapter,
            "accuracy": accuracy,
            "wrong_count": int(stat["wrong"]),
            "practice_count": int(stat["total"]),
            "reason": f"最近{days}天该章节练习正确率为 {accuracy}%（共 {stat['total']} 题）。",
        })
    weak_chapters.sort(key=lambda x: (x["accuracy"], -x["practice_count"], x["chapter"]))

    lowest_mastery = sorted(
        [
            {
                "knowledge_point": kp.name,
                "mastery_score": round(float(mr.mastery_score or 0.0) * 100, 1),
                "mastery_percent": round(float(mr.mastery_score or 0.0) * 100, 1),
                "module": POINT_TO_MODULE.get(kp.name, kp.subject),
                "reason": f"当前掌握度仅为 {round(float(mr.mastery_score or 0.0) * 100, 1)}%。",
            }
            for mr, kp in mastery_rows
        ],
        key=lambda x: x["mastery_score"],
    )

    return {
        "recent_days": days,
        "top_wrong_knowledge_points": weak_points[:5],
        "low_accuracy_chapters": weak_chapters[:5],
        "lowest_mastery_nodes": lowest_mastery[:5],
    }


def build_practice_summary(result_items: list[dict[str, Any]]) -> dict[str, Any]:
    chapter_stats: dict[str, dict[str, int]] = defaultdict(lambda: {"total": 0, "correct": 0, "wrong": 0})
    point_counter: Counter[str] = Counter()
    question_type_counter: Counter[str] = Counter()
    for item in result_items:
        chapter = item.get("chapter") or "未分类章节"
        chapter_stats[chapter]["total"] += 1
        chapter_stats[chapter]["correct"] += 1 if item.get("is_correct") else 0
        chapter_stats[chapter]["wrong"] += 0 if item.get("is_correct") else 1
        if not item.get("is_correct"):
            point_counter.update(item.get("knowledge_points") or [])
            if item.get("question_type"):
                question_type_counter[item.get("question_type")] += 1

    chapter_breakdown = []
    for chapter, stat in chapter_stats.items():
        accuracy = round(stat["correct"] / stat["total"] * 100, 1) if stat["total"] else 0.0
        chapter_breakdown.append({
            "chapter": chapter,
            "accuracy": accuracy,
            "wrong_count": stat["wrong"],
            "question_count": stat["total"],
        })
    chapter_breakdown.sort(key=lambda x: (x["accuracy"], -x["question_count"], x["chapter"]))

    weak_points = [{"knowledge_point": point, "wrong_count": count} for point, count in point_counter.most_common(5)]
    top_chapter = chapter_breakdown[0]["chapter"] if chapter_breakdown else None
    top_point = weak_points[0]["knowledge_point"] if weak_points else None
    next_actions = []
    if top_point:
        next_actions.append(f"优先复习知识点“{top_point}”，并再做 2~3 道同类题。")
    if top_chapter:
        next_actions.append(f"建议继续做“{top_chapter}”章节专项练习，形成二次巩固。")
    if question_type_counter:
        top_qtype = question_type_counter.most_common(1)[0][0]
        next_actions.append(f"本次失分更多集中在“{top_qtype}”，建议复盘标准作答结构。")
    if not next_actions:
        next_actions.append("本次表现较稳定，建议继续保持并尝试更高难度练习。")

    return {
        "chapter_breakdown": chapter_breakdown,
        "weak_points": weak_points,
        "next_actions": next_actions[:3],
    }


def build_teacher_overview(db: Session, days: int = 7) -> dict[str, Any]:
    cutoff = _utc_cutoff(days)
    students = db.query(User).filter(User.role == "student").all()
    student_ids = [s.id for s in students]
    if not student_ids:
        empty = {
            "student_count": 0,
            "average_accuracy": 0.0,
            "class_average_accuracy": 0.0,
            "weak_chapters": [],
            "top_wrong_points": [],
            "wrong_points_top5": [],
            "recent_report_submitters": 0,
            "recent_report_submission_count": 0,
            "recent_ai_grading_count": 0,
            "recent_practice_count": 0,
        }
        return empty

    practices = db.query(PracticeRecord).filter(PracticeRecord.student_id.in_(student_ids), PracticeRecord.created_at >= cutoff).all()
    wrongs = db.query(WrongQuestion).filter(WrongQuestion.student_id.in_(student_ids), WrongQuestion.created_at >= cutoff).all()
    report_rows = db.query(ReportSubmission).filter(ReportSubmission.student_id.in_(student_ids), ReportSubmission.created_at >= cutoff).all()
    grading_count = db.query(AssignmentSubmission).filter(AssignmentSubmission.student_id.in_(student_ids), AssignmentSubmission.created_at >= cutoff).count()

    chapter_stats: dict[str, dict[str, int]] = defaultdict(lambda: {"total": 0, "correct": 0, "wrong": 0})
    wrong_points = Counter()
    total_correct = 0
    total_count = 0
    for row in practices:
        chapter = row.chapter or "未分类章节"
        chapter_stats[chapter]["total"] += 1
        chapter_stats[chapter]["correct"] += 1 if bool(row.is_correct) else 0
        chapter_stats[chapter]["wrong"] += 0 if bool(row.is_correct) else 1
        total_count += 1
        total_correct += 1 if bool(row.is_correct) else 0
    for row in wrongs:
        wrong_points.update(infer_points("\n".join([row.question_text or "", row.analysis or ""])))

    weak_chapters = []
    for chapter, stat in chapter_stats.items():
        if stat["total"] <= 0:
            continue
        accuracy = round(stat["correct"] / stat["total"] * 100, 1)
        weak_chapters.append({
            "chapter": chapter,
            "accuracy": accuracy,
            "wrong_count": stat["wrong"],
            "practice_count": stat["total"],
        })
    weak_chapters.sort(key=lambda x: (x["accuracy"], -x["practice_count"], x["chapter"]))

    top_wrong_points = [{"knowledge_point": k, "wrong_count": v} for k, v in wrong_points.most_common(5)]
    report_submitters = len({row.student_id for row in report_rows})
    average_accuracy = round(total_correct / total_count * 100, 1) if total_count else 0.0

    return {
        "student_count": len(student_ids),
        "average_accuracy": average_accuracy,
        "class_average_accuracy": average_accuracy,
        "weak_chapters": weak_chapters[:5],
        "top_wrong_points": top_wrong_points,
        "wrong_points_top5": top_wrong_points,
        "recent_report_submitters": report_submitters,
        "recent_report_submission_count": len(report_rows),
        "recent_ai_grading_count": grading_count,
        "recent_practice_count": len(practices),
    }


def build_admin_overview(db: Session, days: int = 7) -> dict[str, Any]:
    cutoff = _utc_cutoff(days)
    practice_rows = db.query(PracticeRecord).filter(PracticeRecord.created_at >= cutoff).all()
    wrong_rows = db.query(WrongQuestion).filter(WrongQuestion.created_at >= cutoff).all()
    report_count = db.query(ReportSubmission).filter(ReportSubmission.created_at >= cutoff).count()
    grading_count = db.query(AssignmentSubmission).filter(AssignmentSubmission.created_at >= cutoff).count()
    chart_count = db.query(ChartAnalysisRecord).filter(ChartAnalysisRecord.created_at >= cutoff).count()
    chapter_counter = Counter()
    for row in practice_rows:
        if not bool(row.is_correct):
            chapter_counter.update([row.chapter or "未分类章节"])
    if not chapter_counter:
        for row in wrong_rows:
            points = infer_points("\n".join([row.question_text or "", row.analysis or ""]))
            if points:
                chapter_counter.update([POINT_TO_MODULE.get(points[0], "课程综合")])

    high_frequency_wrong_chapters = [{"chapter": k, "wrong_count": v} for k, v in chapter_counter.most_common(5)]

    user_stats = {
        "total_users": db.query(User).count(),
        "student_count": db.query(User).filter(User.role == "student").count(),
        "teacher_count": db.query(User).filter(User.role == "teacher").count(),
        "admin_count": db.query(User).filter(User.role == "admin").count(),
    }
    content_stats = {
        "total_questions": db.query(PracticeQuestion).count(),
        "knowledge_document_count": db.query(KnowledgeDocument).count(),
        "knowledge_graph_count": 0,
        "learning_path_count": 0,
    }
    weekly_activity = {
        "practice_count": len(practice_rows),
        "wrong_question_count": len(wrong_rows),
        "report_guidance_count": report_count,
        "assignment_grading_count": grading_count,
        "chart_analysis_count": chart_count,
        "chat_history_count": 0,
        "high_frequency_wrong_chapters": high_frequency_wrong_chapters,
    }

    return {
        "user_stats": user_stats,
        "content_stats": content_stats,
        "weekly_activity": weekly_activity,
        "user_count": user_stats["total_users"],
        "student_count": user_stats["student_count"],
        "teacher_count": user_stats["teacher_count"],
        "admin_count": user_stats["admin_count"],
        "practice_question_count": content_stats["total_questions"],
        "knowledge_document_count": content_stats["knowledge_document_count"],
        "weekly_practice_count": weekly_activity["practice_count"],
        "weekly_wrong_count": weekly_activity["wrong_question_count"],
        "high_frequency_wrong_chapter": high_frequency_wrong_chapters[0]["chapter"] if high_frequency_wrong_chapters else "暂无",
        "recent_report_submission_count": report_count,
        "recent_ai_grading_count": grading_count,
        "recent_chart_analysis_count": chart_count,
    }
