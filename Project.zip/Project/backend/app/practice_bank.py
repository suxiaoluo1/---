from __future__ import annotations

import csv
import io
import json
import re
import uuid
from pathlib import Path
from typing import Any

from openpyxl import load_workbook

from .paths import QUESTION_BANK_PARSED_DIR, QUESTION_BANK_UPLOAD_DIR

REQUIRED_COLUMNS = {
    "chapter": ["chapter", "章节", "所属章节"],
    "question_text": ["question_text", "题目", "题干"],
    "correct_answer": ["correct_answer", "正确答案", "答案", "参考答案"],
}
OPTION_COLUMNS = {
    "question_type": ["question_type", "题型", "题目类型"],
    "difficulty": ["difficulty", "难度"],
    "subject": ["subject", "课程", "学科"],
    "analysis": ["analysis", "解析", "答案解析"],
    "knowledge_points": ["knowledge_points", "知识点", "知识点列表", "考点", "关键词"],
    "source_label": ["source_label", "来源", "题源"],
    "source_chapter": ["source_chapter", "来源章节"],
    "scoring_rule": ["scoring_rule", "判分规则"],
    "options": ["options", "选项"],
    "A": ["A", "option_a", "选项A"],
    "B": ["B", "option_b", "选项B"],
    "C": ["C", "option_c", "选项C"],
    "D": ["D", "option_d", "选项D"],
    "E": ["E", "option_e", "选项E"],
    "F": ["F", "option_f", "选项F"],
}


def _normalize_header_map(headers: list[str]) -> dict[str, str]:
    header_map = {}
    for h in headers:
        key = str(h or "").strip()
        if key:
            header_map[key] = key
    resolved = {}
    for target, aliases in {**REQUIRED_COLUMNS, **OPTION_COLUMNS}.items():
        for alias in aliases:
            if alias in header_map:
                resolved[target] = alias
                break
    return resolved


def normalize_difficulty(value: Any) -> str:
    raw = str(value or "").strip().lower()
    if not raw:
        return "适中"
    if raw in {"easy", "simple", "简单", "容易", "基础"}:
        return "简单"
    if raw in {"medium", "normal", "适中", "中等", "一般"}:
        return "适中"
    if raw in {"hard", "difficult", "困难", "较难", "高难"}:
        return "困难"
    if "简" in raw or "易" in raw:
        return "简单"
    if "难" in raw:
        return "困难"
    return "适中"


def _parse_options(row: dict[str, Any], mapping: dict[str, str]) -> dict[str, str] | None:
    if mapping.get("options") and row.get(mapping["options"]):
        raw = str(row.get(mapping["options"]) or "").strip()
        try:
            data = json.loads(raw)
            if isinstance(data, dict):
                return {str(k).strip(): str(v).strip() for k, v in data.items() if str(v).strip()}
        except Exception:
            opts = {}
            for part in re.split(r"\|\||[;；]\s*", raw):
                if ":" in part:
                    k, v = part.split(":", 1)
                    if k.strip() and v.strip():
                        opts[k.strip()] = v.strip()
            if opts:
                return opts
    opts = {}
    for key in ["A", "B", "C", "D", "E", "F"]:
        alias = mapping.get(key)
        if alias and row.get(alias) not in (None, ""):
            opts[key] = str(row.get(alias)).strip()
    return opts or None


def _parse_knowledge_points(value: Any) -> list[str]:
    if value in (None, ""):
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    raw = str(value).strip()
    try:
        data = json.loads(raw)
        if isinstance(data, list):
            return [str(x).strip() for x in data if str(x).strip()]
    except Exception:
        pass
    for sep in ["；", ";", "、", ",", "|", "/", "\n"]:
        raw = raw.replace(sep, ",")
    return [x.strip() for x in raw.split(",") if x.strip()]


def _infer_question_type(row: dict[str, Any], mapping: dict[str, str], options: dict[str, str] | None) -> str:
    raw_type = str(row.get(mapping.get("question_type", "")) or "").strip()
    if raw_type:
        if "多选" in raw_type:
            return "多选题"
        if "判断" in raw_type:
            return "判断题"
        if "计算" in raw_type:
            return "计算题"
        if any(k in raw_type for k in ["简答", "问答", "案例"]):
            return "简答题"
        if "单选" in raw_type:
            return "单选题"
        return raw_type
    qtext = str(row.get(mapping.get("question_text", "")) or "")
    answer = str(row.get(mapping.get("correct_answer", "")) or "")
    if options:
        norm_answer = re.sub(r"[^A-F]", "", answer.upper())
        return "多选题" if len(set(norm_answer)) > 1 else "单选题"
    if any(token in qtext for token in ["判断", "是否正确", "是否错误"]):
        return "判断题"
    if any(token in qtext for token in ["计算", "求", "工期", "成本", "挣值", "关键路径", "EV", "PV", "AC", "CPI", "SPI"]):
        return "计算题"
    if answer.strip() in {"对", "错", "正确", "错误", "true", "false", "TRUE", "FALSE"}:
        return "判断题"
    return "简答题"


def _validate_and_build(rows: list[dict[str, Any]], default_subject: str, default_source_label: str) -> tuple[list[dict[str, Any]], list[str]]:
    if not rows:
        return [], ["导入文件中没有可用题目数据"]
    mapping = _normalize_header_map(list(rows[0].keys()))
    missing = [k for k in REQUIRED_COLUMNS if k not in mapping]
    if missing:
        return [], [f"缺少必填列：{', '.join(missing)}"]
    items, errors = [], []
    for idx, row in enumerate(rows, 2):
        question_text = str(row.get(mapping["question_text"]) or "").strip()
        answer = str(row.get(mapping["correct_answer"]) or "").strip()
        source_chapter = str(row.get(mapping.get("source_chapter", "")) or row.get("__sheet_name__") or "").strip()
        chapter_value = str(row.get(mapping["chapter"]) or "").strip()
        chapter = source_chapter or chapter_value
        if not question_text or not chapter or not answer:
            errors.append(f"第 {idx} 行存在空字段：章节/题目/答案为必填")
            continue
        options = _parse_options(row, mapping)
        item = {
            "subject": str(row.get(mapping.get("subject", "")) or default_subject).strip() or default_subject,
            "chapter": chapter,
            "difficulty": normalize_difficulty(row.get(mapping.get("difficulty", ""))),
            "question_type": _infer_question_type(row, mapping, options),
            "question_text": question_text,
            "options": options,
            "correct_answer": answer,
            "analysis": str(row.get(mapping.get("analysis", "")) or "").strip() or None,
            "knowledge_points": _parse_knowledge_points(row.get(mapping.get("knowledge_points", ""))),
            "source_label": str(row.get(mapping.get("source_label", "")) or default_source_label).strip() or default_source_label,
            "scoring_rule": str(row.get(mapping.get("scoring_rule", "")) or "").strip() or None,
            "raw_chapter": chapter_value or None,
            "source_chapter": source_chapter or None,
        }
        items.append(item)
    return items, errors


def _parse_txt_blocks(text: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    blocks = [b.strip() for b in re.split(r"\n\s*\n", text) if b.strip()]
    for block in blocks:
        obj: dict[str, Any] = {}
        option_lines = []
        for line in block.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            if re.match(r"^[A-FＡ-Ｆ][\.、:：\s]", stripped):
                option_lines.append(stripped)
                continue
            if "：" in stripped:
                k, v = stripped.split("：", 1)
            elif ":" in stripped:
                k, v = stripped.split(":", 1)
            else:
                if "question_text" not in obj and "题目" not in obj:
                    obj["题目"] = stripped
                continue
            obj[k.strip()] = v.strip()
        for line in option_lines:
            m = re.match(r"^([A-FＡ-Ｆ])[\.、:：\s]+(.+)$", line)
            if m:
                key = m.group(1).upper().translate(str.maketrans("ＡＢＣＤＥＦ", "ABCDEF"))
                obj[key] = m.group(2).strip()
        if obj:
            rows.append(obj)
    return rows


def save_question_import_artifacts(file_bytes: bytes, filename: str, parsed_items: list[dict[str, Any]]) -> dict[str, str]:
    safe_name = re.sub(r"[^\w\-.一-龥]+", "_", Path(filename or "questions").name)
    stored_name = f"{uuid.uuid4().hex}_{safe_name}"
    upload_path = QUESTION_BANK_UPLOAD_DIR / stored_name
    upload_path.write_bytes(file_bytes)
    parsed_name = f"{Path(stored_name).stem}.json"
    parsed_path = QUESTION_BANK_PARSED_DIR / parsed_name
    parsed_path.write_text(json.dumps(parsed_items, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"upload_path": str(upload_path), "parsed_path": str(parsed_path), "stored_name": stored_name}


def parse_question_import(file_bytes: bytes, filename: str, default_subject: str, default_source_label: str) -> tuple[list[dict[str, Any]], list[str]]:
    suffix = Path(filename or "").suffix.lower()
    rows: list[dict[str, Any]] = []
    if suffix == ".csv":
        text = file_bytes.decode("utf-8-sig", errors="ignore")
        rows = list(csv.DictReader(io.StringIO(text)))
    elif suffix == ".xlsx":
        wb = load_workbook(io.BytesIO(file_bytes), read_only=True, data_only=True)
        for ws in wb.worksheets:
            values = list(ws.values)
            if not values:
                continue
            headers = [str(x or "").strip() for x in values[0]]
            if not any(headers):
                continue
            for row_vals in values[1:]:
                item = {headers[i]: row_vals[i] if i < len(row_vals) else None for i in range(len(headers))}
                item["__sheet_name__"] = ws.title.strip()
                if any(v not in (None, "") for v in item.values()):
                    rows.append(item)
    elif suffix == ".json":
        data = json.loads(file_bytes.decode("utf-8", errors="ignore"))
        if isinstance(data, list):
            rows = [x for x in data if isinstance(x, dict)]
        elif isinstance(data, dict) and isinstance(data.get("questions"), list):
            rows = [x for x in data["questions"] if isinstance(x, dict)]
    elif suffix == ".txt":
        text = file_bytes.decode("utf-8", errors="ignore")
        rows = _parse_txt_blocks(text)
    else:
        return [], ["仅支持导入 csv、xlsx、json、txt 格式题库文件"]
    return _validate_and_build(rows, default_subject, default_source_label)
