from __future__ import annotations

from fastapi.responses import JSONResponse


def ok(data=None, message="success"):
    return {"success": True, "code": 0, "message": message, "data": data}


def err_payload(message="error", code=1, data=None):
    return {"success": False, "code": code, "message": message, "data": data}


def err(message="error", code=1, status_code=400, data=None):
    return JSONResponse(status_code=status_code, content=err_payload(message=message, code=code, data=data))
