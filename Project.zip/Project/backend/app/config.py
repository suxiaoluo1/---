from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import field_validator
from typing import List
import json


class Settings(BaseSettings):
    APP_NAME: str = "Personalized Learning Assistant"
    SECRET_KEY: str = "change_me_to_a_secure_random_string"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440

    MYSQL_HOST: str = "127.0.0.1"
    MYSQL_PORT: int = 3306
    MYSQL_USER: str = "spm_user"
    MYSQL_PASSWORD: str = "123456"
    MYSQL_DB: str = "spm_learning_assistant"

    OLLAMA_BASE_URL: str = "http://127.0.0.1:11434"
    OLLAMA_MODEL: str = "qwen2.5vl:7b"

    CORS_ORIGINS: List[str] = ["http://localhost:8501", "http://127.0.0.1:8501"]

    APP_FILES_ROOT: str = r"D:\dev\PythonProject\flies"
    LOCAL_EMBEDDING_MODEL_DIR: str = r"D:\dev\PythonProject\models\text2vec-base-chinese"

    @field_validator("CORS_ORIGINS", mode="before")
    @classmethod
    def parse_origins(cls, v):
        if isinstance(v, str):
            try:
                return json.loads(v)
            except Exception:
                return [i.strip() for i in v.split(",") if i.strip()]
        return v

    @property
    def database_url(self) -> str:
        return (
            f"mysql+pymysql://{self.MYSQL_USER}:{self.MYSQL_PASSWORD}"
            f"@{self.MYSQL_HOST}:{self.MYSQL_PORT}/{self.MYSQL_DB}?charset=utf8mb4"
        )

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )


settings = Settings()
print("DB URL =", settings.database_url)