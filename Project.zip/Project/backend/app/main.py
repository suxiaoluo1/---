from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import inspect, text

from .config import settings
from .database import Base, engine, SessionLocal
from .init_data import seed_data
from .routers import auth, student, teacher, admin, chat, graph
from .utils import err_payload


app = FastAPI(title=settings.APP_NAME)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


Base.metadata.create_all(bind=engine)


def _has_column(inspector, table_name: str, column_name: str) -> bool:
    if not inspector.has_table(table_name):
        return False
    return column_name in {col["name"] for col in inspector.get_columns(table_name)}


def ensure_runtime_schema():
    inspector = inspect(engine)
    dialect_name = engine.dialect.name.lower()
    with engine.begin() as conn:
        # SQLite foreign keys must be enabled explicitly.
        if dialect_name == "sqlite":
            conn.execute(text("PRAGMA foreign_keys=ON"))

        if inspector.has_table("practice_questions") and not _has_column(inspector, "practice_questions", "difficulty"):
            conn.execute(text("ALTER TABLE practice_questions ADD COLUMN difficulty VARCHAR(20) NOT NULL DEFAULT '适中'"))
        if inspector.has_table("practice_records") and not _has_column(inspector, "practice_records", "difficulty"):
            conn.execute(text("ALTER TABLE practice_records ADD COLUMN difficulty VARCHAR(20) NULL"))
        if inspector.has_table("wrong_questions") and not _has_column(inspector, "wrong_questions", "ai_analysis"):
            conn.execute(text("ALTER TABLE wrong_questions ADD COLUMN ai_analysis TEXT NULL"))
        if inspector.has_table("wrong_questions") and not _has_column(inspector, "wrong_questions", "knowledge_points_json"):
            conn.execute(text("ALTER TABLE wrong_questions ADD COLUMN knowledge_points_json TEXT NULL"))
        if inspector.has_table("wrong_questions") and not _has_column(inspector, "wrong_questions", "recommended_chapter"):
            conn.execute(text("ALTER TABLE wrong_questions ADD COLUMN recommended_chapter VARCHAR(100) NULL"))
        if inspector.has_table("wrong_questions") and not _has_column(inspector, "wrong_questions", "reference_question_id"):
            conn.execute(text("ALTER TABLE wrong_questions ADD COLUMN reference_question_id INTEGER NULL"))
        if inspector.has_table("report_submissions") and not _has_column(inspector, "report_submissions", "ai_score"):
            conn.execute(text("ALTER TABLE report_submissions ADD COLUMN ai_score FLOAT NULL DEFAULT 0"))
        if inspector.has_table("report_submissions") and not _has_column(inspector, "report_submissions", "highlights_json"):
            conn.execute(text("ALTER TABLE report_submissions ADD COLUMN highlights_json TEXT NULL"))
        if inspector.has_table("report_submissions") and not _has_column(inspector, "report_submissions", "improvements_json"):
            conn.execute(text("ALTER TABLE report_submissions ADD COLUMN improvements_json TEXT NULL"))
        if inspector.has_table("assignment_submissions") and not _has_column(inspector, "assignment_submissions", "optimized_answer"):
            conn.execute(text("ALTER TABLE assignment_submissions ADD COLUMN optimized_answer TEXT NULL"))

        # chat_histories is created by metadata.create_all, but older DB files may miss newer columns.
        if inspector.has_table("chat_histories") and not _has_column(inspector, "chat_histories", "source_summary"):
            conn.execute(text("ALTER TABLE chat_histories ADD COLUMN source_summary TEXT NULL"))
        if inspector.has_table("chat_histories") and not _has_column(inspector, "chat_histories", "knowledge_points_json"):
            conn.execute(text("ALTER TABLE chat_histories ADD COLUMN knowledge_points_json TEXT NULL"))
        if inspector.has_table("chat_histories") and not _has_column(inspector, "chat_histories", "rag_used"):
            conn.execute(text("ALTER TABLE chat_histories ADD COLUMN rag_used INTEGER NOT NULL DEFAULT 0"))

        if inspector.has_table("practice_questions"):
            pq_columns = inspector.get_columns("practice_questions")
            correct_answer_col = next((col for col in pq_columns if col.get("name") == "correct_answer"), None)
            if correct_answer_col is not None:
                type_str = str(correct_answer_col.get("type", "")).upper()
                if dialect_name == "mysql" and "VARCHAR" in type_str:
                    conn.execute(text("ALTER TABLE practice_questions MODIFY COLUMN correct_answer TEXT NOT NULL"))


ensure_runtime_schema()
with SessionLocal() as db:
    seed_data(db)


@app.exception_handler(HTTPException)
async def http_exception_handler(_request: Request, exc: HTTPException):
    return JSONResponse(status_code=exc.status_code, content=err_payload(message=str(exc.detail), code=exc.status_code, data=None))


@app.exception_handler(Exception)
async def unhandled_exception_handler(_request: Request, exc: Exception):
    return JSONResponse(status_code=500, content=err_payload(message=f"系统异常：{type(exc).__name__}: {exc}", code=500, data=None))


app.include_router(auth.router)
app.include_router(student.router)
app.include_router(teacher.router)
app.include_router(admin.router)
app.include_router(chat.router)
app.include_router(graph.router)


@app.get("/")
def root():
    return {"app": settings.APP_NAME, "status": "running", "docs": "/docs"}
