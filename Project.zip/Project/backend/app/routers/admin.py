import json
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, UploadFile
from sqlalchemy.orm import Session

from ..auth import get_password_hash, require_role
from ..analytics import build_admin_overview
from ..database import get_db
from ..knowledge_graph import build_graph_from_documents
from ..models import (
    KnowledgeDocument,
    KnowledgeGraph,
    KnowledgeGraphEdge,
    KnowledgeGraphNode,
    KnowledgePoint,
    ChatHistory,
    LearningPath,
    LearningRecord,
    PracticeQuestion,
    PracticeRecord,
    QuizRecord,
    ReportSubmission,
    AssignmentSubmission,
    ChartAnalysisRecord,
    TaskAssignment,
    User,
    WrongQuestion,
    MasteryRecord,
)
from ..rag import add_document_chunks, delete_knowledge_file_artifacts, extract_text_from_file, remove_document_chunks, save_parsed_text, save_upload_file
from ..practice_bank import parse_question_import, save_question_import_artifacts
from ..schemas import KnowledgeGraphBuildRequest, PracticeQuestionBulkDeleteRequest, PracticeQuestionCreate, PracticeQuestionDeduplicateRequest, PracticeQuestionUpdate, UserRegister, UserUpdate
from ..utils import err, ok

router = APIRouter(prefix="/api/admin", tags=["admin"])




def _delete_user_related_rows(db: Session, user: User):
    db.query(TaskAssignment).filter(TaskAssignment.student_id == user.id).delete(synchronize_session=False)
    db.query(TaskAssignment).filter(TaskAssignment.teacher_id == user.id).delete(synchronize_session=False)
    if user.role == "student":
        db.query(LearningPath).filter(LearningPath.student_id == user.id).delete(synchronize_session=False)
        db.query(MasteryRecord).filter(MasteryRecord.student_id == user.id).delete(synchronize_session=False)
        db.query(WrongQuestion).filter(WrongQuestion.student_id == user.id).delete(synchronize_session=False)
        db.query(QuizRecord).filter(QuizRecord.student_id == user.id).delete(synchronize_session=False)
        db.query(LearningRecord).filter(LearningRecord.student_id == user.id).delete(synchronize_session=False)
        db.query(PracticeRecord).filter(PracticeRecord.student_id == user.id).delete(synchronize_session=False)
        db.query(AssignmentSubmission).filter(AssignmentSubmission.student_id == user.id).delete(synchronize_session=False)
        db.query(ReportSubmission).filter(ReportSubmission.student_id == user.id).delete(synchronize_session=False)
        db.query(ChartAnalysisRecord).filter(ChartAnalysisRecord.student_id == user.id).delete(synchronize_session=False)
    db.query(ChatHistory).filter(ChatHistory.user_id == user.id).delete(synchronize_session=False)
    db.query(KnowledgePoint).filter(KnowledgePoint.created_by == user.id).update({KnowledgePoint.created_by: None}, synchronize_session=False)
    db.query(KnowledgeDocument).filter(KnowledgeDocument.uploaded_by == user.id).update({KnowledgeDocument.uploaded_by: None}, synchronize_session=False)
    db.query(KnowledgeGraph).filter(KnowledgeGraph.created_by == user.id).update({KnowledgeGraph.created_by: None}, synchronize_session=False)

def _serialize_user(u: User):
    return {
        "id": u.id,
        "username": u.username,
        "role": u.role,
        "full_name": u.full_name,
        "grade": u.grade,
        "class_name": u.class_name,
        "subject": u.subject,
    }


def _question_delete_query(db: Session, *, ids=None, source_label=None, chapter=None, keyword=None, delete_all=False):
    query = db.query(PracticeQuestion)
    if ids:
        query = query.filter(PracticeQuestion.id.in_(ids))
    if source_label:
        query = query.filter(PracticeQuestion.source_label == source_label.strip())
    if chapter:
        query = query.filter(PracticeQuestion.chapter == chapter.strip())
    if keyword:
        query = query.filter(PracticeQuestion.question_text.contains(keyword.strip()))
    if not delete_all and not ids and not source_label and not chapter and not keyword:
        return None
    return query


def _cascade_delete_practice_questions(db: Session, rows, cascade_records: bool = True):
    rows = list(rows)
    if not rows:
        return 0, 0
    question_ids = [r.id for r in rows]
    deleted_record_count = 0
    if cascade_records:
        deleted_record_count = db.query(PracticeRecord).filter(PracticeRecord.question_id.in_(question_ids)).delete(synchronize_session=False)
    for row in rows:
        db.delete(row)
    return len(question_ids), deleted_record_count


@router.get("/overview")
def overview(current_user: User = Depends(require_role("admin")), db: Session = Depends(get_db)):
    return ok(build_admin_overview(db, days=7))


@router.get("/users")
def get_users(role: str | None = None, current_user: User = Depends(require_role("admin")), db: Session = Depends(get_db)):
    query = db.query(User)
    if role:
        query = query.filter(User.role == role)
    rows = query.order_by(User.id.asc()).all()
    return ok([_serialize_user(u) for u in rows])


@router.post("/users")
def create_user(payload: UserRegister, current_user: User = Depends(require_role("admin")), db: Session = Depends(get_db)):
    if db.query(User).filter(User.username == payload.username).first():
        return err("用户名已存在", status_code=400)
    user = User(
        username=payload.username,
        password_hash=get_password_hash(payload.password),
        role=payload.role,
        full_name=payload.full_name,
        grade=payload.grade,
        class_name=payload.class_name,
        subject=payload.subject,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return ok(_serialize_user(user), "用户创建成功")


@router.put("/users/{user_id}")
def update_user(user_id: int, payload: UserUpdate, current_user: User = Depends(require_role("admin")), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        return err("用户不存在", status_code=404)
    if payload.password:
        user.password_hash = get_password_hash(payload.password)
    for field in ["full_name", "grade", "class_name", "subject"]:
        value = getattr(payload, field)
        if value is not None:
            setattr(user, field, value)
    db.commit()
    db.refresh(user)
    return ok(_serialize_user(user), "用户更新成功")


@router.delete("/users/{user_id}")
def delete_user(user_id: int, current_user: User = Depends(require_role("admin")), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        return err("用户不存在", status_code=404)
    if user.role == "admin" and db.query(User).filter(User.role == "admin").count() <= 1:
        return err("至少保留一个管理员账号", status_code=400)
    _delete_user_related_rows(db, user)
    db.delete(user)
    db.commit()
    return ok({"id": user_id}, "用户安全删除成功")


@router.get("/knowledge-documents")
def list_knowledge_documents(current_user: User = Depends(require_role("admin")), db: Session = Depends(get_db)):
    rows = db.query(KnowledgeDocument).order_by(KnowledgeDocument.id.desc()).all()
    return ok([
        {
            "id": r.id,
            "title": r.title,
            "subject": r.subject,
            "source_label": r.source_label,
            "file_name": r.file_name,
            "file_type": r.file_type,
            "chunk_count": r.chunk_count,
            "created_at": str(r.created_at),
        }
        for r in rows
    ])


@router.post("/knowledge-documents/upload")
def upload_knowledge_document(
    title: str = Form(...),
    subject: str = Form("软件项目管理"),
    source_label: str = Form("管理员知识库"),
    file: UploadFile = File(...),
    current_user: User = Depends(require_role("admin")),
    db: Session = Depends(get_db),
):
    filename = file.filename or ""
    suffix = Path(filename).suffix.lower()
    if suffix not in {".pdf", ".docx", ".txt", ".md", ".pptx"}:
        return err("仅支持上传 pdf、docx、txt、md、pptx 文件", status_code=400)
    saved_path, stored_name = save_upload_file(file)
    try:
        text = extract_text_from_file(saved_path, filename)
        if not text or len(text.strip()) < 20:
            return err("文件可提取内容过少，无法写入知识库", status_code=400)
        clean_title = title.strip() or Path(filename).stem
        clean_subject = (subject or "软件项目管理").strip()
        clean_source = (source_label or "管理员知识库").strip()
        save_parsed_text(stored_name, clean_title, text)
        doc = KnowledgeDocument(
            title=clean_title,
            subject=clean_subject,
            source_label=clean_source,
            file_name=stored_name,
            file_type=suffix.lstrip("."),
            chunk_count=0,
            uploaded_by=current_user.id,
        )
        db.add(doc)
        db.commit()
        db.refresh(doc)
        chunk_count = add_document_chunks(
            document_db_id=doc.id,
            title=doc.title,
            subject=doc.subject,
            source_label=doc.source_label,
            file_name=filename,
            text=text,
        )
        doc.chunk_count = chunk_count
        db.commit()
        return ok({"id": doc.id, "chunk_count": doc.chunk_count, "title": doc.title}, "知识库文件上传并入库成功")
    except Exception as e:
        return err(f"知识库入库失败：{type(e).__name__}: {e}", status_code=500)


@router.delete("/knowledge-documents/{doc_id}")
def delete_knowledge_document(doc_id: int, current_user: User = Depends(require_role("admin")), db: Session = Depends(get_db)):
    doc = db.query(KnowledgeDocument).filter(KnowledgeDocument.id == doc_id).first()
    if not doc:
        return err("知识库文件不存在", status_code=404)
    remove_document_chunks(doc.id)
    delete_knowledge_file_artifacts(doc.file_name)
    db.delete(doc)
    db.commit()
    return ok({"id": doc_id}, "知识库文件删除成功")


@router.get("/knowledge-graphs")
def list_knowledge_graphs(current_user: User = Depends(require_role("admin")), db: Session = Depends(get_db)):
    rows = db.query(KnowledgeGraph).order_by(KnowledgeGraph.id.desc()).all()
    import json
    return ok([
        {
            "id": g.id,
            "name": g.name,
            "subject": g.subject,
            "node_count": g.node_count,
            "edge_count": g.edge_count,
            "source_titles": json.loads(g.source_titles_json or "[]"),
            "created_at": str(g.created_at),
        }
        for g in rows
    ])


@router.post("/knowledge-graphs/build")
def build_knowledge_graph(payload: KnowledgeGraphBuildRequest, current_user: User = Depends(require_role("admin")), db: Session = Depends(get_db)):
    try:
        result = build_graph_from_documents(
            db,
            graph_name=payload.graph_name.strip() or f"{payload.subject}知识图谱",
            subject=(payload.subject or "软件项目管理").strip(),
            document_ids=payload.document_ids or None,
            created_by=current_user.id,
        )
        return ok({
            "graph_id": result.graph_id,
            "node_count": result.node_count,
            "edge_count": result.edge_count,
            "source_document_ids": result.source_document_ids,
            "source_titles": result.source_titles,
        }, "知识图谱构建成功")
    except Exception as e:
        return err(f"知识图谱构建失败：{type(e).__name__}: {e}", status_code=500)


@router.delete("/knowledge-graphs/{graph_id}")
def delete_knowledge_graph(graph_id: int, current_user: User = Depends(require_role("admin")), db: Session = Depends(get_db)):
    graph = db.query(KnowledgeGraph).filter(KnowledgeGraph.id == graph_id).first()
    if not graph:
        return err("知识图谱不存在", status_code=404)
    db.query(KnowledgeGraphEdge).filter(KnowledgeGraphEdge.graph_id == graph_id).delete()
    db.query(KnowledgeGraphNode).filter(KnowledgeGraphNode.graph_id == graph_id).delete()
    db.delete(graph)
    db.commit()
    return ok({"id": graph_id}, "知识图谱删除成功")


@router.get("/practice-questions")
def list_practice_questions(
    keyword: str | None = None,
    chapter: str | None = None,
    question_type: str | None = None,
    current_user: User = Depends(require_role("admin")),
    db: Session = Depends(get_db),
):
    query = db.query(PracticeQuestion)
    if keyword:
        query = query.filter(PracticeQuestion.question_text.contains(keyword.strip()))
    if chapter:
        query = query.filter(PracticeQuestion.chapter == chapter.strip())
    if question_type:
        query = query.filter(PracticeQuestion.question_type == question_type.strip())
    rows = query.order_by(PracticeQuestion.id.desc()).limit(500).all()
    return ok([{
        'id': r.id,
        'subject': r.subject,
        'chapter': r.chapter,
        'difficulty': r.difficulty or '适中',
        'question_type': r.question_type,
        'question_text': r.question_text,
        'options': json.loads(r.options_json) if r.options_json else None,
        'correct_answer': r.correct_answer,
        'analysis': r.analysis,
        'knowledge_points': json.loads(r.knowledge_points_json or '[]'),
        'source_label': r.source_label,
        'created_at': str(r.created_at),
    } for r in rows])


@router.post("/practice-questions")
def create_practice_question(payload: PracticeQuestionCreate, current_user: User = Depends(require_role("admin")), db: Session = Depends(get_db)):
    row = PracticeQuestion(
        subject=payload.subject,
        chapter=payload.chapter,
        difficulty=payload.difficulty,
        question_type=payload.question_type,
        question_text=payload.question_text,
        options_json=json.dumps(payload.options, ensure_ascii=False) if payload.options is not None else None,
        correct_answer=payload.correct_answer,
        analysis=payload.analysis,
        knowledge_points_json=json.dumps(payload.knowledge_points or [], ensure_ascii=False),
        source_label=payload.source_label,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return ok({'id': row.id}, '题目新增成功')


@router.put("/practice-questions/{question_id}")
def update_practice_question(question_id: int, payload: PracticeQuestionUpdate, current_user: User = Depends(require_role("admin")), db: Session = Depends(get_db)):
    row = db.query(PracticeQuestion).filter(PracticeQuestion.id == question_id).first()
    if not row:
        return err('题目不存在', status_code=404)
    for field in ['subject', 'chapter', 'difficulty', 'question_type', 'question_text', 'correct_answer', 'analysis', 'source_label']:
        value = getattr(payload, field)
        if value is not None:
            setattr(row, field, value)
    if payload.options is not None:
        row.options_json = json.dumps(payload.options, ensure_ascii=False)
    if payload.knowledge_points is not None:
        row.knowledge_points_json = json.dumps(payload.knowledge_points, ensure_ascii=False)
    db.commit()
    return ok({'id': row.id}, '题目更新成功')


@router.delete("/practice-questions/{question_id}")
def delete_practice_question(question_id: int, cascade_records: bool = True, current_user: User = Depends(require_role("admin")), db: Session = Depends(get_db)):
    row = db.query(PracticeQuestion).filter(PracticeQuestion.id == question_id).first()
    if not row:
        return err('题目不存在', status_code=404)
    try:
        deleted_question_count, deleted_record_count = _cascade_delete_practice_questions(db, [row], cascade_records=cascade_records)
        db.commit()
        return ok({'id': question_id, 'deleted_question_count': deleted_question_count, 'deleted_record_count': deleted_record_count}, '题目删除成功')
    except Exception as e:
        db.rollback()
        return err(f"题目删除失败：{type(e).__name__}: {e}", status_code=500)


@router.get("/practice-questions/meta")
def practice_question_meta(current_user: User = Depends(require_role("admin")), db: Session = Depends(get_db)):
    rows = db.query(PracticeQuestion.source_label, PracticeQuestion.chapter).all()
    source_labels = sorted({(r[0] or '未标注').strip() for r in rows if (r[0] or '').strip()})
    chapters = sorted({(r[1] or '').strip() for r in rows if (r[1] or '').strip()})
    return ok({'source_labels': source_labels, 'chapters': chapters})


@router.post("/practice-questions/bulk-delete")
def bulk_delete_practice_questions(payload: PracticeQuestionBulkDeleteRequest, current_user: User = Depends(require_role("admin")), db: Session = Depends(get_db)):
    query = _question_delete_query(
        db,
        ids=payload.ids,
        source_label=payload.source_label,
        chapter=payload.chapter,
        keyword=payload.keyword,
        delete_all=payload.delete_all,
    )
    if query is None:
        return err('请至少选择一种删除条件，或勾选全部删除。', status_code=400)
    rows = query.all()
    if not rows:
        return err('没有匹配到可删除的题目。', status_code=404)
    try:
        deleted_question_count, deleted_record_count = _cascade_delete_practice_questions(db, rows, cascade_records=payload.cascade_records)
        db.commit()
        return ok({'deleted_question_count': deleted_question_count, 'deleted_record_count': deleted_record_count}, '批量删除完成')
    except Exception as e:
        db.rollback()
        return err(f"批量删除失败：{type(e).__name__}: {e}", status_code=500)


@router.post("/practice-questions/deduplicate")
def deduplicate_practice_questions(payload: PracticeQuestionDeduplicateRequest, current_user: User = Depends(require_role("admin")), db: Session = Depends(get_db)):
    query = db.query(PracticeQuestion)
    if payload.source_label:
        query = query.filter(PracticeQuestion.source_label == payload.source_label.strip())
    if payload.chapter:
        query = query.filter(PracticeQuestion.chapter == payload.chapter.strip())
    rows = query.order_by(PracticeQuestion.id.asc()).all()
    if not rows:
        return err('没有可处理的题目。', status_code=404)
    grouped = {}
    duplicates = []
    for row in rows:
        key = (
            (row.chapter or '').strip(),
            (row.question_type or '').strip(),
            (row.question_text or '').strip(),
            (row.options_json or '').strip(),
        )
        if key in grouped:
            duplicates.append(row)
        else:
            grouped[key] = row
    if not duplicates:
        return ok({'deleted_question_count': 0, 'deleted_record_count': 0}, '未发现重复题目')
    try:
        deleted_question_count, deleted_record_count = _cascade_delete_practice_questions(db, duplicates, cascade_records=payload.cascade_records)
        db.commit()
        return ok({'deleted_question_count': deleted_question_count, 'deleted_record_count': deleted_record_count}, '题库去重完成')
    except Exception as e:
        db.rollback()
        return err(f"题库去重失败：{type(e).__name__}: {e}", status_code=500)


@router.post("/practice-questions/import")
def admin_import_practice_questions(
    subject: str = Form("软件项目管理"),
    source_label: str = Form("管理员导入题库"),
    file: UploadFile = File(...),
    current_user: User = Depends(require_role("admin")),
    db: Session = Depends(get_db),
):
    filename = file.filename or ""
    file_bytes = file.file.read()
    items, errors = parse_question_import(file_bytes, filename, subject or "软件项目管理", source_label or "管理员导入题库")
    if errors and not items:
        return err("；".join(errors), status_code=400)
    artifacts = save_question_import_artifacts(file_bytes, filename, items)
    created_count = 0
    skipped_count = 0
    try:
        for item in items:
            exists = db.query(PracticeQuestion).filter(PracticeQuestion.chapter == item['chapter'], PracticeQuestion.question_text == item['question_text']).first()
            if exists:
                skipped_count += 1
                continue
            db.add(PracticeQuestion(
                subject=item['subject'],
                chapter=item['chapter'],
                difficulty=item.get('difficulty', '适中'),
                question_type=item['question_type'],
                question_text=item['question_text'],
                options_json=json.dumps(item['options'], ensure_ascii=False) if item.get('options') is not None else None,
                correct_answer=item['correct_answer'],
                analysis=item.get('analysis'),
                knowledge_points_json=json.dumps(item.get('knowledge_points') or [], ensure_ascii=False),
                source_label=item.get('source_label') or source_label,
            ))
            created_count += 1
        db.commit()
    except Exception as e:
        db.rollback()
        return err(f"题库导入失败：{type(e).__name__}: {e}", status_code=500)
    return ok({
        'created_count': created_count,
        'skipped_count': skipped_count,
        'error_count': len(errors),
        'errors': errors[:20],
        'upload_path': artifacts['upload_path'],
        'parsed_path': artifacts['parsed_path'],
    }, '题库导入完成')
