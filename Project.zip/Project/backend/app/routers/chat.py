import base64
import json
import tempfile
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, UploadFile
from sqlalchemy.orm import Session

from ..auth import require_role
from ..database import get_db
from ..models import ChatHistory, LearningRecord, User
from ..rag import extract_text_from_file
from ..schemas import ChatRequest
from ..services import ollama_chat_once
from ..utils import err, ok

router = APIRouter(prefix="/api/chat", tags=["chat"])


def _persist_chat_record(db: Session, user_id: int, payload_mode: str, payload_prompt: str, image_b64: str | None, answer: str, meta: dict):
    rag_sources = meta.get("rag_sources", []) or []
    knowledge_points = meta.get("knowledge_points", []) or []
    unique_source_items = []
    seen_sources = set()
    for item in rag_sources:
        key = (
            item.get("subject", "通用"),
            item.get("source", "教师知识库"),
            item.get("title", "未命名资料"),
            item.get("file_name") or "",
        )
        if key not in seen_sources:
            seen_sources.add(key)
            unique_source_items.append(item)
    source_summary = "； ".join(
        f"{item.get('subject', '通用')} / {item.get('source', '教师知识库')} / {item.get('title', '未命名资料')}"
        for item in unique_source_items
    )
    lines = [
        f"模式: {payload_mode}",
        f"系统识别科目: {meta.get('subject_label', '未指定')}",
        f"系统识别题型: {meta.get('question_type', '综合学习问题')}",
        f"是否图片输入: {'是' if image_b64 else '否'}",
        f"是否命中知识库: {'是' if meta.get('rag_used') else '否'}",
        f"知识库来源: {source_summary or '无'}",
        f"知识点: {'；'.join(knowledge_points) or '无'}",
        f"Q: {payload_prompt}",
        f"A: {answer[:2000]}",
    ]
    db.add(LearningRecord(student_id=user_id, record_type="chat", content="\n".join(lines)))
    db.add(ChatHistory(
        user_id=user_id,
        mode=payload_mode or "step_by_step",
        question=payload_prompt,
        answer=answer,
        source_summary=source_summary or None,
        knowledge_points_json=json.dumps(knowledge_points or [], ensure_ascii=False),
        rag_used=1 if meta.get("rag_used") else 0,
    ))
    db.commit()
    return unique_source_items, source_summary, knowledge_points


@router.post("")
def chat(payload: ChatRequest, current_user: User = Depends(require_role("student", "teacher", "admin")), db: Session = Depends(get_db)):
    try:
        answer, elapsed, meta = ollama_chat_once(
            prompt=payload.prompt,
            image_b64=payload.image_b64,
            history=[item.model_dump() for item in payload.history],
            mode=payload.mode,
            subject=payload.subject,
            options={
                "temperature": float(payload.temperature),
                "top_p": float(payload.top_p),
                "top_k": int(payload.top_k),
                "num_predict": int(payload.max_new_tokens),
                "num_ctx": int(payload.num_ctx),
            },
            use_rag=True,
            has_uploaded_file=False,
        )
        unique_source_items, source_summary, knowledge_points = _persist_chat_record(db, current_user.id, payload.mode, payload.prompt, payload.image_b64, answer, meta)
        return ok(
            {
                "answer": answer,
                "elapsed_seconds": elapsed,
                "detected_subject": meta.get("subject_label"),
                "detected_question_type": meta.get("question_type"),
                "rag_used": bool(meta.get("rag_used")),
                "rag_sources": meta.get("rag_sources", []) or [],
                "rag_unique_sources": unique_source_items,
                "knowledge_points": knowledge_points,
                "rag_summary": source_summary or "无",
                "rag_allowed": bool(meta.get("rag_allowed")),
                "rag_reason": meta.get("rag_reason"),
                "intent_label": meta.get("intent_label"),
                "extracted_text_preview": None,
                "uploaded_file_name": None,
            }
        )
    except Exception as e:
        return err(f"模型调用失败：{type(e).__name__}: {e}", status_code=500)


@router.post("/with-file")
def chat_with_file(
    prompt: str = Form(...),
    mode: str = Form("step_by_step"),
    subject: str = Form("软件项目管理"),
    history_json: str = Form("[]"),
    max_new_tokens: int = Form(1024),
    temperature: float = Form(0.7),
    top_p: float = Form(0.9),
    top_k: int = Form(40),
    num_ctx: int = Form(8192),
    file: UploadFile = File(...),
    current_user: User = Depends(require_role("student", "teacher", "admin")),
    db: Session = Depends(get_db),
):
    filename = file.filename or "uploaded_file"
    suffix = Path(filename).suffix.lower()
    raw = file.file.read()
    image_b64 = None
    extracted_text = ""
    try:
        if suffix in {".png", ".jpg", ".jpeg", ".webp", ".bmp"}:
            image_b64 = base64.b64encode(raw).decode("utf-8")
        else:
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                tmp.write(raw)
                tmp_path = tmp.name
            try:
                extracted_text = extract_text_from_file(tmp_path, filename)
            finally:
                Path(tmp_path).unlink(missing_ok=True)
    except Exception as e:
        return err(f"文件解析失败：{type(e).__name__}: {e}", status_code=400)

    merged_prompt = prompt.strip()
    if extracted_text.strip():
        merged_prompt += f"\n\n以下是用户上传文件中提取到的内容，请结合这些内容回答：\n{extracted_text[:12000]}"
    try:
        history = json.loads(history_json or "[]")
        answer, elapsed, meta = ollama_chat_once(
            prompt=merged_prompt,
            image_b64=image_b64,
            history=history,
            mode=mode,
            subject=subject,
            options={
                "temperature": float(temperature),
                "top_p": float(top_p),
                "top_k": int(top_k),
                "num_predict": int(max_new_tokens),
                "num_ctx": int(num_ctx),
            },
            use_rag=True,
            has_uploaded_file=bool(extracted_text.strip()) or suffix not in {".png", ".jpg", ".jpeg", ".webp", ".bmp"},
        )
        unique_source_items, source_summary, knowledge_points = _persist_chat_record(db, current_user.id, mode, prompt, image_b64, answer, meta)
        return ok(
            {
                "answer": answer,
                "elapsed_seconds": elapsed,
                "detected_subject": meta.get("subject_label"),
                "detected_question_type": meta.get("question_type"),
                "rag_used": bool(meta.get("rag_used")),
                "rag_sources": meta.get("rag_sources", []) or [],
                "rag_unique_sources": unique_source_items,
                "knowledge_points": knowledge_points,
                "rag_summary": source_summary or "无",
                "rag_allowed": bool(meta.get("rag_allowed")),
                "rag_reason": meta.get("rag_reason"),
                "intent_label": meta.get("intent_label"),
                "extracted_text_preview": extracted_text[:1500] if extracted_text else None,
                "uploaded_file_name": filename,
            }
        )
    except Exception as e:
        return err(f"模型调用失败：{type(e).__name__}: {e}", status_code=500)


@router.get("/history")
def get_chat_history(limit: int = 20, current_user: User = Depends(require_role("student", "teacher", "admin")), db: Session = Depends(get_db)):
    rows = (
        db.query(ChatHistory)
        .filter(ChatHistory.user_id == current_user.id)
        .order_by(ChatHistory.id.desc())
        .limit(max(1, min(limit, 50)))
        .all()
    )
    return ok([
        {
            "id": row.id,
            "mode": row.mode,
            "question": row.question,
            "answer": row.answer,
            "source_summary": row.source_summary,
            "knowledge_points": json.loads(row.knowledge_points_json or "[]"),
            "rag_used": bool(row.rag_used),
            "created_at": str(row.created_at),
        }
        for row in rows
    ])
