import base64
import json
import random
import re
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, UploadFile
from sqlalchemy.orm import Session

from ..analytics import build_practice_summary
from ..auth import require_role
from ..course_data import CANONICAL_CHAPTERS, COURSE_NAME, POINT_TO_MODULE as POINT_TO_MODULE_FALLBACK, infer_points
from ..database import get_db
from ..knowledge_graph import get_graph_payload_for_student
from ..models import (
    AssignmentSubmission,
    ChartAnalysisRecord,
    KnowledgeGraph,
    KnowledgePoint,
    LearningPath,
    LearningRecord,
    MasteryRecord,
    PracticeQuestion,
    PracticeRecord,
    QuizRecord,
    ReportSubmission,
    TaskAssignment,
    User,
    WrongQuestion,
)
from ..paths import CHART_ANALYSIS_UPLOAD_DIR
from ..rag import build_rag_context, extract_text_from_file, search_knowledge
from ..recommendation import build_student_dashboard_summary, ensure_path_for_focus
from ..schemas import (
    LearningPathCreate,
    PracticeGenerateRequest,
    PracticeSubmitRequest,
    QuizRecordCreate,
    ReportGuidanceRequest,
    WrongQuestionCreate,
    WrongQuestionFromChatCreate,
)
from ..services import (
    generate_assignment_grading,
    generate_chart_analysis,
    generate_report_guidance,
    generate_wrong_question_analysis,
)
from ..utils import err, ok

router = APIRouter(prefix="/api/student", tags=["student"])


def _extract_text_from_upload(file: UploadFile) -> tuple[str, str]:
    filename = file.filename or "uploaded_file"
    suffix = Path(filename).suffix.lower()
    raw = file.file.read()
    if not raw:
        return "", filename
    temp_path = CHART_ANALYSIS_UPLOAD_DIR / f"tmp_{random.randint(100000, 999999)}{suffix or '.bin'}"
    temp_path.write_bytes(raw)
    try:
        text = extract_text_from_file(str(temp_path), filename)
        return text, filename
    finally:
        try:
            temp_path.unlink(missing_ok=True)
        except Exception:
            pass


def _knowledge_points_to_chapter(points: list[str]) -> str | None:
    for point in points:
        chapter = POINT_TO_MODULE_FALLBACK.get(point)
        if chapter:
            return chapter
    return None


def _safe_json_loads_list(raw: str | None) -> list:
    if not raw:
        return []
    try:
        value = json.loads(raw)
        return value if isinstance(value, list) else []
    except Exception:
        return []


def _normalize_match_text(text: str | None) -> str:
    value = (text or "").strip().lower()
    return re.sub(r"[^0-9a-zA-Z一-鿿]+", "", value)


def _question_text_candidates(all_rows: list[PracticeQuestion], question_text: str | None) -> list[PracticeQuestion]:
    target = _normalize_match_text(question_text)
    if not target:
        return []
    exact: list[PracticeQuestion] = []
    partial: list[PracticeQuestion] = []
    prefix = target[:28]
    for row in all_rows:
        normalized = _normalize_match_text(row.question_text)
        if not normalized:
            continue
        if normalized == target:
            exact.append(row)
            continue
        if len(prefix) >= 12 and (normalized.startswith(prefix) or prefix in normalized or target[:18] and target[:18] in normalized):
            partial.append(row)
    return exact + partial


def _dedupe_questions(rows: list[PracticeQuestion]) -> list[PracticeQuestion]:
    seen: set[int] = set()
    result: list[PracticeQuestion] = []
    for row in rows:
        if not row or row.id in seen:
            continue
        seen.add(row.id)
        result.append(row)
    return result


def _question_matches_point(row: PracticeQuestion, point: str) -> bool:
    if not point:
        return False
    wanted = _normalize_match_text(point)
    for item in _safe_json_loads_list(row.knowledge_points_json):
        if _normalize_match_text(str(item)) == wanted:
            return True
    return wanted in _normalize_match_text(row.knowledge_points_json or "")


def _question_matches_chapter(row: PracticeQuestion, chapter: str) -> bool:
    if not chapter:
        return False
    return _normalize_match_text(row.chapter) == _normalize_match_text(chapter)


def _get_wrong_question_points(row: WrongQuestion) -> list[str]:
    stored_points = [str(x).strip() for x in _safe_json_loads_list(getattr(row, "knowledge_points_json", None)) if str(x).strip()]
    if stored_points:
        return stored_points
    text = "\n".join([row.question_text or "", row.analysis or "", row.answer_text or ""])
    return infer_points(text)


def _get_wrong_question_chapter(row: WrongQuestion, points: list[str] | None = None) -> str | None:
    chapter = (getattr(row, "recommended_chapter", None) or "").strip()
    if chapter:
        return chapter
    return _knowledge_points_to_chapter(points or _get_wrong_question_points(row))


def _serialize_wrong_question(row: WrongQuestion) -> dict:
    points = _get_wrong_question_points(row)
    return {
        "id": row.id,
        "subject": row.subject,
        "question_text": row.question_text,
        "answer_text": row.answer_text,
        "analysis": row.analysis,
        "ai_analysis": row.ai_analysis,
        "knowledge_points": points,
        "recommended_chapter": _get_wrong_question_chapter(row, points),
        "created_at": str(row.created_at),
    }


@router.get("/dashboard")
def student_dashboard(current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    paths = db.query(LearningPath).filter(LearningPath.student_id == current_user.id).all()
    wrongs = db.query(WrongQuestion).filter(WrongQuestion.student_id == current_user.id).count()
    quizzes = db.query(QuizRecord).filter(QuizRecord.student_id == current_user.id).count()
    practice_count = db.query(PracticeRecord).filter(PracticeRecord.student_id == current_user.id).count()
    tasks = db.query(TaskAssignment).filter(TaskAssignment.student_id == current_user.id).all()
    mastery_rows = (
        db.query(MasteryRecord, KnowledgePoint)
        .join(KnowledgePoint, KnowledgePoint.id == MasteryRecord.knowledge_point_id)
        .filter(MasteryRecord.student_id == current_user.id)
        .all()
    )
    mastery = [{"knowledge_point": kp.name, "subject": kp.subject, "mastery_score": mr.mastery_score} for mr, kp in mastery_rows]
    recommendation = build_student_dashboard_summary(db, current_user.id)
    dynamic_paths = recommendation.get("dynamic_paths") or []
    legacy_paths = [{"id": p.id, "title": p.title, "goal": p.goal, "steps": json.loads(p.steps_json)} for p in paths]
    return ok({
        "paths": dynamic_paths,
        "legacy_paths": legacy_paths,
        "wrong_count": wrongs,
        "quiz_count": quizzes,
        "practice_count": practice_count,
        "tasks": [{"id": t.id, "title": t.title, "description": t.description, "status": t.status} for t in tasks],
        "mastery": mastery,
        "recommendation": recommendation,
    })


@router.get("/recommendations")
def student_recommendations(current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    return ok(build_student_dashboard_summary(db, current_user.id))


@router.post("/learning-path")
def create_learning_path(payload: LearningPathCreate, current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    item = LearningPath(student_id=current_user.id, title=payload.title, goal=payload.goal, steps_json=json.dumps(payload.steps, ensure_ascii=False))
    db.add(item)
    db.commit()
    db.refresh(item)
    return ok({"id": item.id}, "学习路径创建成功")


@router.get("/wrong-questions")
def get_wrong_questions(current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    rows = db.query(WrongQuestion).filter(WrongQuestion.student_id == current_user.id).order_by(WrongQuestion.id.desc()).all()
    return ok([_serialize_wrong_question(r) for r in rows])


@router.post("/wrong-questions")
def add_wrong_question(payload: WrongQuestionCreate, current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    ai_analysis = _build_wrong_question_ai_analysis(payload.question_text, payload.answer_text, payload.analysis or payload.answer_text or "")
    points = infer_points("\n".join([payload.question_text or "", payload.analysis or "", payload.answer_text or ""]))
    chapter = _knowledge_points_to_chapter(points)
    row = WrongQuestion(
        student_id=current_user.id,
        subject=COURSE_NAME,
        question_text=payload.question_text,
        answer_text=payload.answer_text,
        analysis=payload.analysis,
        ai_analysis=ai_analysis,
        knowledge_points_json=json.dumps(points, ensure_ascii=False),
        recommended_chapter=chapter,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    for point in points[:1]:
        ensure_path_for_focus(db, current_user.id, point)
    return ok({"id": row.id}, "错题已保存")


@router.post("/wrong-questions/from-chat")
def add_wrong_question_from_chat(payload: WrongQuestionFromChatCreate, current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    ai_analysis = _build_wrong_question_ai_analysis(payload.question_text, payload.answer_text, payload.analysis or payload.answer_text or "")
    points = infer_points("\n".join([payload.question_text or "", payload.analysis or "", payload.answer_text or ""]))
    chapter = _knowledge_points_to_chapter(points)
    row = WrongQuestion(
        student_id=current_user.id,
        subject=COURSE_NAME,
        question_text=payload.question_text,
        answer_text=payload.answer_text,
        analysis=payload.analysis,
        ai_analysis=ai_analysis,
        knowledge_points_json=json.dumps(points, ensure_ascii=False),
        recommended_chapter=chapter,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    if points:
        ensure_path_for_focus(db, current_user.id, points[0])
    db.add(LearningRecord(
        student_id=current_user.id,
        record_type="wrong_question_from_chat",
        content=f"课程: {COURSE_NAME}\n知识点: {'、'.join(points) or '未识别'}\n题目: {payload.question_text[:1000]}\n分析: {(payload.analysis or '')[:1000]}",
    ))
    db.commit()
    return ok({"id": row.id, "points": points}, "已从最近一次问答加入错题本")


@router.post("/practice/generate-from-wrong")
def generate_practice_from_wrong(payload: dict, current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    data = payload or {}
    mode = data.get("mode") or "question"
    count = max(1, min(int(data.get("count") or 5), 20))
    rows: list[PracticeQuestion] = []
    all_questions = db.query(PracticeQuestion).all()

    if mode == "question":
        wrong_id = int(data.get("wrong_question_id") or 0)
        wrong = db.query(WrongQuestion).filter(WrongQuestion.id == wrong_id, WrongQuestion.student_id == current_user.id).first()
        if not wrong:
            return err("错题不存在", status_code=404)

        exact_rows: list[PracticeQuestion] = []
        related_rows: list[PracticeQuestion] = []
        reference_question_id = getattr(wrong, "reference_question_id", None)
        if reference_question_id:
            matched = next((q for q in all_questions if q.id == reference_question_id), None)
            if matched:
                exact_rows.append(matched)
        if not exact_rows:
            exact_rows = _question_text_candidates(all_questions, wrong.question_text)

        points = _get_wrong_question_points(wrong)
        chapter = _get_wrong_question_chapter(wrong, points)
        for point in points:
            related_rows.extend([q for q in all_questions if _question_matches_point(q, point)])
        if chapter:
            related_rows.extend([q for q in all_questions if _question_matches_chapter(q, chapter)])

        rows = _dedupe_questions(exact_rows + related_rows)
    elif mode == "knowledge_point":
        point = str(data.get("knowledge_point") or "").strip()
        if not point:
            return err("请提供知识点", status_code=400)
        rows = [q for q in all_questions if _question_matches_point(q, point)]
        if not rows:
            chapter = _knowledge_points_to_chapter([point])
            if chapter:
                rows = [q for q in all_questions if _question_matches_chapter(q, chapter)]
        rows = _dedupe_questions(rows)
    elif mode == "chapter":
        chapter = str(data.get("chapter") or "").strip()
        if not chapter:
            return err("请提供章节", status_code=400)
        rows = _dedupe_questions([q for q in all_questions if _question_matches_chapter(q, chapter)])
    else:
        return err("不支持的重练模式", status_code=400)

    if not rows:
        return err("当前条件下没有可重练的题目。已优先按原题、知识点、章节三层检索，仍未命中，请检查该错题是否来自当前课程题库。", status_code=404)

    head = rows[:1]
    tail = rows[1:]
    random.shuffle(tail)
    selected = (head + tail)[:count]
    return ok({
        "filters": {"mode": mode, "count": len(selected)},
        "questions": [_practice_question_to_dict(q) for q in selected],
    }, "已生成针对性重练题目")


@router.get("/quiz-records")
def get_quiz_records(current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    rows = db.query(QuizRecord).filter(QuizRecord.student_id == current_user.id).order_by(QuizRecord.id.desc()).all()
    return ok([{"id": r.id, "subject": r.subject, "score": r.score, "total_score": r.total_score, "summary": r.summary, "created_at": str(r.created_at)} for r in rows])


@router.post("/quiz-records")
def add_quiz_record(payload: QuizRecordCreate, current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    row = QuizRecord(student_id=current_user.id, subject=COURSE_NAME, score=payload.score, total_score=payload.total_score, summary=payload.summary)
    db.add(row)
    db.commit()
    db.refresh(row)
    return ok({"id": row.id}, "测验记录已保存")


@router.get("/learning-records")
def get_learning_records(current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    rows = db.query(LearningRecord).filter(LearningRecord.student_id == current_user.id).order_by(LearningRecord.id.desc()).all()
    return ok([{"id": r.id, "record_type": r.record_type, "content": r.content, "created_at": str(r.created_at)} for r in rows])


@router.get("/knowledge-graph")
def get_student_knowledge_graph(subject: str | None = None, current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    graph = db.query(KnowledgeGraph).order_by(KnowledgeGraph.id.desc()).first()
    if not graph:
        return err("当前还没有可用的知识图谱，请先由教师端构建图谱", status_code=404)
    return ok(get_graph_payload_for_student(db, graph, current_user.id))


def _normalize_text(text: str | None) -> str:
    return "".join((text or "").strip().lower().split())


def _normalize_choice_answer(text: str | None) -> str:
    return "".join(ch for ch in (text or "").upper() if ch in "ABCDEF")


def _find_reference_answer_from_bank(db: Session, question_text: str, chapter: str | None = None) -> tuple[str | None, PracticeQuestion | None]:
    target = _normalize_text(question_text)
    if not target:
        return None, None
    query = db.query(PracticeQuestion).filter(PracticeQuestion.subject == COURSE_NAME)
    if chapter:
        query = query.filter(PracticeQuestion.chapter == chapter)
    rows = query.all()
    for row in rows:
        row_norm = _normalize_text(row.question_text)
        if row_norm == target:
            return row.correct_answer, row
    for row in rows:
        row_norm = _normalize_text(row.question_text)
        if target and row_norm and (target in row_norm or row_norm in target):
            return row.correct_answer, row
    return None, None


def _parse_float_value(text: str | None) -> float | None:
    match = re.search(r"-?\d+(?:\.\d+)?", str(text or ""))
    if not match:
        return None
    try:
        return float(match.group(0))
    except Exception:
        return None


def _is_answer_correct(question: PracticeQuestion, student_answer: str | None) -> bool:
    qtype = question.question_type or ""
    if qtype == "多选题":
        return set(_normalize_choice_answer(student_answer)) == set(_normalize_choice_answer(question.correct_answer))
    if qtype == "判断题":
        mapping = {"对": "正确", "错": "错误", "true": "正确", "false": "错误", "yes": "正确", "no": "错误"}
        answer = mapping.get(_normalize_text(student_answer), _normalize_text(student_answer))
        correct = mapping.get(_normalize_text(question.correct_answer), _normalize_text(question.correct_answer))
        return answer == correct
    if qtype == "计算题":
        stu_val = _parse_float_value(student_answer)
        cor_val = _parse_float_value(question.correct_answer)
        if stu_val is not None and cor_val is not None:
            return abs(stu_val - cor_val) <= max(0.01, abs(cor_val) * 0.02)
        return _normalize_text(student_answer) == _normalize_text(question.correct_answer)
    if qtype == "简答题":
        answer = _normalize_text(student_answer)
        correct = _normalize_text(question.correct_answer)
        if not answer:
            return False
        keywords = [x for x in infer_points(question.correct_answer + "\n" + (question.analysis or ""))]
        if answer in correct or correct in answer:
            return True
        return sum(1 for k in keywords if _normalize_text(k) in answer) >= max(1, min(2, len(keywords)))
    return _normalize_text(student_answer) == _normalize_text(question.correct_answer)


def _ensure_mastery_for_points(db: Session, student_id: int, point_names: list[str], is_correct: bool):
    for point_name in point_names:
        kp = db.query(KnowledgePoint).filter(KnowledgePoint.name == point_name, KnowledgePoint.subject == COURSE_NAME).first()
        if not kp:
            kp = KnowledgePoint(name=point_name, subject=COURSE_NAME, description="由专项练习自动补充", difficulty="medium")
            db.add(kp)
            db.flush()
        row = db.query(MasteryRecord).filter(MasteryRecord.student_id == student_id, MasteryRecord.knowledge_point_id == kp.id).first()
        delta = 0.1 if is_correct else -0.15
        if not row:
            row = MasteryRecord(student_id=student_id, knowledge_point_id=kp.id, mastery_score=max(0.0, min(1.0, 0.5 + delta)))
            db.add(row)
        else:
            row.mastery_score = max(0.0, min(1.0, float(row.mastery_score or 0.5) + delta))


def _practice_question_to_dict(q: PracticeQuestion):
    return {
        "id": q.id,
        "subject": q.subject,
        "chapter": q.chapter,
        "difficulty": q.difficulty or "适中",
        "question_type": q.question_type,
        "question_text": q.question_text,
        "correct_answer": q.correct_answer,
        "analysis": q.analysis,
        "options": json.loads(q.options_json) if q.options_json else None,
        "knowledge_points": json.loads(q.knowledge_points_json) if q.knowledge_points_json else [],
        "source_label": q.source_label,
    }


def _build_wrong_question_ai_analysis(question_text: str, student_answer: str | None, correct_answer: str | None) -> str:
    query = question_text or correct_answer or ""
    docs = search_knowledge(query, subject_hint=COURSE_NAME, top_k=2) if query else []
    rag_context = build_rag_context(docs) if docs else ""
    return generate_wrong_question_analysis(question_text, student_answer or "", correct_answer or "", rag_context)


@router.get("/practice/options")
def get_practice_options(current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    rows = db.query(PracticeQuestion).filter(PracticeQuestion.subject == COURSE_NAME).all()
    row_chapters = {r.chapter for r in rows if r.chapter}
    chapters = [c for c in CANONICAL_CHAPTERS if c in row_chapters]
    extras = sorted([c for c in row_chapters if c not in chapters], key=_chapter_sort_key)
    return ok({
        "chapters": chapters + extras,
        "difficulties": ["简单", "适中", "困难"],
        "count_options": [5, 10, 20],
        "total_questions": len(rows),
    })


def _chapter_sort_key(value: str):
    m = re.search(r"第\s*(\d+)\s*章", value or "")
    return (int(m.group(1)) if m else 9999, value or "")


def _difficulty_priority(target: str | None) -> list[str]:
    if target == "简单":
        return ["简单", "适中", "困难"]
    if target == "困难":
        return ["困难", "适中", "简单"]
    return ["适中", "简单", "困难"]



@router.get("/progress")
def get_learning_progress(current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    rows = (
        db.query(PracticeRecord)
        .filter(PracticeRecord.student_id == current_user.id)
        .order_by(PracticeRecord.id.desc())
        .all()
    )
    stats = {chapter: {"total": 0, "correct": 0} for chapter in CANONICAL_CHAPTERS}
    for row in rows:
        chapter = (row.chapter or "").strip()
        if chapter in stats:
            stats[chapter]["total"] += 1
            stats[chapter]["correct"] += 1 if bool(row.is_correct) else 0

    chapter_items = []
    covered_count = 0
    total_attempts = 0
    total_correct = 0
    priority_revisit = None
    strongest_chapter = None
    for chapter in CANONICAL_CHAPTERS:
        total = int(stats[chapter]["total"])
        correct = int(stats[chapter]["correct"])
        accuracy = round((correct / total) * 100, 1) if total else 0.0
        progress_percent = min(100.0, round(total * 8.0, 1)) if total else 0.0
        if total == 0:
            status = "尚未开始"
        elif accuracy < 60:
            status = "需要巩固"
        elif accuracy < 85:
            status = "正在提升"
        else:
            status = "掌握较好"
        if total > 0:
            covered_count += 1
        total_attempts += total
        total_correct += correct
        item = {
            "chapter": chapter,
            "practice_count": total,
            "correct_count": correct,
            "accuracy": accuracy,
            "progress_percent": progress_percent,
            "status": status,
        }
        chapter_items.append(item)
        if total > 0 and (priority_revisit is None or (accuracy, -total) < (priority_revisit["accuracy"], -priority_revisit["practice_count"])):
            priority_revisit = item
        if total > 0 and (strongest_chapter is None or (accuracy, total) > (strongest_chapter["accuracy"], strongest_chapter["practice_count"])):
            strongest_chapter = item

    avg_accuracy = round((total_correct / total_attempts) * 100, 1) if total_attempts else 0.0
    summary_lines = [f"目前已覆盖 {covered_count} / {len(CANONICAL_CHAPTERS)} 个章节，累计练习 {total_attempts} 次，平均正确率 {avg_accuracy}% 。"]
    if strongest_chapter:
        summary_lines.append(f"你的优势章节为“{strongest_chapter['chapter']}”，当前正确率 {strongest_chapter['accuracy']}%。")
    if priority_revisit and priority_revisit['status'] != '掌握较好':
        summary_lines.append(f"建议优先巩固“{priority_revisit['chapter']}”，当前正确率 {priority_revisit['accuracy']}%。")
    return ok({
        "chapters": chapter_items,
        "summary_text": "".join(summary_lines),
        "covered_count": covered_count,
        "total_chapters": len(CANONICAL_CHAPTERS),
        "total_attempts": total_attempts,
        "average_accuracy": avg_accuracy,
        "priority_revisit": priority_revisit,
        "strongest_chapter": strongest_chapter,
    })


@router.post("/practice/generate")
def generate_practice(payload: PracticeGenerateRequest, current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    query = db.query(PracticeQuestion).filter(PracticeQuestion.subject == COURSE_NAME)
    requested_chapter = payload.chapter or "全部"
    requested_difficulty = payload.difficulty or "适中"
    requested_count = payload.count or 5
    if requested_chapter != "全部":
        query = query.filter(PracticeQuestion.chapter == requested_chapter)
    rows = query.all()
    if not rows:
        return err("当前章节下没有可用题目，请先导入题库", status_code=404)

    selected: list[PracticeQuestion] = []
    used_ids = set()
    for diff in _difficulty_priority(requested_difficulty):
        candidates = [r for r in rows if (r.difficulty or "适中") == diff and r.id not in used_ids]
        random.shuffle(candidates)
        need = requested_count - len(selected)
        if need <= 0:
            break
        chosen = candidates[:need]
        selected.extend(chosen)
        used_ids.update(item.id for item in chosen)

    if len(selected) < requested_count:
        remaining = [r for r in rows if r.id not in used_ids]
        random.shuffle(remaining)
        selected.extend(remaining[: requested_count - len(selected)])

    if not selected:
        return err("当前条件下没有可用题目，请调整筛选条件", status_code=404)

    random.shuffle(selected)
    return ok({
        "filters": {
            "chapter": requested_chapter,
            "difficulty": requested_difficulty,
            "count": len(selected),
        },
        "questions": [_practice_question_to_dict(q) for q in selected],
    }, "专项练习生成成功")


@router.post("/practice/submit")
def submit_practice(payload: PracticeSubmitRequest, current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    if not payload.answers:
        return err("请先作答后再提交")
    result_items = []
    correct_count = 0
    for answer_item in payload.answers:
        question = db.query(PracticeQuestion).filter(PracticeQuestion.id == answer_item.question_id).first()
        if not question:
            continue
        points = json.loads(question.knowledge_points_json) if question.knowledge_points_json else []
        ai_feedback = None
        optimized_answer = None
        ai_grade_meta = {}
        is_correct = _is_answer_correct(question, answer_item.student_answer)
        if question.question_type in {"简答题", "计算题"}:
            ai_feedback, ai_grade_meta = generate_assignment_grading(
                title=f"专项练习｜{question.chapter}｜第{question.id}题",
                question_text=question.question_text,
                student_answer=answer_item.student_answer or "",
                reference_answer=question.correct_answer,
                question_type=question.question_type,
            )
            optimized_answer = ai_grade_meta.get("optimized_answer")
            is_correct = bool(ai_grade_meta.get("is_reference_match")) or is_correct
        record = PracticeRecord(
            student_id=current_user.id,
            question_id=question.id,
            subject=question.subject,
            chapter=question.chapter,
            difficulty=question.difficulty,
            question_type=question.question_type,
            knowledge_points_json=json.dumps(points, ensure_ascii=False),
            student_answer=answer_item.student_answer,
            correct_answer=question.correct_answer,
            is_correct=1 if is_correct else 0,
            score=1.0 if is_correct else 0.0,
            total_score=1.0,
            analysis=(question.analysis or "") + (f"\n\nAI批改意见：{ai_feedback}" if ai_feedback else ""),
        )
        db.add(record)
        _ensure_mastery_for_points(db, current_user.id, points, is_correct)
        if not is_correct:
            wrong_analysis = _build_wrong_question_ai_analysis(
                question.question_text,
                answer_item.student_answer or "",
                question.correct_answer,
            )
            db.add(WrongQuestion(
                student_id=current_user.id,
                subject=COURSE_NAME,
                question_text=question.question_text,
                answer_text=f"你的答案：{answer_item.student_answer or '未作答'}\n正确答案：{question.correct_answer}",
                analysis=question.analysis or "来自专项练习自动收录",
                ai_analysis=wrong_analysis,
            ))
            for point in points[:1]:
                ensure_path_for_focus(db, current_user.id, point)
        else:
            correct_count += 1
        result_items.append({
            "question_id": question.id,
            "question_text": question.question_text,
            "difficulty": question.difficulty or "适中",
            "question_type": question.question_type,
            "chapter": question.chapter,
            "knowledge_points": points,
            "student_answer": answer_item.student_answer,
            "correct_answer": question.correct_answer,
            "is_correct": is_correct,
            "analysis": question.analysis,
            "options": json.loads(question.options_json) if question.options_json else None,
            "ai_feedback": ai_feedback,
            "optimized_answer": optimized_answer,
            "ai_score": ai_grade_meta.get("ai_score"),
        })

    total = len(result_items)
    score = correct_count
    summary = f"共 {total} 题，答对 {correct_count} 题，正确率 {(correct_count / total * 100 if total else 0):.0f}%"
    db.add(QuizRecord(student_id=current_user.id, subject=COURSE_NAME, score=score, total_score=total, summary=f"专项练习：{summary}"))
    db.add(LearningRecord(student_id=current_user.id, record_type="practice_submit", content=summary))
    db.commit()
    weak_points = []
    for item in result_items:
        if not item["is_correct"]:
            for p in item["knowledge_points"]:
                if p not in weak_points:
                    weak_points.append(p)
    summary_card = build_practice_summary(result_items)
    return ok({
        "score": score,
        "total": total,
        "accuracy": round((score / total * 100), 2) if total else 0,
        "summary": summary,
        "weak_points": weak_points,
        "summary_card": summary_card,
        "results": result_items,
    }, "专项练习提交成功")


@router.get("/practice/records")
def get_practice_records(current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    rows = db.query(PracticeRecord).filter(PracticeRecord.student_id == current_user.id).order_by(PracticeRecord.id.desc()).limit(50).all()
    return ok([
        {
            "id": r.id,
            "question_id": r.question_id,
            "chapter": r.chapter,
            "difficulty": r.difficulty or "适中",
            "question_type": r.question_type,
            "knowledge_points": json.loads(r.knowledge_points_json) if r.knowledge_points_json else [],
            "student_answer": r.student_answer,
            "correct_answer": r.correct_answer,
            "is_correct": bool(r.is_correct),
            "score": r.score,
            "total_score": r.total_score,
            "analysis": r.analysis,
            "created_at": str(r.created_at),
        }
        for r in rows
    ])


@router.post("/report-guidance")
def create_report_guidance(payload: ReportGuidanceRequest, current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    title = (payload.title or "").strip() or "未命名实验报告"
    content = (payload.content or "").strip()
    if len(content) < 20:
        return err("实验报告内容过短，请至少输入 20 个字符", status_code=400)
    feedback, meta = generate_report_guidance(title, content)
    row = ReportSubmission(
        student_id=current_user.id,
        title=title,
        content=content,
        ai_feedback=feedback,
        ai_score=float(meta.get("ai_score") or 0.0),
        highlights_json=json.dumps(meta.get("highlights") or [], ensure_ascii=False),
        improvements_json=json.dumps(meta.get("improvements") or [], ensure_ascii=False),
        structure_score=float(meta.get("structure_score") or 0.0),
        terminology_score=float(meta.get("terminology_score") or 0.0),
        completeness_score=float(meta.get("completeness_score") or 0.0),
        overall_level=meta.get("overall_level") or "待评估",
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    db.add(LearningRecord(student_id=current_user.id, record_type="report_guidance", content=f"标题：{title}\n\n{feedback[:2000]}"))
    db.commit()
    return ok({
        "id": row.id,
        "title": row.title,
        "content": row.content,
        "ai_feedback": row.ai_feedback,
        "ai_score": row.ai_score,
        "highlights": meta.get("highlights") or [],
        "improvements": meta.get("improvements") or [],
        "structure_score": row.structure_score,
        "terminology_score": row.terminology_score,
        "completeness_score": row.completeness_score,
        "overall_level": row.overall_level,
        "elapsed_seconds": meta.get("elapsed_seconds", 0.0),
        "rag_used": bool(meta.get("rag_used")),
        "created_at": str(row.created_at),
    }, "实验报告辅导完成")


@router.get("/report-guidance")
def get_report_guidance_records(current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    rows = db.query(ReportSubmission).filter(ReportSubmission.student_id == current_user.id).order_by(ReportSubmission.id.desc()).all()
    return ok([
        {
            "id": r.id,
            "title": r.title,
            "content": r.content,
            "ai_feedback": r.ai_feedback,
            "ai_score": r.ai_score,
            "highlights": json.loads(r.highlights_json or "[]"),
            "improvements": json.loads(r.improvements_json or "[]"),
            "structure_score": r.structure_score,
            "terminology_score": r.terminology_score,
            "completeness_score": r.completeness_score,
            "overall_level": r.overall_level,
            "created_at": str(r.created_at),
        }
        for r in rows
    ])


@router.post("/report-guidance/upload")
def create_report_guidance_from_file(
    title: str = Form("实验报告辅导"),
    file: UploadFile = File(...),
    current_user: User = Depends(require_role("student")),
    db: Session = Depends(get_db),
):
    try:
        content, filename = _extract_text_from_upload(file)
    except Exception as e:
        return err(f"实验报告文件解析失败：{type(e).__name__}: {e}", status_code=400)
    if len((content or "").strip()) < 20:
        return err("文件中可提取的文本过少，请换一个 txt/docx/pdf/pptx 文件或直接粘贴内容", status_code=400)
    feedback, meta = generate_report_guidance((title or "").strip() or Path(filename).stem, content)
    row = ReportSubmission(
        student_id=current_user.id,
        title=(title or "").strip() or Path(filename).stem,
        content=content,
        ai_feedback=feedback,
        ai_score=float(meta.get("ai_score") or 0.0),
        highlights_json=json.dumps(meta.get("highlights") or [], ensure_ascii=False),
        improvements_json=json.dumps(meta.get("improvements") or [], ensure_ascii=False),
        structure_score=float(meta.get("structure_score") or 0.0),
        terminology_score=float(meta.get("terminology_score") or 0.0),
        completeness_score=float(meta.get("completeness_score") or 0.0),
        overall_level=meta.get("overall_level") or "待评估",
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    db.add(LearningRecord(student_id=current_user.id, record_type="report_guidance", content=f"标题：{row.title}\n来源文件：{filename}\n\n{feedback[:2000]}"))
    db.commit()
    return ok({
        "id": row.id,
        "title": row.title,
        "content": row.content,
        "ai_feedback": row.ai_feedback,
        "ai_score": row.ai_score,
        "highlights": meta.get("highlights") or [],
        "improvements": meta.get("improvements") or [],
        "structure_score": row.structure_score,
        "terminology_score": row.terminology_score,
        "completeness_score": row.completeness_score,
        "overall_level": row.overall_level,
        "created_at": str(row.created_at),
        "source_file_name": filename,
    }, "实验报告辅导完成")


@router.post("/assignment-grading")
def create_assignment_grading(
    title: str = Form("AI批改作业"),
    question_text: str = Form(...),
    student_answer: str = Form(""),
    reference_answer: str = Form(""),
    file: UploadFile | None = File(None),
    current_user: User = Depends(require_role("student")),
    db: Session = Depends(get_db),
):
    extra_text = ""
    filename = None
    if file is not None:
        try:
            extra_text, filename = _extract_text_from_upload(file)
        except Exception as e:
            return err(f"作业文件解析失败：{type(e).__name__}: {e}", status_code=400)
    merged_answer = (student_answer or "").strip()
    if extra_text.strip():
        merged_answer = (merged_answer + "\n\n" + extra_text.strip()).strip()
    if len(merged_answer) < 1:
        return err("请填写学生答案，或上传包含答案内容的文件", status_code=400)
    resolved_reference = (reference_answer or "").strip() or None
    matched_question = None
    if not resolved_reference:
        resolved_reference, matched_question = _find_reference_answer_from_bank(db, question_text)
    feedback, meta = generate_assignment_grading((title or "").strip() or "AI批改作业", question_text, merged_answer, resolved_reference, "主观题")
    row = AssignmentSubmission(
        student_id=current_user.id,
        title=(title or "").strip() or "AI批改作业",
        question_text=question_text,
        content=merged_answer,
        reference_answer=resolved_reference,
        ai_score=float(meta.get("ai_score") or 0.0),
        logic_score=float(meta.get("logic_score") or 0.0),
        terminology_score=float(meta.get("terminology_score") or 0.0),
        completeness_score=float(meta.get("completeness_score") or 0.0),
        overall_level=meta.get("overall_level") or "待评估",
        optimized_answer=meta.get("optimized_answer"),
        ai_feedback=feedback,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    db.add(LearningRecord(student_id=current_user.id, record_type="assignment_grading", content=f"标题：{row.title}\n题目：{question_text[:500]}\n参考分：{row.ai_score}\n\n{feedback[:2000]}"))
    db.commit()
    return ok({
        "id": row.id,
        "title": row.title,
        "question_text": row.question_text,
        "content": row.content,
        "reference_answer": row.reference_answer,
        "reference_source_question_id": matched_question.id if matched_question else None,
        "ai_score": row.ai_score,
        "logic_score": row.logic_score,
        "terminology_score": row.terminology_score,
        "completeness_score": row.completeness_score,
        "overall_level": row.overall_level,
        "optimized_answer": row.optimized_answer,
        "ai_feedback": row.ai_feedback,
        "created_at": str(row.created_at),
        "source_file_name": filename,
    }, "AI批改作业完成")


@router.get("/assignment-grading")
def get_assignment_grading_records(current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    rows = db.query(AssignmentSubmission).filter(AssignmentSubmission.student_id == current_user.id).order_by(AssignmentSubmission.id.desc()).all()
    return ok([{
        "id": r.id,
        "title": r.title,
        "question_text": r.question_text,
        "content": r.content,
        "reference_answer": r.reference_answer,
        "ai_score": r.ai_score,
        "logic_score": r.logic_score,
        "terminology_score": r.terminology_score,
        "completeness_score": r.completeness_score,
        "overall_level": r.overall_level,
        "optimized_answer": r.optimized_answer,
        "ai_feedback": r.ai_feedback,
        "created_at": str(r.created_at),
    } for r in rows])


@router.post("/chart-analyses/analyze")
def create_chart_analysis(
    title: str = Form("图表题分析"),
    chart_type: str = Form("图表题"),
    prompt: str = Form(""),
    file: UploadFile = File(...),
    current_user: User = Depends(require_role("student")),
    db: Session = Depends(get_db),
):
    filename = file.filename or "chart.png"
    suffix = Path(filename).suffix.lower()
    if suffix not in {".png", ".jpg", ".jpeg", ".webp", ".bmp"}:
        return err("仅支持上传 png、jpg、jpeg、webp、bmp 图片", status_code=400)
    file_bytes = file.file.read()
    if not file_bytes:
        return err("上传图片为空，请重新选择文件", status_code=400)
    safe_name = f"student_{current_user.id}_{random.randint(100000, 999999)}{suffix}"
    saved_path = CHART_ANALYSIS_UPLOAD_DIR / safe_name
    saved_path.write_bytes(file_bytes)
    image_b64 = base64.b64encode(file_bytes).decode("utf-8")
    feedback, meta = generate_chart_analysis((title or "").strip() or "图表题分析", (chart_type or "").strip() or "图表题", (prompt or "").strip(), image_b64=image_b64)
    knowledge_points = meta.get("knowledge_points") or []
    row = ChartAnalysisRecord(
        student_id=current_user.id,
        title=(title or "").strip() or "图表题分析",
        chart_type=(chart_type or "").strip() or "图表题",
        prompt=(prompt or "").strip(),
        image_path=str(saved_path),
        ai_feedback=feedback,
        knowledge_points_json=json.dumps(knowledge_points, ensure_ascii=False),
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    summary = f"图表类型：{row.chart_type}\n标题：{row.title}\n知识点：{'、'.join(knowledge_points) or '无'}\n\n{feedback[:2000]}"
    db.add(LearningRecord(student_id=current_user.id, record_type="chart_analysis", content=summary))
    db.commit()
    return ok({
        "id": row.id,
        "title": row.title,
        "chart_type": row.chart_type,
        "prompt": row.prompt,
        "image_path": row.image_path,
        "ai_feedback": row.ai_feedback,
        "knowledge_points": knowledge_points,
        "elapsed_seconds": meta.get("elapsed_seconds", 0.0),
        "rag_used": bool(meta.get("rag_used")),
        "rag_sources": meta.get("rag_sources") or [],
        "created_at": str(row.created_at),
    }, "图表题分析完成")


@router.get("/chart-analyses")
def get_chart_analysis_records(current_user: User = Depends(require_role("student")), db: Session = Depends(get_db)):
    rows = db.query(ChartAnalysisRecord).filter(ChartAnalysisRecord.student_id == current_user.id).order_by(ChartAnalysisRecord.id.desc()).all()
    return ok([
        {
            "id": r.id,
            "title": r.title,
            "chart_type": r.chart_type,
            "prompt": r.prompt,
            "image_path": r.image_path,
            "ai_feedback": r.ai_feedback,
            "knowledge_points": json.loads(r.knowledge_points_json or "[]"),
            "created_at": str(r.created_at),
        }
        for r in rows
    ])
