from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import User
from ..schemas import UserRegister, UserLogin, Token, UserOut
from ..auth import get_password_hash, authenticate_user, create_access_token, require_role
from ..utils import ok, err

router = APIRouter(prefix="/api/auth", tags=["auth"])

@router.post("/register")
def register(payload: UserRegister, db: Session = Depends(get_db)):
    if payload.role not in ["student", "teacher", "admin"]:
        return err("角色不合法", status_code=400)
    existing = db.query(User).filter(User.username == payload.username).first()
    if existing:
        return err("用户名已存在", status_code=400)
    user = User(
        username=payload.username,
        password_hash=get_password_hash(payload.password),
        role=payload.role,
        full_name=payload.full_name,
        grade=payload.grade,
        class_name=payload.class_name,
        subject=payload.subject,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return ok(UserOut.model_validate(user).model_dump(), "注册成功")

@router.post("/login")
def login(payload: UserLogin, db: Session = Depends(get_db)):
    user = authenticate_user(db, payload.username, payload.password, payload.role)
    if not user:
        return err("用户名、密码或角色不正确", status_code=401)
    token = create_access_token({"sub": user.username, "role": user.role})
    return ok(Token(
        access_token=token,
        token_type="bearer",
        role=user.role,
        username=user.username
    ).model_dump(), "登录成功")

@router.get("/me")
def me(current_user: User = Depends(require_role("student", "teacher", "admin"))):
    return ok(UserOut.model_validate(current_user).model_dump())
