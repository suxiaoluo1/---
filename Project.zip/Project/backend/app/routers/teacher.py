from pathlib import Path
import json

from fastapi import APIRouter, Depends, File, Form, UploadFile
from sqlalchemy.orm import Session

from ..auth import require_role
from ..analytics import build_teacher_overview
from ..database import get_db
from ..knowledge_graph import build_graph_from_documents
from ..models import (
    AssignmentSubmission,
    ChartAnalysisRecord,
    KnowledgeDocument,
    KnowledgeGraph,
    KnowledgeGraphEdge,
    KnowledgeGraphNode,
    KnowledgePoint,
    LearningRecord,
    PracticeQuestion,
    QuizRecord,
    ReportSubmission,
    TaskAssignment,
    User,
    WrongQuestion,
)
from ..rag import add_document_chunks, delete_knowledge_file_artifacts, extract_text_from_file, remove_document_chunks, save_parsed_text, save_upload_file
from ..practice_bank import parse_question_import, save_question_import_artifacts
from ..schemas import KnowledgeGraphBuildRequest, KnowledgePointCreate, TaskCreate
from ..utils import err, ok

router = APIRouter(prefix="/api/teacher", tags=["teacher"])

@router.get("/overview")
def get_teacher_overview(current_user: User = Depends(require_role("teacher")), db: Session = Depends(get_db)):
    return ok(build_teacher_overview(db, days=7))


@router.get("/students")
def get_students(current_user: User = Depends(require_role("teacher")), db: Session = Depends(get_db)):
    rows = db.query(User).filter(User.role == "student").order_by(User.id.asc()).all()
    return ok([
        {"id": s.id, "username": s.username, "full_name": s.full_name, "grade": s.grade, "class_name": s.class_name}
        for s in rows
    ])

@router.get("/student/{student_id}/records")
def get_student_records(student_id: int, current_user: User = Depends(require_role("teacher")), db: Session = Depends(get_db)):
    records = db.query(LearningRecord).filter(LearningRecord.student_id == student_id).order_by(LearningRecord.id.desc()).all()
    wrongs = db.query(WrongQuestion).filter(WrongQuestion.student_id == student_id).order_by(WrongQuestion.id.desc()).all()
    quizzes = db.query(QuizRecord).filter(QuizRecord.student_id == student_id).order_by(QuizRecord.id.desc()).all()
    reports = db.query(ReportSubmission).filter(ReportSubmission.student_id == student_id).order_by(ReportSubmission.id.desc()).all()
    assignments = db.query(AssignmentSubmission).filter(AssignmentSubmission.student_id == student_id).order_by(AssignmentSubmission.id.desc()).all()
    charts = db.query(ChartAnalysisRecord).filter(ChartAnalysisRecord.student_id == student_id).order_by(ChartAnalysisRecord.id.desc()).all()
    return ok({
        "learning_records": [{"id": r.id, "record_type": r.record_type, "content": r.content, "created_at": str(r.created_at)} for r in records],
        "wrong_questions": [{"id": w.id, "subject": w.subject, "question_text": w.question_text, "analysis": w.analysis, "ai_analysis": w.ai_analysis} for w in wrongs],
        "quiz_records": [{"id": q.id, "subject": q.subject, "score": q.score, "total_score": q.total_score, "summary": q.summary} for q in quizzes],
        "report_submissions": [{"id": rp.id, "title": rp.title, "overall_level": rp.overall_level, "structure_score": rp.structure_score, "terminology_score": rp.terminology_score, "completeness_score": rp.completeness_score, "ai_feedback": rp.ai_feedback, "created_at": str(rp.created_at)} for rp in reports],
        "assignment_submissions": [{"id": a.id, "title": a.title, "ai_score": a.ai_score, "overall_level": a.overall_level, "ai_feedback": a.ai_feedback, "created_at": str(a.created_at)} for a in assignments],
        "chart_analysis_records": [{"id": c.id, "title": c.title, "chart_type": c.chart_type, "prompt": c.prompt, "ai_feedback": c.ai_feedback, "knowledge_points": json.loads(c.knowledge_points_json or '[]'), "created_at": str(c.created_at)} for c in charts],
    })

@router.post("/tasks")
def create_task(payload: TaskCreate, current_user: User = Depends(require_role("teacher")), db: Session = Depends(get_db)):
    task = TaskAssignment(teacher_id=current_user.id, student_id=payload.student_id, title=payload.title, description=payload.description, status="pending")
    db.add(task)
    db.commit()
    db.refresh(task)
    return ok({"id": task.id}, "任务发布成功")

@router.get("/tasks")
def get_tasks(current_user: User = Depends(require_role("teacher")), db: Session = Depends(get_db)):
    tasks = db.query(TaskAssignment).filter(TaskAssignment.teacher_id == current_user.id).order_by(TaskAssignment.id.desc()).all()
    return ok([{"id": t.id, "student_id": t.student_id, "title": t.title, "description": t.description, "status": t.status} for t in tasks])

@router.post("/knowledge-points")
def create_knowledge_point(payload: KnowledgePointCreate, current_user: User = Depends(require_role("teacher")), db: Session = Depends(get_db)):
    row = KnowledgePoint(name=payload.name, subject=payload.subject, description=payload.description, difficulty=payload.difficulty, created_by=current_user.id)
    db.add(row)
    db.commit()
    db.refresh(row)
    return ok({"id": row.id}, "知识点创建成功")

@router.get("/knowledge-points")
def get_knowledge_points(current_user: User = Depends(require_role("teacher")), db: Session = Depends(get_db)):
    rows = db.query(KnowledgePoint).order_by(KnowledgePoint.id.desc()).all()
    return ok([{"id": k.id, "name": k.name, "subject": k.subject, "description": k.description, "difficulty": k.difficulty} for k in rows])

@router.post("/knowledge-documents/upload")
def upload_knowledge_document(
    title: str = Form(...),
    subject: str = Form("通用"),
    source_label: str = Form("教师知识库"),
    file: UploadFile = File(...),
    current_user: User = Depends(require_role("teacher")),
    db: Session = Depends(get_db),
):
    filename = file.filename or ""
    suffix = Path(filename).suffix.lower()
    if suffix not in {".pdf", ".docx", ".txt", ".md", ".pptx"}:
        return err("仅支持上传 pdf、docx、txt、md、pptx 文件", status_code=400)
    saved_path, stored_name = save_upload_file(file)
    try:
        text = extract_text_from_file(saved_path, filename)
        if not text or len(text.strip()) < 20:
            return err("文件可提取内容过少，无法写入知识库", status_code=400)
        clean_title = title.strip() or Path(filename).stem
        clean_subject = (subject or "通用").strip()
        clean_source = (source_label or "教师知识库").strip()
        save_parsed_text(stored_name, clean_title, text)
        doc = KnowledgeDocument(
            title=clean_title,
            subject=clean_subject,
            source_label=clean_source,
            file_name=stored_name,
            file_type=suffix.lstrip("."),
            chunk_count=0,
            uploaded_by=current_user.id,
        )
        db.add(doc)
        db.commit()
        db.refresh(doc)
        chunk_count = add_document_chunks(document_db_id=doc.id, title=doc.title, subject=doc.subject, source_label=doc.source_label, file_name=filename, text=text)
        doc.chunk_count = chunk_count
        db.commit()
        return ok({"id": doc.id, "title": doc.title, "subject": doc.subject, "source_label": doc.source_label, "file_type": doc.file_type, "chunk_count": doc.chunk_count}, "知识库文件上传并入库成功")
    except Exception as e:
        return err(f"知识库入库失败：{type(e).__name__}: {e}", status_code=500)

@router.get("/knowledge-documents")
def list_knowledge_documents(current_user: User = Depends(require_role("teacher")), db: Session = Depends(get_db)):
    rows = db.query(KnowledgeDocument).order_by(KnowledgeDocument.id.desc()).all()
    return ok([{ "id": r.id, "title": r.title, "subject": r.subject, "source_label": r.source_label, "file_name": r.file_name, "file_type": r.file_type, "chunk_count": r.chunk_count, "created_at": str(r.created_at)} for r in rows])

@router.delete("/knowledge-documents/{doc_id}")
def delete_knowledge_document(doc_id: int, current_user: User = Depends(require_role("teacher")), db: Session = Depends(get_db)):
    doc = db.query(KnowledgeDocument).filter(KnowledgeDocument.id == doc_id).first()
    if not doc:
        return err("知识库文件不存在", status_code=404)
    remove_document_chunks(doc.id)
    delete_knowledge_file_artifacts(doc.file_name)
    db.delete(doc)
    db.commit()
    return ok({"id": doc_id}, "知识库文件删除成功")

@router.post("/knowledge-graphs/build")
def teacher_build_knowledge_graph(payload: KnowledgeGraphBuildRequest, current_user: User = Depends(require_role("teacher")), db: Session = Depends(get_db)):
    try:
        result = build_graph_from_documents(db, graph_name=payload.graph_name.strip() or f"{payload.subject}知识图谱", subject=(payload.subject or "通用").strip(), document_ids=payload.document_ids or None, created_by=current_user.id)
        return ok({"graph_id": result.graph_id, "node_count": result.node_count, "edge_count": result.edge_count, "source_document_ids": result.source_document_ids, "source_titles": result.source_titles}, "知识图谱构建成功")
    except Exception as e:
        return err(f"知识图谱构建失败：{type(e).__name__}: {e}", status_code=500)

@router.get("/knowledge-graphs")
def teacher_list_knowledge_graphs(current_user: User = Depends(require_role("teacher")), db: Session = Depends(get_db)):
    rows = db.query(KnowledgeGraph).order_by(KnowledgeGraph.id.desc()).all()
    return ok([{"id": g.id, "name": g.name, "subject": g.subject, "node_count": g.node_count, "edge_count": g.edge_count, "source_titles": json.loads(g.source_titles_json or "[]"), "created_at": str(g.created_at)} for g in rows])

@router.delete("/knowledge-graphs/{graph_id}")
def teacher_delete_knowledge_graph(graph_id: int, current_user: User = Depends(require_role("teacher")), db: Session = Depends(get_db)):
    graph = db.query(KnowledgeGraph).filter(KnowledgeGraph.id == graph_id).first()
    if not graph:
        return err("知识图谱不存在", status_code=404)
    db.query(KnowledgeGraphEdge).filter(KnowledgeGraphEdge.graph_id == graph_id).delete()
    db.query(KnowledgeGraphNode).filter(KnowledgeGraphNode.graph_id == graph_id).delete()
    db.delete(graph)
    db.commit()
    return ok({"id": graph_id}, "知识图谱删除成功")


@router.post("/practice-questions/import")
def import_practice_questions(
    subject: str = Form("软件项目管理"),
    source_label: str = Form("教师导入题库"),
    file: UploadFile = File(...),
    current_user: User = Depends(require_role("teacher")),
    db: Session = Depends(get_db),
):
    filename = file.filename or ""
    file_bytes = file.file.read()
    items, errors = parse_question_import(file_bytes, filename, subject or "软件项目管理", source_label or "教师导入题库")
    if errors and not items:
        return err("；".join(errors), status_code=400)
    artifacts = save_question_import_artifacts(file_bytes, filename, items)
    created_count = 0
    skipped_count = 0
    try:
        for item in items:
            exists = db.query(PracticeQuestion).filter(PracticeQuestion.chapter == item['chapter'], PracticeQuestion.question_text == item['question_text']).first()
            if exists:
                skipped_count += 1
                continue
            db.add(PracticeQuestion(
                subject=item['subject'],
                chapter=item['chapter'],
                difficulty=item.get('difficulty', '适中'),
                question_type=item['question_type'],
                question_text=item['question_text'],
                options_json=json.dumps(item['options'], ensure_ascii=False) if item.get('options') is not None else None,
                correct_answer=item['correct_answer'],
                analysis=item.get('analysis'),
                knowledge_points_json=json.dumps(item.get('knowledge_points') or [], ensure_ascii=False),
                source_label=item.get('source_label') or source_label,
            ))
            created_count += 1
        db.commit()
    except Exception as e:
        db.rollback()
        return err(f"题库导入失败：{type(e).__name__}: {e}", status_code=500)
    return ok({
        'created_count': created_count,
        'skipped_count': skipped_count,
        'error_count': len(errors),
        'errors': errors[:20],
        'upload_path': artifacts['upload_path'],
        'parsed_path': artifacts['parsed_path'],
    }, '题库导入完成')


@router.get("/practice-questions")
def teacher_list_practice_questions(
    keyword: str | None = None,
    chapter: str | None = None,
    current_user: User = Depends(require_role("teacher")),
    db: Session = Depends(get_db),
):
    query = db.query(PracticeQuestion)
    if keyword:
        query = query.filter(PracticeQuestion.question_text.contains(keyword.strip()))
    if chapter:
        query = query.filter(PracticeQuestion.chapter == chapter.strip())
    rows = query.order_by(PracticeQuestion.id.desc()).limit(200).all()
    return ok([{
        'id': r.id,
        'subject': r.subject,
        'chapter': r.chapter,
        'difficulty': r.difficulty or '适中',
        'question_type': r.question_type,
        'question_text': r.question_text,
        'correct_answer': r.correct_answer,
        'knowledge_points': json.loads(r.knowledge_points_json or '[]'),
        'source_label': r.source_label,
        'created_at': str(r.created_at),
    } for r in rows])
