import json

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from ..auth import require_role
from ..database import get_db
from ..knowledge_graph import build_graph_from_documents, get_graph_payload_for_student
from ..models import KnowledgeGraph, KnowledgeGraphEdge, KnowledgeGraphNode, User
from ..schemas import KnowledgeGraphBuildRequest
from ..utils import err, ok

router = APIRouter(prefix="/api/graph", tags=["graph"])


@router.post("/build")
def build_knowledge_graph(
    payload: KnowledgeGraphBuildRequest,
    current_user: User = Depends(require_role("teacher", "admin")),
    db: Session = Depends(get_db),
):
    try:
        result = build_graph_from_documents(
            db,
            graph_name=payload.graph_name.strip() or f"{payload.subject}知识图谱",
            subject=(payload.subject or "通用").strip(),
            document_ids=payload.document_ids or None,
            created_by=current_user.id,
        )
        return ok(
            {
                "graph_id": result.graph_id,
                "node_count": result.node_count,
                "edge_count": result.edge_count,
                "source_document_ids": result.source_document_ids,
                "source_titles": result.source_titles,
            },
            "知识图谱构建成功",
        )
    except Exception as e:
        return err(f"知识图谱构建失败：{type(e).__name__}: {e}", status_code=500)


@router.get("/list")
def list_knowledge_graphs(
    subject: str | None = Query(default=None),
    current_user: User = Depends(require_role("teacher", "student", "admin")),
    db: Session = Depends(get_db),
):
    q = db.query(KnowledgeGraph)
    if subject:
        q = q.filter(KnowledgeGraph.subject == subject)
    rows = q.order_by(KnowledgeGraph.id.desc()).all()
    return ok([
        {
            "id": g.id,
            "name": g.name,
            "subject": g.subject,
            "node_count": g.node_count,
            "edge_count": g.edge_count,
            "build_status": g.build_status,
            "source_titles": json.loads(g.source_titles_json or "[]"),
            "created_at": str(g.created_at),
        }
        for g in rows
    ])


@router.get("/{graph_id}")
def get_graph_detail(
    graph_id: int,
    current_user: User = Depends(require_role("teacher", "student", "admin")),
    db: Session = Depends(get_db),
):
    graph = db.query(KnowledgeGraph).filter(KnowledgeGraph.id == graph_id).first()
    if not graph:
        return err("知识图谱不存在", status_code=404)

    if current_user.role == "student":
        return ok(get_graph_payload_for_student(db, graph, current_user.id))

    nodes = db.query(KnowledgeGraphNode).filter(KnowledgeGraphNode.graph_id == graph_id).all()
    edges = db.query(KnowledgeGraphEdge).filter(KnowledgeGraphEdge.graph_id == graph_id).all()
    return ok(
        {
            "graph_id": graph.id,
            "name": graph.name,
            "subject": graph.subject,
            "node_count": len(nodes),
            "edge_count": len(edges),
            "nodes": [
                {
                    "id": n.id,
                    "name": n.name,
                    "category": n.category,
                    "description": n.description,
                    "source_count": n.source_count,
                }
                for n in nodes
            ],
            "edges": [
                {
                    "id": e.id,
                    "source": e.source_node_id,
                    "target": e.target_node_id,
                    "relation": e.relation,
                    "weight": float(e.weight or 1.0),
                    "evidence": e.evidence,
                }
                for e in edges
            ],
            "source_titles": json.loads(graph.source_titles_json or "[]"),
        }
    )


@router.get("/student/latest")
def get_latest_student_graph(
    subject: str | None = Query(default=None),
    current_user: User = Depends(require_role("student")),
    db: Session = Depends(get_db),
):
    q = db.query(KnowledgeGraph)
    if subject and subject != "全部":
        q = q.filter(KnowledgeGraph.subject == subject)
    graph = q.order_by(KnowledgeGraph.id.desc()).first()
    if not graph:
        return err("当前还没有可用的知识图谱，请先由教师端构建图谱", status_code=404)
    return ok(get_graph_payload_for_student(db, graph, current_user.id))
