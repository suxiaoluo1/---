import json
import re
import time
from difflib import SequenceMatcher
from typing import Any

import requests

from .config import settings
from .course_data import COURSE_NAME, DEFAULT_SUBJECT, POINT_TO_MODULE, infer_points
from .rag import build_rag_context, search_knowledge




SYSTEM_IDENTITY_PATTERNS = [
    r"你是谁",
    r"你叫什么",
    r"你是干什么的",
    r"你能做什么",
    r"你的功能是什么",
    r"你的能力",
    r"你有什么能力",
    r"你的角色",
    r"你的定位",
    r"你来自哪里",
    r"你的知识库",
    r"知识库.*什么",
    r"知识.*截止",
    r"介绍一下你自己",
    r"who are you",
    r"what can you do",
]

GREETING_PATTERNS = [
    r"^你好[呀啊]?$",
    r"^您好$",
    r"^hi$",
    r"^hello$",
    r"^谢谢$",
    r"^thanks?$",
]

PROJECT_IDENTITY_PROMPT = (
    "【身份设定】你是智能化学习助手小智，"
    f"主要服务于《{COURSE_NAME}》课程学习场景。你的定位不是通用聊天机器人，也不要自称某个商业平台客服、"
    "某个公司官方助手或具有真实人格的老师。\n"
    "【核心能力】你可以结合课程知识库检索、学生学习记录、专项练习、错题本、知识图谱、学习进度、"
    "学习路径推荐，以及用户上传的文本、文档或图片，完成知识点讲解、错题分析、图表分析、实验报告辅导、"
    "AI作业批改、专项练习建议和学习规划。\n"
    "【回答边界】如果系统没有检索到课程资料，必须说明“知识库中未检索到可靠相关资料，本次为AI根据通用能力回答”。"
    "不要编造不存在的资料来源、联网能力、模型厂商、发布时间、证书、教师身份或系统之外的功能。\n"
    "【身份类问题规则】当用户问“你是谁、你能做什么、你的功能是什么、你来自哪里、你的知识库是什么”等问题时，"
    "你仍然需要经过模型自然组织语言回答，但内容必须围绕上述身份、能力、边界展开；回答应简洁、真实、准确，"
    "适合本科毕业设计答辩展示。"
)

PROJECT_IDENTITY_ANSWER = (
    f"我是智能化学习助手———小智，服务于《{COURSE_NAME}》课程学习场景。"
    "我可以结合课程知识库、学生学习记录、专项练习、错题本、知识图谱和学习进度，为学生提供知识讲解、"
    "错题分析、图表分析、实验报告辅导、AI批改和个性化学习建议。"
    "如果没有检索到相关课程资料，我会明确说明，并基于通用能力进行回答。"
)


def is_identity_prompt(prompt: str) -> bool:
    lowered = (prompt or "").strip().lower()
    if not lowered:
        return False
    return any(re.search(pattern, lowered) for pattern in SYSTEM_IDENTITY_PATTERNS)


COURSE_STRONG_KEYWORDS = [
    "软件项目管理", "项目管理", "项目集成管理", "项目范围管理", "项目成本管理", "软件项目时间管理",
    "软件项目质量管理", "软件项目人力资源管理", "软件项目沟通管理", "软件项目风险管理", "软件项目采购管理",
    "范围管理", "进度管理", "成本管理", "质量管理", "风险管理", "采购管理", "沟通管理", "人力资源管理",
    "项目章程", "需求基线", "WBS", "wbs", "工作分解结构", "范围定义", "范围蔓延", "关键路径", "网络图",
    "甘特图", "PERT", "pert", "里程碑", "挣值", "挣值分析", "EV", "PV", "AC", "CV", "SV", "CPI", "SPI",
    "Scrum", "scrum", "Sprint", "sprint", "燃尽图", "用户故事", "产品待办列表", "每日站会", "风险识别",
    "风险分析", "风险应对", "风险监控", "质量保证", "质量控制", "缺陷跟踪", "验收管理", "结项报告",
]

# “项目”这个词本身太宽泛，旅行规划、个人计划也可能出现，所以只有同时出现下列管理语境时才认为是课程问题。
PROJECT_CONTEXT_KEYWORDS = [
    "范围", "进度", "成本", "质量", "风险", "采购", "沟通", "资源", "干系人", "章程", "需求", "基线",
    "交付", "可交付", "工期", "预算", "估算", "监控", "控制", "收尾", "立项", "生命周期", "团队",
]

GENERAL_LIFE_HINTS = [
    "旅行", "旅游", "北京旅行", "去哪", "在哪", "天气", "吃什么", "路线", "酒店", "机票", "景点", "餐厅",
    "1+1", "一加一", "等于几", "今天", "明天", "翻译", "写一首", "讲个笑话",
]


def is_course_related_prompt(prompt: str) -> bool:
    """判断问题是否真的需要《软件项目管理》课程知识库。

    这里故意比之前更保守：
    - 身份类、寒暄、生活常识、简单算术不进 RAG；
    - 只有出现课程强关键词，或“项目”同时带有管理语境时，才允许检索课程知识库。
    """
    text = (prompt or "").strip()
    lowered = text.lower()
    if not text:
        return False
    if is_identity_prompt(text):
        return False
    if any(re.search(pattern, lowered) for pattern in GREETING_PATTERNS):
        return False
    # 明显生活类/常识类问题，除非同时出现明确课程词，否则不检索课程资料。
    if any(h.lower() in lowered or h in text for h in GENERAL_LIFE_HINTS):
        has_strong_course = any(k.lower() in lowered or k in text for k in COURSE_STRONG_KEYWORDS if k not in {"EV", "PV", "AC", "CV", "SV"})
        if not has_strong_course:
            return False
    if infer_points(text):
        return True
    if any(k.lower() in lowered or k in text for k in COURSE_STRONG_KEYWORDS):
        return True
    if "项目" in text and any(k in text for k in PROJECT_CONTEXT_KEYWORDS):
        return True
    return False


def filter_relevant_rag_docs(prompt: str, docs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """对向量召回结果再做一道保险过滤，避免任意问题都展示课程资料来源。"""
    if not docs or not is_course_related_prompt(prompt):
        return []
    lowered_prompt = (prompt or "").lower()
    points = set(infer_points(prompt))
    filtered: list[dict[str, Any]] = []
    for doc in docs:
        content = (doc.get("content") or "")[:1200]
        title = doc.get("title") or ""
        joined = f"{title}\n{content}".lower()
        score = doc.get("score")
        score_ok = score is None or float(score) >= 0.18
        keyword_ok = any(k.lower() in joined for k in COURSE_STRONG_KEYWORDS if len(k) >= 2)
        point_ok = any(p.lower() in joined for p in points) if points else False
        query_overlap_ok = any(k.lower() in lowered_prompt and k.lower() in joined for k in COURSE_STRONG_KEYWORDS if len(k) >= 2)
        if score_ok and (point_ok or query_overlap_ok or keyword_ok):
            filtered.append(doc)
    return filtered[:4]


def _extract_quoted_terms(prompt: str) -> list[str]:
    terms = []
    for match in re.findall(r'[“"]([^”"]{1,20})[”"]', prompt or ""):
        value = str(match).strip()
        if value and value not in terms:
            terms.append(value)
    return terms


def build_rag_search_queries(prompt: str, mode: str = "step_by_step") -> list[str]:
    text = (prompt or "").strip()
    queries: list[str] = []

    def add(candidate: str | None):
        value = (candidate or "").strip()
        if value and value not in queries:
            queries.append(value)

    add(text)
    points = infer_points(text)
    quoted_terms = _extract_quoted_terms(text)

    for term in quoted_terms[:3]:
        add(term)
        add(f"{term} {COURSE_NAME}")

    for point in points[:4]:
        add(point)
        module = POINT_TO_MODULE.get(point)
        if module:
            add(f"{point} {module} {COURSE_NAME}")
        add(f"{point} {COURSE_NAME} 知识点讲解")
        add(f"{point} 定义 方法 场景")

    if mode == "knowledge_explain" and points:
        add(f"{' '.join(points[:2])} 课程知识库 复习建议")

    if mode == "wrong_analysis" and points:
        add(f"{' '.join(points[:2])} 易错点 正确思路")

    return queries[:8]


def retrieve_rag_docs(prompt: str, mode: str = "step_by_step", subject_hint: str | None = None, top_k: int = 4) -> list[dict[str, Any]]:
    merged: list[dict[str, Any]] = []
    seen = set()
    for query in build_rag_search_queries(prompt, mode=mode):
        results = search_knowledge(query, subject_hint=subject_hint or COURSE_NAME, top_k=top_k)
        for item in results:
            key = (item.get("title"), item.get("file_name"), item.get("chunk_index"))
            if key in seen:
                continue
            seen.add(key)
            merged.append(item)
    merged.sort(key=lambda x: x.get("score") or 0.0, reverse=True)
    return merged[:top_k]


def classify_rag_intent(prompt: str, mode: str = "step_by_step", has_uploaded_file: bool = False, has_image: bool = False) -> dict[str, Any]:
    text = (prompt or "").strip()
    lowered = text.lower()

    # 最高优先级：身份类、寒暄和明显通用问题不检索课程知识库。
    # 即使前端当前模式停留在“知识点讲解”，这些问题也不能误触发 RAG。
    if is_identity_prompt(text):
        return {"rag_allowed": False, "reason": "system_identity", "label": "系统身份说明"}

    for pattern in GREETING_PATTERNS:
        if re.search(pattern, lowered):
            return {"rag_allowed": False, "reason": "greeting", "label": "寒暄互动"}

    if has_uploaded_file or has_image:
        return {"rag_allowed": True, "reason": "uploaded_material", "label": "结合上传材料学习"}

    explicit_material_request = any(k in text or k in lowered for k in ["课程知识库", "教师资料", "课件", "教材", "资料来源", "根据资料", "结合资料"])
    course_related = is_course_related_prompt(text)

    # 只有真正课程相关的问题，或用户明确要求结合课程资料时，才允许进入 RAG。
    if explicit_material_request and course_related:
        return {"rag_allowed": True, "reason": "explicit_material_request", "label": "要求参考课程资料"}

    if course_related:
        if infer_points(text):
            return {"rag_allowed": True, "reason": "detected_knowledge_point", "label": "识别到课程知识点"}
        return {"rag_allowed": True, "reason": "course_question", "label": "课程学习问题"}

    # 这些模式本身是学习任务，但也不能不看问题内容就强制检索。
    # 图表、报告、作业、错题如果没有上传/课程关键词，交给模型通用能力回答，并在前端提示未命中知识库。
    if mode in {"wrong_analysis", "knowledge_explain", "chart_analysis", "report_guidance", "ai_grading"}:
        return {"rag_allowed": False, "reason": "learning_mode_but_general_prompt", "label": "学习模式下的普通问题"}

    return {"rag_allowed": False, "reason": "general_chat", "label": "普通对话"}


def normalize_subject(subject: str | None) -> str:
    return DEFAULT_SUBJECT


def detect_subject(prompt: str, subject: str | None = None) -> str:
    return DEFAULT_SUBJECT


def detect_question_type(prompt: str, subject_key: str, mode: str) -> str:
    text = (prompt or "").lower()
    if is_identity_prompt(prompt):
        return "系统身份与能力说明"
    if mode == "wrong_analysis":
        return "错题分析"
    if mode == "knowledge_explain":
        return "知识点讲解"
    if mode == "report_guidance":
        return "实验报告辅导"
    if mode == "ai_grading":
        return "作业批改"
    if mode == "chart_analysis":
        return "图表题分析"
    if any(k in text for k in ["关键路径", "网络图", "pert", "甘特"]):
        return "进度网络图分析"
    if any(k in text for k in ["evm", "挣值", "cv", "sv", "cpi", "spi"]):
        return "挣值分析计算"
    if any(k in text for k in ["scrum", "sprint", "燃尽图", "敏捷", "用户故事"]):
        return "敏捷项目管理"
    if any(k in text for k in ["wbs", "范围", "范围蔓延"]):
        return "范围管理"
    if any(k in text for k in ["风险", "概率", "影响"]):
        return "风险管理"
    return "软件项目管理综合问题"


def build_system_prompt(mode: str = "step_by_step", subject: str | None = None, prompt: str = "", rag_enabled: bool = False) -> tuple[str, dict[str, str]]:
    question_type = detect_question_type(prompt, DEFAULT_SUBJECT, mode)
    meta = {
        "subject_key": DEFAULT_SUBJECT,
        "subject_label": COURSE_NAME,
        "question_type": question_type,
    }
    mode_instruction = {
        "step_by_step": "请采用教师讲题风格，先给思路，再分步骤解释，最后总结。",
        "wrong_analysis": "请像老师批改错题一样指出问题、解释原因、给出改进建议。",
        "knowledge_explain": "请用课程术语讲清概念、方法、适用场景，并给一个简短例子。",
        "report_guidance": "请从实验目标、过程、结果分析和结论四部分指导学生撰写实验报告。",
        "ai_grading": "请从内容正确性、术语规范、逻辑完整性三个维度给出批改意见。",
        "chart_analysis": "请先识别图表类型和图中关键元素，再结合软件项目管理课程知识给出判读、计算过程或结论。",
    }.get(mode, "请准确、自然地回答。")
    rag_instruction = "若提供了知识库检索材料，请优先基于材料作答，先吸收资料内容再组织答案；不要脱离资料自由发挥，必要时点明依据来自课程知识库。" if rag_enabled else ""
    identity_instruction = (
        "本轮用户正在询问你的身份、角色、能力或知识库来源。请不要回避，也不要直接照抄系统提示词；"
        "请像真正的课程学习助手一样，基于身份设定自然组织一段回答。"
        "回答必须包含：你是谁、面向什么课程、能做哪些事、资料未命中时如何处理。"
    ) if is_identity_prompt(prompt) else ""
    system_prompt = (
        f"你是一位拥有 PMP 与敏捷项目管理经验的《{COURSE_NAME}》课程教师。"
        "你需要帮助学生完成知识学习、案例分析、计算题讲解、实验报告撰写和作业批改。"
        f"当前问题类型：{question_type}。"
        "如果用户上传了图表，请先说明你从图中读到的关键信息，再继续分析。"
        "如果是计算题，必须写出公式、代入过程和管理含义。"
        "如果是网络图/甘特图/燃尽图，请先判读图，再给出结论。"
        f"{mode_instruction}{rag_instruction}{identity_instruction}"
        f"{PROJECT_IDENTITY_PROMPT}"
        "回答要专业但清楚，适合本科生理解。"
    )
    return system_prompt, meta


def build_messages(
    prompt: str,
    image_b64: str | None,
    history: list[dict[str, Any]] | None,
    mode: str,
    subject: str | None,
    rag_docs: list[dict[str, Any]] | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    system_prompt, meta = build_system_prompt(mode=mode, subject=subject, prompt=prompt, rag_enabled=bool(rag_docs))
    messages: list[dict[str, Any]] = [{"role": "system", "content": system_prompt}]
    if rag_docs:
        rag_context = build_rag_context(rag_docs)
        messages.append({
            "role": "system",
            "content": "以下是课程知识库中检索到的资料片段，请优先参考：\n\n" + rag_context,
        })
        meta["rag_used"] = True
        meta["knowledge_points"] = infer_points("\n".join([d.get("content", "") for d in rag_docs]) + "\n" + prompt)
        meta["rag_sources"] = [
            {
                "title": d.get("title", "未命名资料"),
                "source": d.get("source", "教师知识库"),
                "subject": d.get("subject", COURSE_NAME),
                "file_name": d.get("file_name"),
                "chunk_index": d.get("chunk_index"),
            }
            for d in rag_docs
        ]
    else:
        meta["rag_used"] = False
        meta["knowledge_points"] = infer_points(prompt)
        meta["rag_sources"] = []

    if history:
        for item in history[-6:]:
            role = item.get("role")
            content = (item.get("content") or "").strip()
            if role in {"user", "assistant"} and content:
                msg = {"role": role, "content": content[:2000]}
                if role == "user" and item.get("image_b64"):
                    msg["images"] = [item["image_b64"]]
                messages.append(msg)

    user_msg = {"role": "user", "content": prompt}
    if image_b64:
        user_msg["images"] = [image_b64]
    messages.append(user_msg)
    return messages, meta


def ollama_chat_once(
    prompt: str,
    image_b64: str | None,
    options: dict,
    history: list[dict[str, Any]] | None = None,
    mode: str = "step_by_step",
    subject: str | None = None,
    use_rag: bool = True,
    has_uploaded_file: bool = False,
) -> tuple[str, float, dict[str, Any]]:
    intent_meta = classify_rag_intent(prompt=prompt, mode=mode, has_uploaded_file=has_uploaded_file, has_image=bool(image_b64))
    actual_use_rag = bool(use_rag and intent_meta.get("rag_allowed"))

    # 身份类问题不再直接返回固定文本，而是进入模型生成流程。
    # 这里只关闭 RAG 检索，避免“你是谁”这类问题被错误匹配到课程资料；
    # 角色、能力和回答边界由 build_system_prompt 中的 PROJECT_IDENTITY_PROMPT 统一约束。
    if is_identity_prompt(prompt) and not image_b64 and not has_uploaded_file:
        actual_use_rag = False

    rag_docs = retrieve_rag_docs(prompt, mode=mode, subject_hint=COURSE_NAME, top_k=4) if actual_use_rag else []
    rag_docs = filter_relevant_rag_docs(prompt, rag_docs) if rag_docs else []
    if actual_use_rag and not rag_docs:
        actual_use_rag = False
    messages, meta = build_messages(prompt=prompt, image_b64=image_b64, history=history, mode=mode, subject=subject, rag_docs=rag_docs)
    meta["rag_allowed"] = bool(intent_meta.get("rag_allowed"))
    meta["intent_label"] = intent_meta.get("label")
    meta["rag_reason"] = intent_meta.get("reason")
    payload = {"model": settings.OLLAMA_MODEL, "messages": messages, "stream": False, "options": options}
    t0 = time.time()
    r = requests.post(f"{settings.OLLAMA_BASE_URL.rstrip('/')}/api/chat", json=payload, timeout=600)
    r.raise_for_status()
    data = r.json()
    answer = data.get("message", {}).get("content", "")
    return answer, round(time.time() - t0, 2), meta



def _report_fallback_feedback(title: str, content: str) -> tuple[str, dict[str, Any]]:
    text = (content or "").strip()
    lowered = text.lower()

    sections = [
        ("实验目的", ["实验目的", "目的", "目标"]),
        ("实验过程", ["实验过程", "过程", "步骤", "实施过程"]),
        ("结果分析", ["结果分析", "分析", "结果", "实验结果"]),
        ("结论", ["结论", "总结", "心得", "收获"]),
    ]
    found_sections = []
    for name, keys in sections:
        if any(k in text for k in keys):
            found_sections.append(name)

    structure_score = round(len(found_sections) / len(sections) * 100, 1)
    term_hits = sum(1 for k in ["项目", "进度", "范围", "成本", "风险", "质量", "WBS", "关键路径", "挣值", "Scrum"] if k.lower() in lowered or k in text)
    terminology_score = min(100.0, round(35 + term_hits * 8, 1)) if text else 0.0

    length = len(text)
    completeness_score = 40.0
    if length >= 200:
        completeness_score += 20
    if length >= 400:
        completeness_score += 20
    if length >= 700:
        completeness_score += 20
    completeness_score = min(100.0, completeness_score)
    ai_score = round((structure_score + terminology_score + completeness_score) / 3, 1)

    if ai_score >= 85:
        level = "优秀"
    elif ai_score >= 70:
        level = "良好"
    elif ai_score >= 60:
        level = "合格"
    else:
        level = "需改进"

    missing = [name for name, _ in sections if name not in found_sections]
    highlights = []
    if found_sections:
        highlights.append("已覆盖这些核心结构：" + "、".join(found_sections))
    if term_hits:
        highlights.append(f"已使用 {term_hits} 个以上课程相关术语，具备一定专业表达。")
    if length >= 200:
        highlights.append("报告内容已有一定展开，不是仅有几句概述。")
    if not highlights:
        highlights.append("已经开始围绕课程实验进行撰写，可在此基础上继续完善。")

    improvements = []
    if missing:
        improvements.append("建议补齐这些部分：" + "、".join(missing) + "。")
    if term_hits < 4:
        improvements.append("建议增加“范围管理、进度管理、风险识别、关键路径、挣值分析”等课程术语。")
    if length < 200:
        improvements.append("建议补充实验场景、关键步骤、结果分析与结论，使内容更完整。")
    improvements.append("每个部分最后补一句“体现了什么课程知识点、它对项目管理有什么意义”。")

    feedback = (
        f"AI评分：{ai_score}/100\n"
        + "亮点：\n- " + "\n- ".join(highlights)
        + "\n\n改进建议：\n- " + "\n- ".join(improvements)
    )
    return feedback, {
        "ai_score": ai_score,
        "structure_score": structure_score,
        "terminology_score": terminology_score,
        "completeness_score": completeness_score,
        "overall_level": level,
        "highlights": highlights,
        "improvements": improvements,
    }


def generate_report_guidance(title: str, content: str) -> tuple[str, dict[str, Any]]:
    fallback_text, scores = _report_fallback_feedback(title, content)
    prompt = (
        f"请对下面这份《{COURSE_NAME}》课程实验报告草稿进行辅导。"
        "你必须严格输出 JSON，字段仅允许为 ai_score、highlights、improvements。"
        "其中 highlights 和 improvements 都必须是字符串数组。"
        "评分用于帮助学生理解当前完成度，不要虚高。"
        "改进建议要贴近《软件项目管理》课程，避免空话。"
        f"\n\n标题：{title}\n\n报告内容：\n{content}"
    )
    try:
        answer, elapsed, meta = ollama_chat_once(
            prompt=prompt,
            image_b64=None,
            history=[],
            mode="report_guidance",
            subject=COURSE_NAME,
            options={"temperature": 0.2, "top_p": 0.9, "top_k": 40, "num_predict": 600, "num_ctx": 8192},
            use_rag=True,
        )
        parsed = None
        if answer and answer.strip():
            try:
                parsed = json.loads(answer.strip())
            except Exception:
                m = re.search(r'\{[\s\S]*\}', answer.strip())
                if m:
                    try:
                        parsed = json.loads(m.group(0))
                    except Exception:
                        parsed = None
        if isinstance(parsed, dict):
            highlights = parsed.get('highlights') or scores.get('highlights') or []
            improvements = parsed.get('improvements') or scores.get('improvements') or []
            if isinstance(highlights, str):
                highlights = [highlights]
            if isinstance(improvements, str):
                improvements = [improvements]
            ai_score = float(parsed.get('ai_score') or scores.get('ai_score') or 0.0)
            feedback = (
                f"AI评分：{round(ai_score,1)}/100\n"
                + "亮点：\n- " + "\n- ".join([str(x) for x in highlights if str(x).strip()])
                + "\n\n改进建议：\n- " + "\n- ".join([str(x) for x in improvements if str(x).strip()])
            )
            return feedback, scores | {
                'ai_score': round(ai_score, 1),
                'highlights': [str(x) for x in highlights if str(x).strip()],
                'improvements': [str(x) for x in improvements if str(x).strip()],
                'elapsed_seconds': elapsed,
                'rag_used': bool(meta.get('rag_used')),
            }
    except Exception:
        pass
    return fallback_text, scores | {"elapsed_seconds": 0.0, "rag_used": False}



def _chart_fallback_feedback(title: str, chart_type: str, prompt: str) -> tuple[str, dict[str, Any]]:
    text = (prompt or '').strip()
    chart_type = (chart_type or '图表题').strip()
    points = infer_points(f"{chart_type}\n{text}")
    advice_map = {
        '甘特图': '建议重点关注任务起止时间、前后依赖关系、关键里程碑和是否存在延期任务。',
        '网络图': '建议重点识别活动顺序、前置关系、最早/最迟时间和关键路径。',
        '燃尽图': '建议重点比较实际剩余工作量与理想趋势线，判断迭代是否偏离计划。',
        '挣值分析图': '建议重点结合 EV、PV、AC 以及 CV、SV、CPI、SPI 判断成本和进度状态。',
        '风险矩阵图': '建议重点说明风险发生概率、影响程度及其优先处理顺序。',
    }
    template = [
        f'图表标题：{title or "未命名图表题"}',
        f'图表类型：{chart_type}',
        '一、图中应重点读取的信息：题目通常需要先识别图表中的关键对象、时间/数值变化和任务关系。',
        f'二、分析思路：{advice_map.get(chart_type, "建议先概括图中关键信息，再结合题目要求逐步分析。")}',
        '三、课程知识联系：应结合《软件项目管理》中的进度管理、范围管理、成本管理、风险管理或敏捷项目管理相关知识解释。',
        f'四、作答建议：{text or "请补充题目要求，例如需要判断延期、计算关键路径、解释挣值指标或分析风险优先级。"}',
        '五、结论写法建议：先给出结论，再给出依据，最后说明该结论对项目管理的意义。',
    ]
    return "\n\n".join(template), {'knowledge_points': points or infer_points(chart_type)}


def generate_chart_analysis(title: str, chart_type: str, prompt: str, image_b64: str | None = None) -> tuple[str, dict[str, Any]]:
    user_prompt = (
        f'请分析这道《{COURSE_NAME}》课程图表题。\n'
        f'图表标题：{title or "未命名图表题"}\n'
        f'图表类型：{chart_type or "图表题"}\n'
        '请按以下结构回答：\n'
        '1. 图中读取到的关键信息\n'
        '2. 解题思路\n'
        '3. 计算过程或判读依据\n'
        '4. 最终结论\n'
        '5. 涉及知识点\n'
        f'补充题目要求：{prompt or "请结合图中信息完成分析。"}'
    )
    try:
        answer, elapsed, meta = ollama_chat_once(
            prompt=user_prompt,
            image_b64=image_b64,
            history=[],
            mode='chart_analysis',
            subject=COURSE_NAME,
            options={
                'temperature': 0.3,
                'top_p': 0.9,
                'top_k': 40,
                'num_predict': 1200,
                'num_ctx': 8192,
            },
            use_rag=True,
        )
        kp = meta.get('knowledge_points') or infer_points(f"{chart_type}\n{prompt}\n{answer}")
        return answer, {'elapsed_seconds': elapsed, 'knowledge_points': kp, 'rag_used': bool(meta.get('rag_used')), 'rag_sources': meta.get('rag_sources') or []}
    except Exception:
        return _chart_fallback_feedback(title, chart_type, prompt)





def _wrong_question_fallback(question_text: str, student_answer: str, correct_answer: str, rag_context: str) -> str:
    concept_hint = rag_context[:260].replace("\n", " ") if rag_context else "课件中通常会强调题干对应的核心概念、判断依据和标准作答关键词。"
    return (
        f"你为什么错：\n"
        f"- 这道题的失分点通常在于没有准确抓住题目所对应的课程概念，或答案里缺少标准作答关键词。\n"
        f"- 你的答案：{student_answer or '未作答'}\n\n"
        f"课件中的相关概念：\n"
        f"- {concept_hint}\n\n"
        f"正确思路：\n"
        f"- 先判断题目考查的是哪一个知识点，再结合标准答案提炼 2~3 个必须写出的关键词。\n"
        f"- 标准答案：{correct_answer}\n\n"
        f"下次避免建议：\n"
        f"- 作答前先圈出题干关键词；\n"
        f"- 写答案时先给结论，再写依据；\n"
        f"- 对照标准答案复盘自己遗漏了哪些课程术语。"
    )


def generate_wrong_question_analysis(question_text: str, student_answer: str, correct_answer: str, rag_context: str = '') -> str:
    prompt = (
        f'你是一位《{COURSE_NAME}》辅导老师。学生做错了一道题。'
        '请只输出给学生看的分析结果，并严格使用以下四个标题：'
        '“你为什么错：”“课件中的相关概念：”“正确思路：”“下次避免建议：”。'
        '每个标题下用 1~3 条简洁要点说明，语气鼓励但要具体。'
        f'\n\n【题目】{question_text}\n【学生答案】{student_answer or "未作答"}\n【标准答案】{correct_answer}\n【参考资料】\n{rag_context or "无"}'
    )
    try:
        answer, _elapsed, _meta = ollama_chat_once(
            prompt=prompt,
            image_b64=None,
            history=[],
            mode='wrong_analysis',
            subject=COURSE_NAME,
            options={'temperature': 0.2, 'top_p': 0.9, 'top_k': 30, 'num_predict': 500, 'num_ctx': 8192},
            use_rag=False,
        )
        if answer and answer.strip():
            cleaned = answer.strip()
            required_sections = ["你为什么错", "课件中的相关概念", "正确思路", "下次避免建议"]
            if all(section in cleaned for section in required_sections):
                return cleaned
    except Exception:
        pass
    return _wrong_question_fallback(question_text, student_answer, correct_answer, rag_context)



_INVALID_ANSWER_SET = {"", "无", "不会", "不知道", "没写", "略", "未作答", "none", "null", "n/a", "na", "不会做"}


def _normalize_loose(text: str | None) -> str:
    raw = (text or "").strip().lower()
    return re.sub(r"[\s\u3000，。,．；;：:！!？?、\-—_（）()\[\]{}]", "", raw)


def is_invalid_answer_text(text: str | None) -> bool:
    raw = (text or "").strip()
    norm = _normalize_loose(raw)
    if not norm:
        return True
    if norm in _INVALID_ANSWER_SET:
        return True
    if len(norm) <= 2:
        return True
    return False


def _match_ratio(a: str | None, b: str | None) -> float:
    aa = _normalize_loose(a)
    bb = _normalize_loose(b)
    if not aa or not bb:
        return 0.0
    if aa == bb:
        return 1.0
    if aa in bb or bb in aa:
        shorter = min(len(aa), len(bb))
        longer = max(len(aa), len(bb))
        return shorter / max(1, longer)
    return SequenceMatcher(None, aa, bb).ratio()


def _extract_reference_keywords(question_text: str, reference_answer: str | None) -> list[str]:
    terms = []
    for item in infer_points((question_text or "") + "\n" + (reference_answer or "")):
        token = item.strip()
        if token and len(_normalize_loose(token)) >= 2 and token not in terms:
            terms.append(token)
    return terms[:12]


def _format_grading_feedback(summary: str, correctness: str, logic: str, terminology: str, suggestions: list[str], optimized: str) -> str:
    compact_suggestions: list[str] = []
    for item in [summary, correctness, logic, terminology]:
        cleaned = (item or '').strip()
        if cleaned and cleaned not in compact_suggestions:
            compact_suggestions.append(cleaned)
    for item in suggestions or []:
        cleaned = (item or '').strip()
        if cleaned and cleaned not in compact_suggestions:
            compact_suggestions.append(cleaned)
    suggestion_lines = '\n'.join([f'- {s}' for s in compact_suggestions]) or '- 建议围绕题目要求补全关键点。'
    optimized_text = (optimized or '').strip() or '请结合标准答案补全关键点后重新作答。'
    return (
        f"分析建议：\n{suggestion_lines}\n\n"
        f"优化答案建议：\n{optimized_text}"
    )


def _assignment_fallback_feedback(title: str, question_text: str, student_answer: str, reference_answer: str | None = None, question_type: str | None = None) -> tuple[str, dict[str, Any]]:
    student = (student_answer or '').strip()
    reference = (reference_answer or '').strip()
    points = _extract_reference_keywords(question_text, reference)
    optimized = reference or (
        '建议采用“先给结论，再说明依据，最后总结差异/意义”的结构重新组织答案。\n'
        + f'可优先补充这些知识点：{"、".join(points[:4]) or "项目背景、分析依据、结论与意义"}'
    )

    if is_invalid_answer_text(student):
        feedback = _format_grading_feedback(
            '学生未作答或作答无效，本题不能判为正确。',
            '未检测到有效答案内容，因此无法形成有效的内容正确性评价。',
            '答案为空、过短或属于“无/不会/不知道”等无效回答，逻辑完整性为 0。',
            '未使用有效课程术语，术语规范性为 0。',
            ['请先围绕题目写出完整答案，再进行 AI 批改。'],
            optimized,
        )
        return feedback, {
            'ai_score': 0.0,
            'logic_score': 0.0,
            'terminology_score': 0.0,
            'completeness_score': 0.0,
            'overall_level': '待改进',
            'optimized_answer': optimized,
            'knowledge_points': points,
            'elapsed_seconds': 0.0,
            'rag_used': False,
            'is_reference_match': False,
            'reference_match_ratio': 0.0,
        }

    exact_ratio = _match_ratio(student, reference) if reference else 0.0
    if reference and exact_ratio >= 0.995:
        feedback = _format_grading_feedback(
            '学生答案与题库标准答案一致，可判定为正确。',
            '答案与标准答案在内容上完全一致，内容正确性为高。',
            '答案结构完整，已覆盖题目要求中的关键比较点。',
            '课程术语使用准确规范。',
            ['可以在保持标准答案准确性的基础上，适当补充一句总结性表述，使书写更完整。'],
            optimized,
        )
        return feedback, {
            'ai_score': 100.0,
            'logic_score': 100.0,
            'terminology_score': 100.0,
            'completeness_score': 100.0,
            'overall_level': '优秀',
            'optimized_answer': optimized,
            'knowledge_points': points,
            'elapsed_seconds': 0.0,
            'rag_used': False,
            'is_reference_match': True,
            'reference_match_ratio': 1.0,
        }

    logic_score = 45.0
    terminology_score = 40.0
    completeness_score = 35.0

    if len(student) >= 40:
        completeness_score += 12
    if len(student) >= 80:
        completeness_score += 12
    if len(student) >= 150:
        completeness_score += 8

    logic_words = ["首先", "其次", "再次", "最后", "因此", "所以", "因为", "通过", "根据", "分别", "区别", "相同", "不同"]
    hit_logic = sum(1 for w in logic_words if w in student)
    logic_score = min(100.0, logic_score + hit_logic * 5)

    course_terms = ["项目", "项目集", "项目组合", "范围", "进度", "成本", "风险", "质量", "WBS", "关键路径", "挣值", "敏捷", "Scrum", "战略目标", "收益", "可交付成果"]
    hit_terms = sum(1 for k in course_terms if k in student)
    terminology_score = min(100.0, terminology_score + hit_terms * 4)

    matched = 0
    for kp in points:
        if _normalize_loose(kp) and _normalize_loose(kp) in _normalize_loose(student):
            matched += 1
    if points:
        completeness_score = min(100.0, completeness_score + matched / len(points) * 45)

    if reference:
        ratio_bonus = exact_ratio * 40
        completeness_score = min(100.0, completeness_score + ratio_bonus)
        logic_score = min(100.0, logic_score + exact_ratio * 15)
        terminology_score = min(100.0, terminology_score + exact_ratio * 10)

    total = round((logic_score + terminology_score + completeness_score) / 3, 1)
    level = '优秀' if total >= 85 else '良好' if total >= 70 else '合格' if total >= 60 else '待改进'

    if reference and exact_ratio >= 0.90:
        summary = '学生答案与题库标准答案高度一致，可以判定为基本正确。'
        correctness = '答案已覆盖标准答案的主要内容，仅在表述细节上可以进一步打磨。'
    elif reference and exact_ratio >= 0.70:
        summary = '学生答案与标准答案有较高重合度，核心观点基本正确，但仍有细节可补充。'
        correctness = '答案覆盖了标准答案中的多数关键点，但部分比较维度或总结表述仍可增强。'
    else:
        summary = '学生答案部分覆盖了题目要求，但与标准答案相比仍有明显缺漏。'
        correctness = '建议围绕标准答案中的关键点补充作答，确保结论、依据和差异点都写出来。'

    logic_comment = '答案具备一定层次，但可进一步使用“分别/区别/因此”等连接词增强比较逻辑。'
    terminology_comment = '已使用部分课程术语，建议继续对齐题库标准答案中的术语表达。'
    suggestions = [
        '先明确结论，再分别说明每个概念/对象的关注重点。',
        '尽量沿用题库标准答案中的课程术语，减少口语化表达。',
    ]
    if points:
        suggestions.append('可重点补充这些要点：' + '、'.join(points[:6]))

    feedback = _format_grading_feedback(summary, correctness, logic_comment, terminology_comment, suggestions, optimized)
    return feedback, {
        'ai_score': total,
        'logic_score': round(logic_score, 1),
        'terminology_score': round(terminology_score, 1),
        'completeness_score': round(completeness_score, 1),
        'overall_level': level,
        'optimized_answer': optimized,
        'knowledge_points': points,
        'elapsed_seconds': 0.0,
        'rag_used': False,
        'is_reference_match': exact_ratio >= 0.995,
        'reference_match_ratio': round(exact_ratio, 4),
    }


def _simple_norm(text: str | None) -> str:
    return ''.join((text or '').strip().lower().split())


def generate_assignment_grading(title: str, question_text: str, student_answer: str, reference_answer: str | None = None, question_type: str | None = None) -> tuple[str, dict[str, Any]]:
    fallback_text, scores = _assignment_fallback_feedback(title, question_text, student_answer, reference_answer, question_type)

    # 先以题库标准答案和规则打底，避免模型在“答案完全一致”时误判。
    if scores.get('is_reference_match') or is_invalid_answer_text(student_answer):
        return fallback_text, scores

    prompt = (
        f'请作为《{COURSE_NAME}》课程教师，对下面这份学生作答进行辅助批改。'
        '你必须以“标准答案”为判定依据，不能编造学生没有写出的内容。'
        '如果学生答案与标准答案一致或高度一致，就应明确说明“答案与标准答案一致/高度一致”。'
        '你只负责生成评价文字，不负责重新决定分数。'
        '请严格输出 JSON，字段为 summary、correctness_comment、logic_comment、terminology_comment、suggestions、optimized_answer。'
        f'\n\n作业标题：{title}\n题型：{question_type or "主观题"}\n题目：{question_text}\n学生答案：{student_answer}\n标准答案：{reference_answer or "无"}'
    )
    try:
        answer, elapsed, meta = ollama_chat_once(
            prompt=prompt,
            image_b64=None,
            history=[],
            mode='ai_grading',
            subject=COURSE_NAME,
            options={'temperature': 0.1, 'top_p': 0.8, 'top_k': 30, 'num_predict': 700, 'num_ctx': 8192},
            use_rag=False,
        )
        if answer and answer.strip():
            parsed = None
            try:
                parsed = json.loads(answer.strip())
            except Exception:
                m = re.search(r'\{[\s\S]*\}', answer.strip())
                if m:
                    try:
                        parsed = json.loads(m.group(0))
                    except Exception:
                        parsed = None
            if isinstance(parsed, dict):
                suggestions = parsed.get('suggestions')
                if isinstance(suggestions, str):
                    suggestions = [suggestions]
                feedback = _format_grading_feedback(
                    parsed.get('summary') or '学生答案与标准答案存在一定差距，可根据标准答案继续优化。',
                    parsed.get('correctness_comment') or '请继续对照标准答案检查关键点是否覆盖完整。',
                    parsed.get('logic_comment') or '建议进一步优化答案结构。',
                    parsed.get('terminology_comment') or '建议继续使用规范课程术语。',
                    suggestions or ['可继续参照题库标准答案补全关键点。'],
                    parsed.get('optimized_answer') or scores.get('optimized_answer') or '',
                )
                return feedback, scores | {'elapsed_seconds': elapsed, 'rag_used': bool(meta.get('rag_used'))}
    except Exception:
        pass
    return fallback_text, scores
