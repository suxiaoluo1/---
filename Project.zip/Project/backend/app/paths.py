from __future__ import annotations

import os
from pathlib import Path

# backend/app -> backend -> Project -> PythonProject 根目录
PYTHON_PROJECT_ROOT = Path(__file__).resolve().parents[3]
FILES_ROOT = Path(os.environ.get("APP_FILES_ROOT", str(PYTHON_PROJECT_ROOT / "flies"))).resolve()
KNOWLEDGE_UPLOAD_DIR = FILES_ROOT / "knowledge_base" / "uploads"
KNOWLEDGE_PARSED_DIR = FILES_ROOT / "knowledge_base" / "parsed"
QUESTION_BANK_UPLOAD_DIR = FILES_ROOT / "question_bank" / "uploads"
QUESTION_BANK_PARSED_DIR = FILES_ROOT / "question_bank" / "parsed"
CHROMA_DB_DIR = FILES_ROOT / "chroma_db"
CHART_ANALYSIS_UPLOAD_DIR = FILES_ROOT / "chart_analysis" / "uploads"

for _dir in [FILES_ROOT, KNOWLEDGE_UPLOAD_DIR, KNOWLEDGE_PARSED_DIR, QUESTION_BANK_UPLOAD_DIR, QUESTION_BANK_PARSED_DIR, CHROMA_DB_DIR, CHART_ANALYSIS_UPLOAD_DIR]:
    _dir.mkdir(parents=True, exist_ok=True)
