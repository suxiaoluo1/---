from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text, Float
from sqlalchemy.sql import func
from .database import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False, index=True)  # student teacher admin
    full_name = Column(String(100), nullable=True)
    grade = Column(String(50), nullable=True)
    class_name = Column(String(50), nullable=True)
    subject = Column(String(50), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class LearningPath(Base):
    __tablename__ = "learning_paths"
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    title = Column(String(200), nullable=False)
    goal = Column(Text, nullable=False)
    steps_json = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class KnowledgePoint(Base):
    __tablename__ = "knowledge_points"
    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False)
    subject = Column(String(50), nullable=False)
    description = Column(Text, nullable=True)
    difficulty = Column(String(20), default="medium")
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class MasteryRecord(Base):
    __tablename__ = "mastery_records"
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    knowledge_point_id = Column(Integer, ForeignKey("knowledge_points.id"), nullable=False)
    mastery_score = Column(Float, default=0.0)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

class WrongQuestion(Base):
    __tablename__ = "wrong_questions"
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    subject = Column(String(50), nullable=False)
    question_text = Column(Text, nullable=False)
    answer_text = Column(Text, nullable=True)
    analysis = Column(Text, nullable=True)
    ai_analysis = Column(Text, nullable=True)
    knowledge_points_json = Column(Text, nullable=True)
    recommended_chapter = Column(String(100), nullable=True)
    reference_question_id = Column(Integer, ForeignKey("practice_questions.id"), nullable=True)
    image_path = Column(String(255), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class QuizRecord(Base):
    __tablename__ = "quiz_records"
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    subject = Column(String(50), nullable=False)
    score = Column(Float, nullable=False)
    total_score = Column(Float, nullable=False)
    summary = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class LearningRecord(Base):
    __tablename__ = "learning_records"
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    record_type = Column(String(50), nullable=False)
    content = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class TaskAssignment(Base):
    __tablename__ = "task_assignments"
    id = Column(Integer, primary_key=True)
    teacher_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    student_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    title = Column(String(200), nullable=False)
    description = Column(Text, nullable=True)
    status = Column(String(20), default="pending")
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class KnowledgeDocument(Base):
    __tablename__ = "knowledge_documents"
    id = Column(Integer, primary_key=True)
    title = Column(String(255), nullable=False)
    subject = Column(String(50), nullable=False, default="通用")
    source_label = Column(String(255), nullable=False)
    file_name = Column(String(255), nullable=False)
    file_type = Column(String(50), nullable=False)
    chunk_count = Column(Integer, nullable=False, default=0)
    uploaded_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class KnowledgeGraph(Base):
    __tablename__ = "knowledge_graphs"
    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    subject = Column(String(50), nullable=False, default="通用")
    source_type = Column(String(50), nullable=False, default="knowledge_documents")
    source_document_ids_json = Column(Text, nullable=True)
    source_titles_json = Column(Text, nullable=True)
    build_status = Column(String(20), nullable=False, default="done")
    node_count = Column(Integer, nullable=False, default=0)
    edge_count = Column(Integer, nullable=False, default=0)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class KnowledgeGraphNode(Base):
    __tablename__ = "knowledge_graph_nodes"
    id = Column(Integer, primary_key=True)
    graph_id = Column(Integer, ForeignKey("knowledge_graphs.id"), nullable=False, index=True)
    name = Column(String(200), nullable=False, index=True)
    category = Column(String(50), nullable=False, default="通用")
    description = Column(Text, nullable=True)
    source_count = Column(Integer, nullable=False, default=1)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class KnowledgeGraphEdge(Base):
    __tablename__ = "knowledge_graph_edges"
    id = Column(Integer, primary_key=True)
    graph_id = Column(Integer, ForeignKey("knowledge_graphs.id"), nullable=False, index=True)
    source_node_id = Column(Integer, ForeignKey("knowledge_graph_nodes.id"), nullable=False)
    target_node_id = Column(Integer, ForeignKey("knowledge_graph_nodes.id"), nullable=False)
    relation = Column(String(50), nullable=False, default="相关于")
    weight = Column(Float, nullable=False, default=1.0)
    evidence = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class PracticeQuestion(Base):
    __tablename__ = "practice_questions"
    id = Column(Integer, primary_key=True)
    subject = Column(String(50), nullable=False, default="软件项目管理", index=True)
    chapter = Column(String(100), nullable=False, index=True)
    difficulty = Column(String(20), nullable=False, default="适中", index=True)
    question_type = Column(String(50), nullable=False, default="单选题", index=True)
    question_text = Column(Text, nullable=False)
    options_json = Column(Text, nullable=True)
    correct_answer = Column(Text, nullable=False)
    analysis = Column(Text, nullable=True)
    knowledge_points_json = Column(Text, nullable=True)
    source_label = Column(String(255), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class PracticeRecord(Base):
    __tablename__ = "practice_records"
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    question_id = Column(Integer, ForeignKey("practice_questions.id"), nullable=False, index=True)
    subject = Column(String(50), nullable=False, default="软件项目管理")
    chapter = Column(String(100), nullable=True)
    difficulty = Column(String(20), nullable=True)
    question_type = Column(String(50), nullable=True)
    knowledge_points_json = Column(Text, nullable=True)
    student_answer = Column(Text, nullable=True)
    correct_answer = Column(Text, nullable=True)
    is_correct = Column(Integer, nullable=False, default=0)
    score = Column(Float, nullable=False, default=0.0)
    total_score = Column(Float, nullable=False, default=1.0)
    analysis = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())




class AssignmentSubmission(Base):
    __tablename__ = "assignment_submissions"
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    title = Column(String(255), nullable=False)
    question_text = Column(Text, nullable=False)
    content = Column(Text, nullable=False)
    reference_answer = Column(Text, nullable=True)
    ai_score = Column(Float, nullable=True, default=0.0)
    logic_score = Column(Float, nullable=True, default=0.0)
    terminology_score = Column(Float, nullable=True, default=0.0)
    completeness_score = Column(Float, nullable=True, default=0.0)
    overall_level = Column(String(20), nullable=True, default="待评估")
    optimized_answer = Column(Text, nullable=True)
    ai_feedback = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class ReportSubmission(Base):
    __tablename__ = "report_submissions"
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    title = Column(String(255), nullable=False)
    content = Column(Text, nullable=False)
    ai_feedback = Column(Text, nullable=True)
    ai_score = Column(Float, nullable=True, default=0.0)
    highlights_json = Column(Text, nullable=True)
    improvements_json = Column(Text, nullable=True)
    structure_score = Column(Float, nullable=True, default=0.0)
    terminology_score = Column(Float, nullable=True, default=0.0)
    completeness_score = Column(Float, nullable=True, default=0.0)
    overall_level = Column(String(20), nullable=True, default="待评估")
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class ChartAnalysisRecord(Base):
    __tablename__ = "chart_analysis_records"
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    title = Column(String(255), nullable=False)
    chart_type = Column(String(50), nullable=False, default="图表题")
    prompt = Column(Text, nullable=True)
    image_path = Column(String(255), nullable=True)
    ai_feedback = Column(Text, nullable=True)
    knowledge_points_json = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())



class ChatHistory(Base):
    __tablename__ = "chat_histories"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    mode = Column(String(50), nullable=False, default="step_by_step")
    question = Column(Text, nullable=False)
    answer = Column(Text, nullable=False)
    source_summary = Column(Text, nullable=True)
    knowledge_points_json = Column(Text, nullable=True)
    rag_used = Column(Integer, nullable=False, default=0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
