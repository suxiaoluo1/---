import hashlib
import os
import re
import uuid
from pathlib import Path
from typing import Any

import chromadb
import docx
import fitz
from pptx import Presentation
from sentence_transformers import SentenceTransformer

try:
    from langchain_text_splitters import RecursiveCharacterTextSplitter
except Exception:
    RecursiveCharacterTextSplitter = None


from .paths import CHROMA_DB_DIR, KNOWLEDGE_PARSED_DIR, KNOWLEDGE_UPLOAD_DIR, PYTHON_PROJECT_ROOT

DEFAULT_LOCAL_MODEL_DIR = Path(os.environ.get("LOCAL_EMBEDDING_MODEL_DIR", str(PYTHON_PROJECT_ROOT / "models" / "text2vec-base-chinese"))).resolve()

chroma_client = chromadb.PersistentClient(path=str(CHROMA_DB_DIR))
collection = chroma_client.get_or_create_collection(
    name="learning_knowledge_base",
    metadata={"hnsw:space": "cosine"},
)

_embedding_model = None
_embedding_model_failed = False


def _is_valid_local_model_dir(model_dir: Path) -> tuple[bool, str]:
    if not model_dir.exists():
        return False, "目录不存在"
    if not model_dir.is_dir():
        return False, "不是目录"
    required_any = [model_dir / "config.json", model_dir / "modules.json"]
    if not any(p.exists() for p in required_any):
        return False, "缺少 config.json 或 modules.json"
    weight_files = [model_dir / "model.safetensors", model_dir / "pytorch_model.bin"]
    existing = [p for p in weight_files if p.exists()]
    if not existing:
        return False, "缺少 model.safetensors 或 pytorch_model.bin"
    for wf in existing:
        try:
            if wf.stat().st_size < 1024:
                return False, f"权重文件异常过小：{wf.name}"
            with wf.open("rb") as f:
                header = f.read(64)
            if header.startswith(b"version https://git-lfs.github.com/spec"):
                return False, f"{wf.name} 看起来是 Git LFS 指针文件，未下载真实权重"
        except Exception as e:
            return False, f"无法读取权重文件 {wf.name}: {e}"
    return True, "ok"


def get_embedding_model() -> SentenceTransformer | None:
    """优先加载本地模型；本地模型目录无效时自动跳过，再回退到远程模型。"""
    global _embedding_model, _embedding_model_failed

    if _embedding_model is not None:
        return _embedding_model

    if _embedding_model_failed:
        return None

    remote_model_name = os.environ.get("EMBEDDING_MODEL", "shibing624/text2vec-base-chinese")

    print(f"[RAG] DEFAULT_LOCAL_MODEL_DIR = {DEFAULT_LOCAL_MODEL_DIR}")

    # 先尝试本地固定路径
    valid_local, reason = _is_valid_local_model_dir(DEFAULT_LOCAL_MODEL_DIR)
    if valid_local:
        try:
            print(f"[RAG] 正在加载本地嵌入模型: {DEFAULT_LOCAL_MODEL_DIR}")
            _embedding_model = SentenceTransformer(str(DEFAULT_LOCAL_MODEL_DIR), device=os.environ.get("EMBEDDING_DEVICE") or None)
            print("[RAG] 本地嵌入模型加载成功")
            return _embedding_model
        except Exception as e:
            print(f"[RAG] 本地嵌入模型加载失败: {type(e).__name__}: {e}")
    else:
        print(f"[RAG] 跳过本地嵌入模型目录 {DEFAULT_LOCAL_MODEL_DIR}，原因：{reason}")

    # 再尝试远程
    try:
        print(f"[RAG] 未找到可用本地模型，尝试加载远程模型: {remote_model_name}")
        _embedding_model = SentenceTransformer(remote_model_name)
        print("[RAG] 远程嵌入模型加载成功")
        return _embedding_model
    except Exception as e:
        print(f"[RAG] 远程嵌入模型加载失败: {type(e).__name__}: {e}")
        _embedding_model_failed = True
        return None


def get_embedding(text: str) -> list[float] | None:
    model = get_embedding_model()
    if model is None:
        return None
    try:
        return model.encode(text, normalize_embeddings=True).tolist()
    except Exception as e:
        print(f"[RAG] 文本向量化失败: {type(e).__name__}: {e}")
        return None


def safe_filename(filename: str) -> str:
    name = Path(filename or "file").name
    return re.sub(r"[^\w\-.一-龥]+", "_", name)


def save_upload_file(upload_file) -> tuple[str, str]:
    suffix = Path(upload_file.filename or "").suffix.lower()
    original_name = safe_filename(upload_file.filename or "file")
    stored_name = f"{uuid.uuid4().hex}_{original_name}"
    target = KNOWLEDGE_UPLOAD_DIR / stored_name
    with target.open("wb") as f:
        f.write(upload_file.file.read())
    return str(target), stored_name


def save_parsed_text(stored_name: str, title: str, text: str) -> str:
    parsed_name = f"{Path(stored_name).stem}.txt"
    parsed_path = KNOWLEDGE_PARSED_DIR / parsed_name
    parsed_path.write_text(f"# {title}\n\n{text}", encoding="utf-8")
    return str(parsed_path)



def delete_knowledge_file_artifacts(stored_name: str) -> None:
    for path in [KNOWLEDGE_UPLOAD_DIR / stored_name, KNOWLEDGE_PARSED_DIR / f"{Path(stored_name).stem}.txt"]:
        if path.exists():
            try:
                path.unlink()
            except Exception:
                pass


def extract_text_from_file(file_path: str, filename: str) -> str:
    suffix = Path(filename).suffix.lower()

    if suffix in {".txt", ".md"}:
        return Path(file_path).read_text(encoding="utf-8", errors="ignore")

    if suffix == ".pdf":
        doc = fitz.open(file_path)
        parts = [page.get_text("text") for page in doc]
        doc.close()
        return "\n".join(parts)

    if suffix == ".docx":
        document = docx.Document(file_path)
        return "\n".join(p.text for p in document.paragraphs if p.text and p.text.strip())

    if suffix == ".pptx":
        prs = Presentation(file_path)
        parts = []
        for slide in prs.slides:
            for shape in slide.shapes:
                if hasattr(shape, "text") and shape.text:
                    parts.append(shape.text)
        return "\n".join(parts)

    raise ValueError(f"暂不支持的文件类型: {suffix}")


def normalize_text(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"\r\n?", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def split_text(text: str, chunk_size: int = 700, chunk_overlap: int = 120) -> list[str]:
    text = normalize_text(text)
    if not text:
        return []

    if RecursiveCharacterTextSplitter is not None:
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            separators=["\n\n", "\n", "。", "！", "？", ";", "；", ",", "，", " ", ""],
        )
        return [c.strip() for c in splitter.split_text(text) if c and c.strip()]

    chunks = []
    start = 0
    while start < len(text):
        end = min(len(text), start + chunk_size)
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end >= len(text):
            break
        start = max(start + chunk_size - chunk_overlap, end)

    return chunks


def extract_knowledge_points(chunks: list[str], limit: int = 5) -> list[str]:
    points = []
    seen = set()

    for chunk in chunks:
        candidates = re.split(r"[\n；;。!?！？]", chunk)
        for item in candidates:
            item = re.sub(r"\s+", " ", item).strip(" -•·\t")
            if 8 <= len(item) <= 60 and item not in seen:
                seen.add(item)
                points.append(item)
                if len(points) >= limit:
                    return points

    return points


def add_document_chunks(
    *,
    document_db_id: int,
    title: str,
    subject: str,
    source_label: str,
    file_name: str,
    text: str,
) -> int:
    chunks = split_text(text)
    if not chunks:
        raise ValueError("文件内容为空，无法写入知识库")

    valid_chunks: list[str] = []
    embeddings: list[list[float]] = []

    for chunk in chunks:
        emb = get_embedding(chunk)
        if emb is not None:
            valid_chunks.append(chunk)
            embeddings.append(emb)

    if not valid_chunks:
        raise RuntimeError("嵌入模型不可用，无法写入知识库。请先检查本地嵌入模型是否已正确加载。")

    ids = []
    metadatas = []

    for idx, chunk in enumerate(valid_chunks):
        chunk_hash = hashlib.md5(f"{document_db_id}:{idx}:{chunk[:80]}".encode("utf-8")).hexdigest()
        ids.append(f"doc_{document_db_id}_{idx}_{chunk_hash[:8]}")
        metadatas.append(
            {
                "document_db_id": document_db_id,
                "title": title,
                "subject": subject or "通用",
                "source": source_label,
                "file_name": file_name,
                "chunk_index": idx,
            }
        )

    collection.upsert(
        ids=ids,
        embeddings=embeddings,
        metadatas=metadatas,
        documents=valid_chunks,
    )

    print(f"[RAG] 文档入库成功: title={title}, chunks={len(valid_chunks)}, subject={subject or '通用'}")
    return len(valid_chunks)


def remove_document_chunks(document_db_id: int):
    try:
        collection.delete(where={"document_db_id": document_db_id})
        print(f"[RAG] 已删除文档切片: document_db_id={document_db_id}")
    except Exception as e:
        print(f"[RAG] 删除文档切片失败: document_db_id={document_db_id}, error={e}")


def search_knowledge(query: str, subject_hint: str | None = None, top_k: int = 4) -> list[dict[str, Any]]:
    query = (query or "").strip()
    if not query:
        return []

    query_embedding = get_embedding(query)
    if query_embedding is None:
        print("[RAG] 检索跳过：嵌入模型不可用")
        return []

    where = None
    if subject_hint and subject_hint not in {"通用", "general"}:
        where = {"subject": subject_hint}

    try:
        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k,
            where=where,
            include=["documents", "metadatas", "distances"],
        )
    except Exception as e:
        print(f"[RAG] 带科目过滤检索失败，改用全库检索: {type(e).__name__}: {e}")
        try:
            results = collection.query(
                query_embeddings=[query_embedding],
                n_results=top_k,
                include=["documents", "metadatas", "distances"],
            )
        except Exception as e2:
            print(f"[RAG] 全库检索失败: {type(e2).__name__}: {e2}")
            return []

    if not results or not results.get("documents") or not results["documents"][0]:
        print("[RAG] 检索完成：未找到候选片段")
        return []

    docs = []
    distances = results.get("distances", [[]])[0]

    for idx, content in enumerate(results["documents"][0]):
        meta = results["metadatas"][0][idx]
        distance = distances[idx] if idx < len(distances) else None

        print(
            f"[RAG] 候选片段 distance={distance}, "
            f"title={meta.get('title')}, "
            f"subject={meta.get('subject')}, "
            f"chunk_index={meta.get('chunk_index')}"
        )

        docs.append(
            {
                "content": content,
                "title": meta.get("title", "未命名资料"),
                "source": meta.get("source", "教师知识库"),
                "subject": meta.get("subject", "通用"),
                "file_name": meta.get("file_name"),
                "chunk_index": meta.get("chunk_index"),
                "score": None if distance is None else round(max(0.0, 1.0 - float(distance)), 4),
            }
        )

    print(
        f"[RAG] 检索完成: query={query[:40]}, subject_hint={subject_hint}, top_k={top_k}, 候选数={len(docs)}"
    )
    return docs


def build_rag_context(docs: list[dict[str, Any]]) -> str:
    if not docs:
        return ""

    parts = []
    for idx, doc in enumerate(docs, 1):
        parts.append(
            f"[资料{idx}] 标题：{doc['title']}\n"
            f"来源：{doc['source']}\n"
            f"科目：{doc['subject']}\n"
            f"文件：{doc.get('file_name') or '未知'}\n"
            f"内容：{doc['content']}"
        )
    return "\n\n".join(parts)
