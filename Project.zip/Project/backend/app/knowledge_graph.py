from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from sqlalchemy.orm import Session

from .course_data import COURSE_MODULES, POINT_TO_MODULE, STATIC_RELATIONS, infer_points
from .models import (
    KnowledgeDocument,
    KnowledgeGraph,
    KnowledgeGraphEdge,
    KnowledgeGraphNode,
    KnowledgePoint,
    LearningRecord,
    MasteryRecord,
    PracticeRecord,
    WrongQuestion,
)
from .rag import extract_text_from_file


@dataclass
class GraphBuildResult:
    graph_id: int
    node_count: int
    edge_count: int
    source_document_ids: list[int]
    source_titles: list[str]


def build_graph_from_documents(
    db: Session,
    *,
    graph_name: str,
    subject: str,
    document_ids: list[int] | None = None,
    created_by: int | None = None,
) -> GraphBuildResult:
    query = db.query(KnowledgeDocument)
    if document_ids:
        query = query.filter(KnowledgeDocument.id.in_(document_ids))
    docs = query.order_by(KnowledgeDocument.id.desc()).all()

    graph = KnowledgeGraph(
        name=graph_name,
        subject=subject,
        source_type="knowledge_documents",
        source_document_ids_json=json.dumps([d.id for d in docs], ensure_ascii=False),
        source_titles_json=json.dumps([d.title for d in docs], ensure_ascii=False),
        build_status="processing",
        created_by=created_by,
    )
    db.add(graph)
    db.commit()
    db.refresh(graph)

    node_map: dict[str, KnowledgeGraphNode] = {}
    for module in COURSE_MODULES:
        for point in module["points"]:
            node = KnowledgeGraphNode(
                graph_id=graph.id,
                name=point,
                category=module["name"],
                description=f"{module['name']}核心知识点",
                source_count=1,
            )
            db.add(node)
            db.flush()
            node_map[point] = node

    doc_hits = {k: 0 for k in node_map}
    for doc in docs:
        try:
            from pathlib import Path

            file_path = Path(__file__).resolve().parent.parent / "storage" / "knowledge_files" / doc.file_name
            text = extract_text_from_file(str(file_path), doc.file_name)
        except Exception:
            text = ""
        for p in infer_points(text):
            if p in doc_hits:
                doc_hits[p] += 1

    for p, count in doc_hits.items():
        if count:
            node_map[p].source_count = 1 + count
            node_map[p].description = f"{POINT_TO_MODULE.get(p, subject)}；知识库命中 {count} 次"

    edge_count = 0
    for a, rel, b in STATIC_RELATIONS:
        if a in node_map and b in node_map:
            db.add(
                KnowledgeGraphEdge(
                    graph_id=graph.id,
                    source_node_id=node_map[a].id,
                    target_node_id=node_map[b].id,
                    relation=rel,
                    weight=1.0,
                    evidence="课程知识结构预定义关系",
                )
            )
            edge_count += 1

    graph.node_count = len(node_map)
    graph.edge_count = edge_count
    graph.build_status = "done"
    db.commit()

    return GraphBuildResult(
        graph_id=graph.id,
        node_count=len(node_map),
        edge_count=edge_count,
        source_document_ids=[d.id for d in docs],
        source_titles=[d.title for d in docs],
    )


def get_graph_payload_for_student(db: Session, graph: KnowledgeGraph, student_id: int) -> dict[str, Any]:
    nodes = db.query(KnowledgeGraphNode).filter(KnowledgeGraphNode.graph_id == graph.id).all()
    edges = db.query(KnowledgeGraphEdge).filter(KnowledgeGraphEdge.graph_id == graph.id).all()
    mastery_rows = (
        db.query(MasteryRecord, KnowledgePoint)
        .join(KnowledgePoint, KnowledgePoint.id == MasteryRecord.knowledge_point_id)
        .filter(MasteryRecord.student_id == student_id)
        .all()
    )
    mastery_map = {kp.name: float(mr.mastery_score) for mr, kp in mastery_rows}
    wrongs = db.query(WrongQuestion).filter(WrongQuestion.student_id == student_id).order_by(WrongQuestion.id.desc()).limit(100).all()
    records = db.query(LearningRecord).filter(LearningRecord.student_id == student_id).order_by(LearningRecord.id.desc()).limit(50).all()
    practices = db.query(PracticeRecord).filter(PracticeRecord.student_id == student_id).order_by(PracticeRecord.id.desc()).limit(100).all()

    wrong_counter: dict[str, int] = {}
    for w in wrongs:
        for p in infer_points("\n".join([w.question_text or "", w.analysis or ""])):
            wrong_counter[p] = wrong_counter.get(p, 0) + 1

    record_counter: dict[str, int] = {}
    for r in records:
        for p in infer_points(r.content or ""):
            record_counter[p] = record_counter.get(p, 0) + 1

    practice_stats: dict[str, dict[str, int]] = {}
    for row in practices:
        points = []
        if row.knowledge_points_json:
            try:
                points = json.loads(row.knowledge_points_json) or []
            except Exception:
                points = []
        if not points:
            points = infer_points("\n".join([row.analysis or "", row.chapter or ""]))
        for point in points:
            stat = practice_stats.setdefault(point, {"total": 0, "correct": 0})
            stat["total"] += 1
            stat["correct"] += 1 if bool(row.is_correct) else 0

    payload_nodes = []
    weak_nodes = []
    node_detail_map = {}
    for n in nodes:
        mastery = mastery_map.get(n.name)
        wrong_hits = int(wrong_counter.get(n.name, 0))
        recent_hits = int(record_counter.get(n.name, 0))
        practice_total = int(practice_stats.get(n.name, {}).get("total", 0))
        practice_correct = int(practice_stats.get(n.name, {}).get("correct", 0))
        recent_accuracy = round(practice_correct / practice_total * 100, 1) if practice_total else None
        if mastery is not None:
            status = "mastered" if mastery >= 0.8 else "weak" if mastery < 0.6 else "learning"
        elif wrong_hits >= 2:
            status = "weak"
            mastery = max(0.2, 0.6 - wrong_hits * 0.1)
        elif wrong_hits == 1 or recent_hits > 0:
            status = "learning"
            mastery = 0.65
        else:
            status = "unknown"
            mastery = None

        mastery_percent = None if mastery is None else round(float(mastery) * 100, 1)
        color = "#22c55e" if status == "mastered" else "#f59e0b" if status == "learning" else "#ef4444" if status == "weak" else "#94a3b8"
        base_size = 28 + min(int(n.source_count or 1) * 3, 18)
        if status == "weak":
            base_size += 10

        diagnosis_reasons = []
        if mastery_percent is not None:
            diagnosis_reasons.append(f"当前掌握度 {mastery_percent}%")
        if wrong_hits:
            diagnosis_reasons.append(f"最近相关错题 {wrong_hits} 次")
        if recent_accuracy is not None:
            diagnosis_reasons.append(f"最近专项练习正确率 {recent_accuracy}%")
        diagnosis_reason = "；".join(diagnosis_reasons) or "当前缺少足够学习数据，可先完成专项练习。"

        if wrong_hits >= 2 or (recent_accuracy is not None and recent_accuracy < 60):
            recommended_action = f"优先复习“{n.name}”，随后完成 2~3 道同类专项练习。"
        elif mastery_percent is not None and mastery_percent < 60:
            recommended_action = f"建议先回看该知识点对应课件，再到智能问答中追问“{n.name}”的易错原因。"
        else:
            recommended_action = f"继续保持，并尝试把“{n.name}”用于案例分析或图表题。"

        item = {
            "id": n.id,
            "name": n.name,
            "category": n.category,
            "description": n.description,
            "source_count": int(n.source_count or 0),
            "status": status,
            "mastery_score": mastery,
            "mastery_percent": mastery_percent,
            "wrong_hits": wrong_hits,
            "recent_hits": recent_hits,
            "recent_accuracy": recent_accuracy,
            "symbol_size": base_size,
            "color": color,
            "diagnosis_reason": diagnosis_reason,
            "recommended_action": recommended_action,
        }
        payload_nodes.append(item)
        node_detail_map[n.name] = {
            "name": n.name,
            "category": n.category,
            "module": n.category,
            "mastery_percent": mastery_percent,
            "wrong_hits": wrong_hits,
            "recent_wrong_count": wrong_hits,
            "recent_accuracy": recent_accuracy,
            "recommended_action": recommended_action,
            "diagnosis_reason": diagnosis_reason,
            "status": status,
        }
        if status == "weak":
            weak_nodes.append(item)

    payload_edges = [
        {
            "id": e.id,
            "source": e.source_node_id,
            "target": e.target_node_id,
            "relation": e.relation,
            "weight": float(e.weight or 1.0),
            "evidence": e.evidence,
        }
        for e in edges
    ]
    weak_nodes = sorted(weak_nodes, key=lambda x: (x["wrong_hits"], -(x["mastery_score"] or 0)), reverse=True)
    recommendations = [f"优先复习“{w['name']}”，{w['diagnosis_reason']}。" for w in weak_nodes[:5]]
    if not recommendations:
        recommendations = ["当前没有明显薄弱节点，可继续通过案例题和图表题提升熟练度。"]
    return {
        "graph_id": graph.id,
        "name": graph.name,
        "subject": graph.subject,
        "node_count": len(payload_nodes),
        "edge_count": len(payload_edges),
        "nodes": payload_nodes,
        "edges": payload_edges,
        "recommendations": recommendations,
        "node_details": list(node_detail_map.values()),
        "source_titles": json.loads(graph.source_titles_json or "[]"),
    }
