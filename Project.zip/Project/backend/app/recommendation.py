from __future__ import annotations

import json
from collections import Counter, defaultdict
from typing import Any

from sqlalchemy.orm import Session

from .analytics import summarize_student_learning
from .course_data import COURSE_NAME, DEFAULT_PATH, POINT_TO_MODULE, POINT_TO_PATH, infer_points
from .models import (
    KnowledgePoint,
    LearningPath,
    LearningRecord,
    MasteryRecord,
    PracticeRecord,
    QuizRecord,
    TaskAssignment,
    WrongQuestion,
)


def _extract_points_from_records(records: list[LearningRecord]) -> list[str]:
    found = []
    for r in records:
        for p in infer_points(r.content or ""):
            if p not in found:
                found.append(p)
    return found[:8]


def _safe_json_loads(value: str | None) -> list[str]:
    if not value:
        return []
    try:
        data = json.loads(value)
        if isinstance(data, list):
            return [str(x) for x in data if str(x).strip()]
    except Exception:
        pass
    return []


def ensure_path_for_focus(db: Session, student_id: int, focus_point: str) -> None:
    cfg = POINT_TO_PATH.get(focus_point, DEFAULT_PATH)
    exists = db.query(LearningPath).filter(
        LearningPath.student_id == student_id,
        LearningPath.title == cfg["title"],
    ).first()
    if exists:
        return
    db.add(
        LearningPath(
            student_id=student_id,
            title=cfg["title"],
            goal=cfg["goal"],
            steps_json=json.dumps(cfg["steps"], ensure_ascii=False),
        )
    )
    db.commit()


def _build_dynamic_paths(
    wrongs: list[WrongQuestion],
    practices: list[PracticeRecord],
    weak_mastery: list[dict[str, Any]],
    legacy_paths: list[LearningPath],
    recent_summary: dict[str, Any],
) -> list[dict[str, Any]]:
    point_stats: dict[str, dict[str, Any]] = defaultdict(lambda: {
        "wrong_count": 0,
        "practice_count": 0,
        "correct_count": 0,
        "chapters": Counter(),
        "question_types": Counter(),
    })
    chapter_stats: dict[str, dict[str, int]] = defaultdict(lambda: {"total": 0, "wrong": 0})

    for w in wrongs[:30]:
        points = infer_points((w.question_text or "") + "\n" + (w.analysis or ""))
        for point in points:
            point_stats[point]["wrong_count"] += 1

    for p in practices[:50]:
        points = _safe_json_loads(p.knowledge_points_json)
        if not points:
            points = infer_points((p.analysis or "") + "\n" + (p.chapter or ""))
        for point in points:
            point_stats[point]["practice_count"] += 1
            point_stats[point]["correct_count"] += 1 if bool(p.is_correct) else 0
            if p.chapter:
                point_stats[point]["chapters"][p.chapter] += 1
            if p.question_type:
                point_stats[point]["question_types"][p.question_type] += 1
            if not bool(p.is_correct):
                point_stats[point]["wrong_count"] += 1
        if p.chapter:
            chapter_stats[p.chapter]["total"] += 1
            if not bool(p.is_correct):
                chapter_stats[p.chapter]["wrong"] += 1

    mastery_map = {item["knowledge_point"]: float(item["mastery_score"]) / 100 if item.get("mastery_score", 0) > 1 else float(item["mastery_score"]) for item in weak_mastery}
    recent_point_map = {item["knowledge_point"]: item for item in recent_summary.get("top_wrong_knowledge_points", [])}
    recent_chapter_map = {item["chapter"]: item for item in recent_summary.get("low_accuracy_chapters", [])}

    scored_points = []
    for point, stat in point_stats.items():
        score = stat["wrong_count"] * 2.0 + (stat["practice_count"] - stat["correct_count"]) * 0.8
        if point in mastery_map:
            score += max(0.0, 1.0 - mastery_map[point]) * 2.5
        recent_bonus = recent_point_map.get(point, {}).get("wrong_count", 0)
        score += recent_bonus * 1.2
        scored_points.append((point, score, stat))

    scored_points.sort(key=lambda x: (-x[1], -x[2]["wrong_count"], x[0]))

    dynamic_paths: list[dict[str, Any]] = []
    used_titles = set()

    for idx, (point, _score, stat) in enumerate(scored_points[:3], start=1):
        module = POINT_TO_MODULE.get(point, "软件项目管理")
        chapter = stat["chapters"].most_common(1)[0][0] if stat["chapters"] else module
        qtype = stat["question_types"].most_common(1)[0][0] if stat["question_types"] else "同类题"
        wrong_count = int(stat["wrong_count"])
        practice_count = int(stat["practice_count"])
        mastery_score = mastery_map.get(point)
        recent_point = recent_point_map.get(point, {})
        title = f"{module}｜{point}个性化提升路径"
        if title in used_titles:
            continue
        used_titles.add(title)
        goal = f"围绕“{point}”补齐概念理解、题型判断和应用表达，优先修复最近练习中暴露出的薄弱点。"
        reason_parts = [f"最近 7 天“{point}”相关题目出错 {recent_point.get('wrong_count', wrong_count)} 次"]
        if recent_point.get("recent_practice_accuracy") is not None:
            reason_parts.append(f"相关练习正确率约 {recent_point.get('recent_practice_accuracy')}%")
        elif practice_count:
            reason_parts.append(f"近期练习涉及 {practice_count} 次")
        if mastery_score is not None:
            reason_parts.append(f"当前掌握度约 {round(mastery_score * 100)}%")
        reason_text = "，".join(reason_parts) + "，因此优先推荐复习该知识点。"
        steps = [
            f"先回看 {chapter} 中与“{point}”相关的教材/PPT内容，整理 3 个核心要点。",
            f"复盘最近做错的 {qtype}，重点找出自己为什么会在“{point}”上失分。",
            f"重新完成 2~3 道与“{point}”相关的专项练习，并记录标准答案中的关键词。",
            f"用自己的话写一段关于“{point}”的简答或结论，再与题库标准答案对照修订。",
        ]
        dynamic_paths.append({
            "id": f"dynamic-point-{idx}",
            "title": title,
            "goal": goal,
            "steps": steps,
            "reason": reason_text,
            "type": "dynamic",
            "priority": idx,
            "focus_point": point,
            "module": module,
            "recommended_chapter": chapter,
            "recommended_question_type": qtype,
            "action_targets": {
                "practice": {"chapter": chapter, "difficulty": "适中", "count": 5, "reason": reason_text},
                "graph": {"node_name": point},
                "chat": {"prompt": f"请结合课程知识库，系统讲解“{point}”，并说明我最近为什么容易在这个知识点失分。"},
            },
        })

    weak_chapters = []
    for chapter, stat in chapter_stats.items():
        if stat["total"] <= 0:
            continue
        accuracy = (stat["total"] - stat["wrong"]) / stat["total"]
        weak_chapters.append((chapter, accuracy, stat))
    weak_chapters.sort(key=lambda x: (x[1], -x[2]["total"], x[0]))
    if weak_chapters:
        chapter, accuracy, stat = weak_chapters[0]
        title = f"{chapter}｜章节巩固路径"
        chapter_recent = recent_chapter_map.get(chapter, {})
        if title not in used_titles:
            used_titles.add(title)
            reason_text = (
                f"最近 7 天在 {chapter} 的练习正确率约为 {chapter_recent.get('accuracy', round(accuracy * 100, 1))}%"
                f"，累计失分 {chapter_recent.get('wrong_count', stat['wrong'])} 次，因此建议优先做章节巩固。"
            )
            dynamic_paths.append({
                "id": "dynamic-chapter-1",
                "title": title,
                "goal": f"围绕 {chapter} 做章节级查漏补缺，提升近期专项练习正确率。",
                "steps": [
                    f"整理 {chapter} 的高频考点，先区分概念题、计算题和简答题。",
                    f"复盘本章最近做错的题，标出最容易混淆的 2~3 个知识点。",
                    f"再做一轮 {chapter} 的 5 题专项练习，优先选择“适中/困难”难度。",
                    f"把本章易错点写成一份复盘清单，下次练习前先看一遍。",
                ],
                "reason": reason_text,
                "type": "dynamic",
                "priority": len(dynamic_paths) + 1,
                "focus_point": chapter,
                "module": chapter,
                "recommended_chapter": chapter,
                "action_targets": {
                    "practice": {"chapter": chapter, "difficulty": "适中", "count": 5, "reason": reason_text},
                    "graph": {"node_name": None},
                    "chat": {"prompt": f"请帮我总结 {chapter} 的核心知识点、常见错误和专项练习策略。"},
                },
            })

    if not dynamic_paths:
        for idx, path in enumerate(legacy_paths[:2], start=1):
            try:
                steps = json.loads(path.steps_json)
            except Exception:
                steps = [path.steps_json]
            dynamic_paths.append({
                "id": f"legacy-{path.id}",
                "title": path.title,
                "goal": path.goal,
                "steps": steps,
                "reason": "当前个性化数据较少，暂时展示系统基础学习路径。",
                "type": "legacy",
                "priority": idx,
                "focus_point": path.title,
                "module": "基础路径",
                "recommended_chapter": None,
                "action_targets": {
                    "practice": {"chapter": "全部", "difficulty": "适中", "count": 5, "reason": "基础练习"},
                    "graph": {"node_name": None},
                    "chat": {"prompt": f"请帮我制定一份围绕“{path.title}”的学习问答提纲。"},
                },
            })

    if not dynamic_paths:
        dynamic_paths.append({
            "id": "fallback-1",
            "title": DEFAULT_PATH["title"],
            "goal": DEFAULT_PATH["goal"],
            "steps": DEFAULT_PATH["steps"],
            "reason": "当前练习与错题数据不足，建议先完成一轮专项练习后再生成个性化路径。",
            "type": "fallback",
            "priority": 1,
            "focus_point": "基础巩固",
            "module": "基础路径",
            "recommended_chapter": "全部",
            "action_targets": {
                "practice": {"chapter": "全部", "difficulty": "适中", "count": 5, "reason": "基础练习"},
                "graph": {"node_name": None},
                "chat": {"prompt": "请根据软件项目管理课程，为我生成一份基础巩固学习建议。"},
            },
        })
    return dynamic_paths[:4]


def build_student_dashboard_summary(db: Session, student_id: int) -> dict[str, Any]:
    legacy_paths = db.query(LearningPath).filter(LearningPath.student_id == student_id).order_by(LearningPath.id.desc()).all()
    wrongs = db.query(WrongQuestion).filter(WrongQuestion.student_id == student_id).order_by(WrongQuestion.id.desc()).all()
    quizzes = db.query(QuizRecord).filter(QuizRecord.student_id == student_id).order_by(QuizRecord.id.desc()).all()
    tasks = db.query(TaskAssignment).filter(TaskAssignment.student_id == student_id).order_by(TaskAssignment.id.desc()).all()
    records = db.query(LearningRecord).filter(LearningRecord.student_id == student_id).order_by(LearningRecord.id.desc()).limit(30).all()
    practices = db.query(PracticeRecord).filter(PracticeRecord.student_id == student_id).order_by(PracticeRecord.id.desc()).limit(50).all()
    mastery_rows = (
        db.query(MasteryRecord, KnowledgePoint)
        .join(KnowledgePoint, KnowledgePoint.id == MasteryRecord.knowledge_point_id)
        .filter(MasteryRecord.student_id == student_id)
        .all()
    )

    point_counter = Counter()
    for w in wrongs[:30]:
        point_counter.update(infer_points((w.question_text or "") + "\n" + (w.analysis or "")))
    for p in practices[:30]:
        if not bool(p.is_correct):
            points = _safe_json_loads(p.knowledge_points_json)
            point_counter.update(points or infer_points((p.analysis or "") + "\n" + (p.chapter or "")))

    weak_mastery = sorted(
        [
            {
                "knowledge_point": kp.name,
                "subject": kp.subject,
                "mastery_score": round(float(mr.mastery_score or 0.0) * 100, 1),
            }
            for mr, kp in mastery_rows
            if float(mr.mastery_score or 0.0) < 0.6
        ],
        key=lambda x: x["mastery_score"],
    )

    focus_points = [p for p, _ in point_counter.most_common(5)]
    if weak_mastery:
        for item in weak_mastery[:2]:
            if item["knowledge_point"] not in focus_points:
                focus_points.append(item["knowledge_point"])

    recent_summary = summarize_student_learning(db, student_id, days=7)
    dynamic_paths = _build_dynamic_paths(wrongs, practices, weak_mastery, legacy_paths, recent_summary)

    recommendations = []
    if dynamic_paths:
        first = dynamic_paths[0]
        recommendations.append(f"最近最需要优先突破的是“{first.get('focus_point')}”，已为你生成针对性的学习路径。")
        if first.get("reason"):
            recommendations.append(first.get("reason"))
    if quizzes:
        latest = quizzes[0]
        ratio = latest.score / latest.total_score if latest.total_score else 0
        if ratio < 0.7:
            recommendations.append(f"最近一次测验得分为 {latest.score}/{latest.total_score}，建议优先复习错题集中模块。")
    record_points = _extract_points_from_records(records)
    if record_points:
        recommendations.append("你最近学习轨迹覆盖：" + "、".join(record_points[:4]) + "。")
    if not recommendations:
        recommendations.append("当前学习记录较少，建议先完成 1 次专项练习并整理 1 条错题，系统会再生成个性化路径。")

    suggested_actions = []
    if dynamic_paths:
        suggested_actions.append(f"优先复习：{dynamic_paths[0].get('focus_point')}")
        suggested_actions.append(f"继续学习路径：{dynamic_paths[0].get('title')}")
    suggested_actions.append("练习方向：信息系统项目管理师/PMP 风格案例题")
    suggested_actions.append("可尝试：甘特图、网络图、挣值分析图表题")

    return {
        "wrong_count": len(wrongs),
        "quiz_count": len(quizzes),
        "task_count": len(tasks),
        "path_count": len(dynamic_paths),
        "focus_subjects": [COURSE_NAME],
        "weak_mastery": weak_mastery[:5],
        "recommendations": recommendations[:4],
        "suggested_actions": suggested_actions[:4],
        "recent_keywords": record_points,
        "recent_summary": recent_summary,
        "dynamic_paths": dynamic_paths,
    }
