import json
from sqlalchemy.orm import Session
from .models import User, KnowledgePoint, LearningPath, PracticeQuestion
from .auth import get_password_hash
from .course_data import COURSE_NAME, COURSE_MODULES, DEFAULT_PATH


def seed_data(db: Session):
    users = [
        ("admin", "Admin@123", "admin", "系统管理员", None, None, None),
        ("teacher1", "Teacher@123", "teacher", "项目管理老师", None, None, COURSE_NAME),
        ("student1", "Student@123", "student", "学生一号", "软件工程2022级", "软工2201", COURSE_NAME),
    ]
    for username, password, role, full_name, grade, class_name, subject in users:
        user = db.query(User).filter(User.username == username, User.role == role).first()
        if not user:
            db.add(User(username=username, password_hash=get_password_hash(password), role=role, full_name=full_name, grade=grade, class_name=class_name, subject=subject))
    db.flush()

    teacher = db.query(User).filter(User.username == "teacher1", User.role == "teacher").first()
    created_by = teacher.id if teacher else None
    for module in COURSE_MODULES:
        for point in module["points"]:
            row = db.query(KnowledgePoint).filter(KnowledgePoint.name == point, KnowledgePoint.subject == COURSE_NAME).first()
            if not row:
                db.add(KnowledgePoint(name=point, subject=COURSE_NAME, description=f"{module['name']}核心知识点", difficulty="medium", created_by=created_by))

    student = db.query(User).filter(User.username == "student1", User.role == "student").first()
    if student:
        path = db.query(LearningPath).filter(LearningPath.student_id == student.id).first()
        if not path:
            db.add(LearningPath(student_id=student.id, title=DEFAULT_PATH["title"], goal=DEFAULT_PATH["goal"], steps_json=json.dumps(DEFAULT_PATH["steps"], ensure_ascii=False)))

    for item in PRACTICE_QUESTION_SEED:
        exists = db.query(PracticeQuestion).filter(PracticeQuestion.question_text == item["question_text"]).first()
        if not exists:
            db.add(PracticeQuestion(
                subject=COURSE_NAME,
                chapter=item["chapter"],
                difficulty=item.get("difficulty", "适中"),
                question_type=item["question_type"],
                question_text=item["question_text"],
                options_json=json.dumps(item["options"], ensure_ascii=False) if item["options"] is not None else None,
                correct_answer=item["correct_answer"],
                analysis=item["analysis"],
                knowledge_points_json=json.dumps(item["knowledge_points"], ensure_ascii=False),
                source_label=item["source_label"],
            ))
    db.commit()


PRACTICE_QUESTION_SEED = [
    {
        "chapter": "范围管理",
        "difficulty": "简单",
        "question_type": "单选题",
        "question_text": "在软件项目管理中，用于将项目可交付成果逐层分解为更小工作包的工具是？",
        "options": {"A": "甘特图", "B": "WBS", "C": "燃尽图", "D": "风险登记册"},
        "correct_answer": "B",
        "analysis": "WBS 是范围管理中对工作进行结构化分解的核心工具。",
        "knowledge_points": ["WBS", "范围定义"],
        "source_label": "软件项目管理课程样题",
    },
    {
        "chapter": "进度管理",
        "difficulty": "简单",
        "question_type": "单选题",
        "question_text": "某项目网络图中，决定项目总工期的路径称为？",
        "options": {"A": "最短路径", "B": "风险路径", "C": "关键路径", "D": "资源路径"},
        "correct_answer": "C",
        "analysis": "关键路径决定项目总工期，其总时差为 0 或最小。",
        "knowledge_points": ["关键路径法", "网络图"],
        "source_label": "软件项目管理课程样题",
    },
    {
        "chapter": "成本管理",
        "difficulty": "简单",
        "question_type": "单选题",
        "question_text": "当 CPI 小于 1 时，通常说明项目处于哪种状态？",
        "options": {"A": "成本节约", "B": "进度超前", "C": "成本超支", "D": "质量提升"},
        "correct_answer": "C",
        "analysis": "CPI = EV/AC，小于 1 表示挣值低于实际成本，项目成本超支。",
        "knowledge_points": ["挣值分析", "CPI"],
        "source_label": "信息系统项目管理师样题",
    },
    {
        "chapter": "风险管理与采购管理",
        "difficulty": "简单",
        "question_type": "单选题",
        "question_text": "项目团队先识别风险，再评估其概率和影响，这里的第二步是？",
        "options": {"A": "风险识别", "B": "风险分析", "C": "风险应对", "D": "风险监控"},
        "correct_answer": "B",
        "analysis": "风险管理通常遵循识别、分析、应对、监控的顺序。",
        "knowledge_points": ["风险识别", "风险分析"],
        "source_label": "软件项目管理课程样题",
    },
    {
        "chapter": "敏捷项目管理",
        "difficulty": "简单",
        "question_type": "单选题",
        "question_text": "Scrum 中用于展示当前 Sprint 剩余工作量变化趋势的图是？",
        "options": {"A": "WBS 图", "B": "鱼骨图", "C": "燃尽图", "D": "帕累托图"},
        "correct_answer": "C",
        "analysis": "燃尽图用于跟踪 Sprint 内剩余工作量变化。",
        "knowledge_points": ["Scrum", "Sprint", "燃尽图"],
        "source_label": "软件项目管理课程样题",
    },
    {
        "chapter": "项目收尾与复盘",
        "difficulty": "适中",
        "question_type": "简答题",
        "question_text": "请简要说明项目复盘时沉淀经验教训库的意义。",
        "options": None,
        "correct_answer": "有助于总结成功经验和失败原因，为后续项目提供可复用参考，提升组织过程资产。",
        "analysis": "回答应覆盖知识沉淀、组织复用、改进后续项目等要点。",
        "knowledge_points": ["项目总结", "经验教训库"],
        "source_label": "软件项目管理课程样题",
    },
    {
        "chapter": "进度管理",
        "difficulty": "适中",
        "question_type": "简答题",
        "question_text": "请说明关键路径法在项目进度管理中的作用。",
        "options": None,
        "correct_answer": "用于识别决定总工期的关键活动链，帮助项目经理进行工期控制、资源调配和进度监控。",
        "analysis": "答题时可从总工期判断、关键活动识别、时差分析和进度控制角度展开。",
        "knowledge_points": ["关键路径法", "网络图"],
        "source_label": "信息系统项目管理师样题",
    },
]
