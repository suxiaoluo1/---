@echo off
cd /d %~dp0frontend
streamlit run app.py
pause
